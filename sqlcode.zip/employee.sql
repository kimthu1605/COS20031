CREATE DATABASE  IF NOT EXISTS `employee` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `employee`;
-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: employee
-- ------------------------------------------------------
-- Server version	8.0.35

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `applicant_evaluation`
--

DROP TABLE IF EXISTS `applicant_evaluation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `applicant_evaluation` (
  `applicant_evaluation_id` int unsigned NOT NULL,
  `interviewer_id` int unsigned NOT NULL,
  `comments` longtext,
  `application_id` int unsigned NOT NULL,
  `hired_bit` bit(1) DEFAULT NULL,
  PRIMARY KEY (`applicant_evaluation_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `applicant_evaluation`
--

LOCK TABLES `applicant_evaluation` WRITE;
/*!40000 ALTER TABLE `applicant_evaluation` DISABLE KEYS */;
/*!40000 ALTER TABLE `applicant_evaluation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `applicants`
--

DROP TABLE IF EXISTS `applicants`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `applicants` (
  `applicant_id` int unsigned NOT NULL,
  `applicant_firstname` char(100) DEFAULT NULL,
  `applicant_lastname` char(100) DEFAULT NULL,
  `applicant_contact_number` varchar(100) DEFAULT NULL,
  `applicant_email` varchar(100) DEFAULT NULL,
  `applicant_biography` text,
  PRIMARY KEY (`applicant_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `applicants`
--

LOCK TABLES `applicants` WRITE;
/*!40000 ALTER TABLE `applicants` DISABLE KEYS */;
INSERT INTO `applicants` VALUES (1,'Ursula','Grouen','797-332-8323','ugrouen0@chicagotribune.com','ligula sit amet'),(2,'Dougy','Cottem','599-337-3256','dcottem1@epa.gov','nullam orci pede venenatis non'),(3,'Cissiee','Patrone','999-195-6973','cpatrone2@opensource.org','sit amet erat nulla tempus'),(4,'Jewel','Hafner','385-587-4617','jhafner3@mtv.com','gravida nisi at nibh in hac'),(5,'Kimberlyn','Sprackling','227-504-9454','ksprackling4@myspace.com','tristique tortor eu'),(6,'Aleen','Fishley','333-358-4096','afishley5@state.tx.us','vestibulum ante ipsum primis in faucibus'),(7,'Celestine','Tooting','652-851-4519','ctooting6@sun.com','diam id ornare'),(8,'Ives','Harraway','859-637-9457','iharraway7@theatlantic.com','faucibus orci luctus'),(9,'Karim','Boone','708-489-1026','kboone8@webmd.com','sem duis aliquam'),(10,'Reeva','Mateev','246-870-7225','rmateev9@cnn.com','in imperdiet et'),(11,'Emmet','Pain','257-674-1646','epaina@xing.com','quam sollicitudin vitae consectetuer'),(12,'Charlot','Juschke','919-748-8592','cjuschkeb@purevolume.com','eget eleifend luctus ultricies eu nibh'),(13,'Dorella','Thody','141-502-2969','dthodyc@google.co.jp','ligula in lacus curabitur at ipsum'),(14,'Timmi','Hartus','582-621-2002','thartusd@bluehost.com','ligula nec sem duis aliquam convallis'),(15,'Abraham','Philippe','836-223-6410','aphilippee@phoca.cz','augue vestibulum rutrum rutrum neque aenean'),(16,'Lucho','Thewys','774-374-3105','lthewysf@fastcompany.com','tempus vivamus in'),(17,'Michel','Brammer','759-502-4963','mbrammerg@surveymonkey.com','suspendisse potenti nullam porttitor'),(18,'Lucia','Hammond','631-833-7290','lhammondh@forbes.com','tellus in sagittis dui vel nisl'),(19,'Jere','Thorley','485-390-1376','jthorleyi@opensource.org','eget elit sodales scelerisque mauris sit'),(20,'Jocelin','Stebbings','933-916-5320','jstebbingsj@squidoo.com','primis in faucibus orci luctus'),(21,'Rosabel','Breinl','371-304-1900','rbreinlk@cloudflare.com','semper sapien a libero nam'),(22,'Alma','Reding','927-320-8903','aredingl@baidu.com','amet eros suspendisse accumsan'),(23,'Thorndike','Pittock','985-483-6871','tpittockm@zimbio.com','vivamus tortor duis mattis'),(24,'Trude','Rennebeck','223-140-8641','trennebeckn@spotify.com','in sagittis dui vel nisl'),(25,'Willi','Schruur','396-161-4562','wschruuro@foxnews.com','mattis pulvinar nulla pede ullamcorper augue'),(26,'Clementia','Elvish','904-387-8823','celvishp@purevolume.com','lacus at turpis'),(27,'Hadrian','Weaver','154-964-4831','hweaverq@microsoft.com','amet consectetuer adipiscing'),(28,'Pryce','Cowdroy','721-394-0502','pcowdroyr@jugem.jp','interdum mauris ullamcorper purus'),(29,'Masha','Tinson','344-284-0613','mtinsons@kickstarter.com','nulla pede ullamcorper'),(30,'Traci','Pasby','549-457-2591','tpasbyt@is.gd','vivamus metus arcu adipiscing'),(31,'Vanda','Kuhnert','611-590-2943','vkuhnertu@prweb.com','ultrices phasellus id sapien'),(32,'Kilian','Smillie','772-327-2340','ksmilliev@amazon.com','id ornare imperdiet sapien urna pretium'),(33,'Whitney','Shuter','682-567-4636','wshuterw@salon.com','quis orci nullam molestie nibh'),(34,'Brockie','Kinahan','916-723-5339','bkinahanx@netlog.com','non velit donec diam neque'),(35,'Stephenie','Hampton','761-270-4226','shamptony@adobe.com','enim in tempor turpis nec euismod'),(36,'Adair','Davidsen','801-608-3139','adavidsenz@pcworld.com','magna vestibulum aliquet'),(37,'Annadiana','Rout','319-423-2800','arout10@microsoft.com','sem praesent id massa'),(38,'Bowie','Wycliffe','314-638-9424','bwycliffe11@usda.gov','habitasse platea dictumst aliquam augue'),(39,'Eula','Dumbrill','183-721-3098','edumbrill12@netvibes.com','faucibus orci luctus et ultrices'),(40,'Fawne','Leahey','243-590-6652','fleahey13@columbia.edu','adipiscing molestie hendrerit at vulputate'),(41,'Colan','Phillpot','328-450-4191','cphillpot14@mashable.com','sapien in sapien'),(42,'Kennedy','Wilmot','182-571-9741','kwilmot15@newsvine.com','semper rutrum nulla nunc purus phasellus'),(43,'Valentina','Ox','193-474-6491','vox16@apple.com','congue vivamus metus'),(44,'Ilario','Emm','586-870-4152','iemm17@cisco.com','magna ac consequat metus sapien ut'),(45,'Brandtr','Leipelt','559-919-0716','bleipelt18@github.com','posuere cubilia curae nulla dapibus'),(46,'Gar','Yosevitz','719-801-1965','gyosevitz19@desdev.cn','in hac habitasse platea'),(47,'Joy','Garmons','258-715-4347','jgarmons1a@clickbank.net','iaculis diam erat'),(48,'Korella','Cristofori','113-574-0503','kcristofori1b@ameblo.jp','nulla suspendisse potenti'),(49,'Nathalia','Lynas','330-220-1858','nlynas1c@aboutads.info','ac diam cras pellentesque'),(50,'Nan','Greiswood','660-444-1873','ngreiswood1d@irs.gov','sapien placerat ante'),(51,'Jody','Perritt','294-194-8051','jperritt1e@bloglovin.com','ac neque duis bibendum morbi'),(52,'Francesca','Murison','792-587-1716','fmurison1f@networkadvertising.org','ac diam cras pellentesque'),(53,'Marilee','Riha','574-347-4407','mriha1g@bbc.co.uk','non lectus aliquam sit'),(54,'Monah','Caras','362-585-2566','mcaras1h@statcounter.com','ligula pellentesque ultrices phasellus id sapien'),(55,'Tami','Piaggia','961-164-0612','tpiaggia1i@hc360.com','nulla elit ac nulla sed vel'),(56,'Demetra','Bulteel','276-825-3031','dbulteel1j@unc.edu','consequat ut nulla sed accumsan felis'),(57,'Mathe','Sworn','939-518-7593','msworn1k@xinhuanet.com','nam nulla integer pede justo lacinia'),(58,'Loy','Trebilcock','871-420-3482','ltrebilcock1l@cafepress.com','sollicitudin vitae consectetuer eget rutrum'),(59,'Ronny','Fagg','207-234-8465','rfagg1m@intel.com','purus phasellus in felis donec semper'),(60,'Cybil','Antao','351-280-3718','cantao1n@printfriendly.com','in eleifend quam'),(61,'Franklin','Dunphie','108-190-9234','fdunphie1o@samsung.com','lobortis sapien sapien'),(62,'Margarette','Labrenz','122-295-7109','mlabrenz1p@foxnews.com','nulla eget eros elementum pellentesque'),(63,'Monroe','Portugal','336-217-6163','mportugal1q@facebook.com','fermentum donec ut mauris'),(64,'Brant','Wickardt','459-127-2624','bwickardt1r@google.es','morbi non quam'),(65,'Bunny','McGeachey','961-123-6999','bmcgeachey1s@flavors.me','dui nec nisi volutpat eleifend donec'),(66,'Mattie','Kruszelnicki','409-132-2735','mkruszelnicki1t@twitter.com','mi in porttitor pede'),(67,'Leisha','Seeman','227-269-3915','lseeman1u@nydailynews.com','quis lectus suspendisse potenti'),(68,'Floria','Philp','427-187-3630','fphilp1v@reuters.com','libero quis orci nullam'),(69,'Peri','Wildes','889-119-8871','pwildes1w@fotki.com','praesent lectus vestibulum quam sapien varius'),(70,'Phillis','Woffinden','708-678-5771','pwoffinden1x@multiply.com','suscipit nulla elit ac'),(71,'Margi','Capsey','483-781-3501','mcapsey1y@canalblog.com','volutpat quam pede lobortis'),(72,'Rafaelita','Plowes','272-592-9609','rplowes1z@oakley.com','in lacus curabitur at ipsum ac'),(73,'Hussein','Eccleston','716-779-9047','heccleston20@nationalgeographic.com','eu orci mauris lacinia'),(74,'Nalani','Jaffrey','868-207-0626','njaffrey21@oaic.gov.au','eget vulputate ut ultrices vel augue'),(75,'Hildagard','Maseres','801-524-4923','hmaseres22@gizmodo.com','justo pellentesque viverra pede ac diam'),(76,'Roxy','Flageul','857-854-7980','rflageul23@flavors.me','posuere metus vitae ipsum'),(77,'Kiah','Rosewarne','787-706-7216','krosewarne24@europa.eu','vestibulum sagittis sapien cum sociis natoque'),(78,'Darbee','Smallridge','166-583-4423','dsmallridge25@chron.com','in est risus auctor sed'),(79,'Darwin','Turpie','890-273-8558','dturpie26@symantec.com','mauris viverra diam vitae'),(80,'Tracey','Aizik','189-593-0764','taizik27@java.com','varius ut blandit non interdum in'),(81,'Franchot','Sherlaw','598-464-9910','fsherlaw28@free.fr','phasellus id sapien in sapien iaculis'),(82,'Colver','Coal','396-758-2798','ccoal29@ning.com','a ipsum integer'),(83,'Mildrid','De Bernardi','908-472-2053','mdebernardi2a@npr.org','congue risus semper porta volutpat'),(84,'Marty','Abbots','739-494-7739','mabbots2b@harvard.edu','lorem quisque ut erat curabitur'),(85,'Caron','Sparway','462-205-8622','csparway2c@sbwire.com','volutpat eleifend donec'),(86,'Cassi','Edgeson','725-511-8686','cedgeson2d@nytimes.com','dolor quis odio consequat varius integer'),(87,'Nolana','Hyland','385-822-2463','nhyland2e@gmpg.org','posuere cubilia curae mauris viverra diam'),(88,'Ingelbert','Towriss','645-425-2028','itowriss2f@sciencedirect.com','nulla ut erat id mauris'),(89,'Dorine','Slyvester','381-738-7586','dslyvester2g@rambler.ru','sodales sed tincidunt eu felis'),(90,'Tim','Noe','746-509-0432','tnoe2h@biglobe.ne.jp','pede lobortis ligula sit'),(91,'Amanda','Edinboro','938-829-6760','aedinboro2i@123-reg.co.uk','vestibulum velit id'),(92,'Byrle','Astridge','480-456-6912','bastridge2j@ebay.com','hac habitasse platea dictumst aliquam'),(93,'Jarid','Oldall','419-197-7918','joldall2k@constantcontact.com','tincidunt nulla mollis'),(94,'Cal','Scatchard','695-648-5440','cscatchard2l@patch.com','enim sit amet nunc'),(95,'Kalina','Kemell','691-435-2045','kkemell2m@dailymotion.com','nisi eu orci'),(96,'Konstance','Osgardby','576-539-5799','kosgardby2n@unblog.fr','justo eu massa donec dapibus duis'),(97,'Lezley','Lockton','939-409-9942','llockton2o@1688.com','consequat dui nec nisi volutpat eleifend'),(98,'Othelia','McGunley','933-588-9379','omcgunley2p@spiegel.de','odio in hac habitasse platea dictumst'),(99,'Brandon','Le Pruvost','517-495-5850','blepruvost2q@woothemes.com','sit amet eleifend pede libero'),(100,'Evangelia','Krates','415-153-1051','ekrates2r@tmall.com','lacus at velit vivamus vel');
/*!40000 ALTER TABLE `applicants` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `application`
--

DROP TABLE IF EXISTS `application`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `application` (
  `application_id` int unsigned NOT NULL,
  `application_date` date DEFAULT NULL,
  `job_vacancies_id` int unsigned NOT NULL,
  `applicant_id` int unsigned NOT NULL,
  `qualifications` varchar(100) DEFAULT NULL,
  `experience_years` decimal(10,2) DEFAULT NULL,
  `applied_position` varchar(100) NOT NULL,
  PRIMARY KEY (`application_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `application`
--

LOCK TABLES `application` WRITE;
/*!40000 ALTER TABLE `application` DISABLE KEYS */;
INSERT INTO `application` VALUES (1,'2023-03-21',92,47,'FALSE',3.40,'Accounting'),(2,'2023-03-16',51,22,'FALSE',6.60,'Product Management'),(3,'2023-04-23',26,78,'FALSE',2.70,'Human Resources'),(4,'2023-07-14',17,90,'TRUE',7.70,'Engineering'),(5,'2023-11-07',70,25,'TRUE',7.90,'Product Management'),(6,'2023-06-18',57,13,'TRUE',8.90,'Support'),(7,'2023-12-14',61,72,'FALSE',9.60,'Sales'),(8,'2023-07-01',73,45,'FALSE',3.10,'Legal'),(9,'2023-12-13',31,76,'FALSE',3.50,'Research and Development'),(10,'2023-03-18',85,18,'FALSE',9.80,'Human Resources'),(11,'2023-09-08',88,81,'TRUE',9.30,'Product Management'),(12,'2023-05-21',46,77,'TRUE',2.60,'Human Resources'),(13,'2023-08-30',1,22,'FALSE',6.00,'Product Management'),(14,'2023-06-02',18,22,'FALSE',7.00,'Research and Development'),(15,'2023-10-17',68,11,'TRUE',4.30,'Legal'),(16,'2023-08-09',19,18,'TRUE',8.80,'Legal'),(17,'2023-07-20',26,58,'TRUE',7.90,'Research and Development'),(18,'2023-02-27',58,36,'TRUE',9.70,'Accounting'),(19,'2023-03-26',63,58,'FALSE',9.90,'Engineering'),(20,'2023-08-14',45,71,'TRUE',1.00,'Research and Development'),(21,'2023-07-22',99,41,'TRUE',1.70,'Training'),(22,'2023-06-15',37,95,'TRUE',3.50,'Sales'),(23,'2023-09-21',83,72,'FALSE',2.80,'Legal'),(24,'2023-01-11',30,91,'TRUE',2.20,'Human Resources'),(25,'2023-08-25',44,57,'FALSE',6.70,'Marketing'),(26,'2023-07-24',24,58,'TRUE',9.80,'Marketing'),(27,'2023-08-02',52,83,'TRUE',6.90,'Accounting'),(28,'2023-08-13',46,98,'TRUE',8.60,'Research and Development'),(29,'2023-02-22',6,74,'TRUE',9.80,'Business Development'),(30,'2023-05-06',17,35,'FALSE',6.70,'Support'),(31,'2023-09-12',37,74,'TRUE',6.70,'Legal'),(32,'2023-08-31',94,93,'TRUE',2.10,'Engineering'),(33,'2023-04-07',23,3,'FALSE',8.40,'Sales'),(34,'2023-11-08',45,86,'TRUE',9.20,'Business Development'),(35,'2023-02-22',65,35,'FALSE',2.10,'Engineering'),(36,'2023-11-12',55,30,'TRUE',4.60,'Marketing'),(37,'2023-05-03',25,1,'FALSE',4.30,'Marketing'),(38,'2023-07-05',30,95,'FALSE',1.50,'Accounting'),(39,'2023-04-10',4,94,'TRUE',4.50,'Research and Development'),(40,'2023-09-28',6,89,'TRUE',5.10,'Sales'),(41,'2023-05-13',100,79,'TRUE',1.80,'Product Management'),(42,'2023-09-10',24,97,'TRUE',7.80,'Human Resources'),(43,'2023-06-06',30,10,'FALSE',7.60,'Research and Development'),(44,'2023-08-29',3,10,'TRUE',5.40,'Services'),(45,'2023-10-12',58,85,'FALSE',2.20,'Marketing'),(46,'2023-04-17',47,95,'FALSE',6.90,'Training'),(47,'2023-12-04',8,83,'TRUE',5.90,'Product Management'),(48,'2023-09-23',1,67,'FALSE',7.80,'Sales'),(49,'2023-04-23',90,88,'TRUE',3.90,'Human Resources'),(50,'2023-04-18',40,45,'FALSE',8.90,'Product Management'),(51,'2023-12-29',64,57,'TRUE',3.60,'Product Management'),(52,'2023-09-28',52,78,'TRUE',5.70,'Product Management'),(53,'2023-03-31',21,26,'FALSE',6.20,'Research and Development'),(54,'2023-02-22',37,89,'FALSE',2.80,'Research and Development'),(55,'2023-03-13',77,53,'TRUE',8.80,'Training'),(56,'2023-12-17',82,27,'TRUE',7.70,'Training'),(57,'2023-08-19',79,29,'FALSE',7.80,'Engineering'),(58,'2023-10-11',82,53,'TRUE',1.40,'Marketing'),(59,'2023-12-12',38,80,'FALSE',7.00,'Product Management'),(60,'2023-09-11',47,87,'FALSE',5.80,'Sales'),(61,'2023-05-22',97,35,'TRUE',2.10,'Sales'),(62,'2023-11-27',54,26,'TRUE',7.90,'Marketing'),(63,'2023-06-19',5,84,'FALSE',7.00,'Research and Development'),(64,'2023-02-25',99,11,'TRUE',2.70,'Marketing'),(65,'2023-03-25',24,6,'TRUE',3.20,'Human Resources'),(66,'2023-12-23',60,43,'FALSE',5.20,'Accounting'),(67,'2023-06-06',45,35,'FALSE',8.00,'Research and Development'),(68,'2023-04-11',77,24,'TRUE',7.20,'Accounting'),(69,'2023-06-05',85,43,'FALSE',4.30,'Engineering'),(70,'2023-10-08',11,57,'FALSE',8.60,'Support'),(71,'2023-08-26',41,55,'TRUE',4.20,'Accounting'),(72,'2023-02-18',99,98,'TRUE',5.90,'Accounting'),(73,'2023-03-15',2,57,'FALSE',3.10,'Human Resources'),(74,'2023-03-07',48,29,'TRUE',6.80,'Sales'),(75,'2023-02-10',54,55,'FALSE',3.90,'Training'),(76,'2023-03-29',96,67,'TRUE',9.50,'Product Management'),(77,'2023-06-12',83,45,'TRUE',6.70,'Research and Development'),(78,'2023-10-23',35,52,'FALSE',8.20,'Legal'),(79,'2023-12-16',42,88,'TRUE',4.30,'Marketing'),(80,'2023-10-19',33,31,'FALSE',2.40,'Training'),(81,'2023-12-05',44,14,'TRUE',5.40,'Support'),(82,'2023-10-06',85,92,'TRUE',3.60,'Research and Development'),(83,'2023-01-25',36,75,'TRUE',1.70,'Engineering'),(84,'2023-04-26',76,37,'TRUE',1.40,'Accounting'),(85,'2023-01-25',20,24,'TRUE',8.70,'Research and Development'),(86,'2023-04-01',63,80,'TRUE',1.90,'Legal'),(87,'2023-04-18',53,85,'TRUE',6.70,'Product Management'),(88,'2023-10-15',21,82,'FALSE',2.60,'Sales'),(89,'2023-11-09',69,62,'TRUE',2.00,'Engineering'),(90,'2023-03-22',87,25,'FALSE',7.30,'Business Development'),(91,'2023-02-06',41,51,'FALSE',9.80,'Marketing'),(92,'2023-12-29',51,27,'TRUE',7.70,'Training'),(93,'2023-02-11',40,53,'FALSE',3.90,'Engineering'),(94,'2023-10-18',20,44,'FALSE',2.60,'Accounting'),(95,'2023-11-06',33,87,'TRUE',4.20,'Product Management'),(96,'2023-01-10',11,54,'TRUE',5.20,'Support'),(97,'2023-05-09',15,100,'TRUE',3.60,'Marketing'),(98,'2023-05-16',69,74,'FALSE',4.30,'Sales'),(99,'2023-05-16',44,19,'FALSE',7.40,'Training'),(100,'2023-07-23',27,31,'FALSE',4.30,'Legal');
/*!40000 ALTER TABLE `application` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `application_document`
--

DROP TABLE IF EXISTS `application_document`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `application_document` (
  `application_document_id` int unsigned NOT NULL,
  `document_id` int unsigned NOT NULL,
  `application_id` int unsigned NOT NULL,
  PRIMARY KEY (`application_document_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `application_document`
--

LOCK TABLES `application_document` WRITE;
/*!40000 ALTER TABLE `application_document` DISABLE KEYS */;
INSERT INTO `application_document` VALUES (1,1,1),(2,2,2),(3,3,3),(4,4,4),(5,5,5),(6,6,6),(7,7,7),(8,8,8),(9,9,9),(10,10,10),(11,11,11),(12,12,12),(13,13,13),(14,14,14),(15,15,15),(16,16,16),(17,17,17),(18,18,18),(19,19,19),(20,20,20),(21,21,21),(22,22,22),(23,23,23),(24,24,24),(25,25,25),(26,26,26),(27,27,27),(28,28,28),(29,29,29),(30,30,30),(31,31,31),(32,32,32),(33,33,33),(34,34,34),(35,35,35),(36,36,36),(37,37,37),(38,38,38),(39,39,39),(40,40,40),(41,41,41),(42,42,42),(43,43,43),(44,44,44),(45,45,45),(46,46,46),(47,47,47),(48,48,48),(49,49,49),(50,50,50),(51,51,51),(52,52,52),(53,53,53),(54,54,54),(55,55,55),(56,56,56),(57,57,57),(58,58,58),(59,59,59),(60,60,60),(61,61,61),(62,62,62),(63,63,63),(64,64,64),(65,65,65),(66,66,66),(67,67,67),(68,68,68),(69,69,69),(70,70,70),(71,71,71),(72,72,72),(73,73,73),(74,74,74),(75,75,75),(76,76,76),(77,77,77),(78,78,78),(79,79,79),(80,80,80),(81,81,81),(82,82,82),(83,83,83),(84,84,84),(85,85,85),(86,86,86),(87,87,87),(88,88,88),(89,89,89),(90,90,90),(91,91,91),(92,92,92),(93,93,93),(94,94,94),(95,95,95),(96,96,96),(97,97,97),(98,98,98),(99,99,99),(100,100,100);
/*!40000 ALTER TABLE `application_document` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `application_status`
--

DROP TABLE IF EXISTS `application_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `application_status` (
  `applicant_status_id` int unsigned NOT NULL,
  `status` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  PRIMARY KEY (`applicant_status_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `application_status`
--

LOCK TABLES `application_status` WRITE;
/*!40000 ALTER TABLE `application_status` DISABLE KEYS */;
INSERT INTO `application_status` VALUES (1,'augue'),(2,'nisi'),(3,'posuere'),(4,'luctus cum sociis'),(5,'luctus ultricies'),(6,'libero'),(7,'volutpat sapien'),(8,'curabitur'),(9,'pretium iaculis'),(10,'turpis adipiscing'),(11,'augue'),(12,'non velit nec'),(13,'habitasse'),(14,'nulla'),(15,'metus arcu adipiscing'),(16,'nec'),(17,'nibh in'),(18,'leo pellentesque'),(19,'porttitor'),(20,'sit'),(21,'sapien'),(22,'nec'),(23,'dis parturient montes'),(24,'sit amet consectetuer'),(25,'pretium quis lectus'),(26,'donec quis'),(27,'at velit'),(28,'dolor'),(29,'cubilia curae'),(30,'ut'),(31,'lorem'),(32,'non sodales'),(33,'odio cras'),(34,'luctus et ultrices'),(35,'sem sed'),(36,'sit'),(37,'cubilia'),(38,'etiam justo'),(39,'id'),(40,'porta volutpat quam'),(41,'condimentum curabitur in'),(42,'amet turpis elementum'),(43,'nullam porttitor lacus'),(44,'amet justo'),(45,'ac enim in'),(46,'in tempor turpis'),(47,'elementum pellentesque'),(48,'dapibus'),(49,'mi'),(50,'congue eget semper'),(51,'lectus'),(52,'enim sit amet'),(53,'risus semper porta'),(54,'nunc rhoncus'),(55,'id sapien in'),(56,'donec pharetra'),(57,'nisl venenatis'),(58,'placerat'),(59,'adipiscing elit proin'),(60,'id turpis'),(61,'viverra dapibus'),(62,'vestibulum sagittis sapien'),(63,'sagittis dui'),(64,'placerat praesent'),(65,'adipiscing'),(66,'hendrerit'),(67,'vestibulum'),(68,'faucibus'),(69,'cubilia'),(70,'in faucibus'),(71,'metus vitae'),(72,'morbi non quam'),(73,'consequat morbi'),(74,'habitasse platea dictumst'),(75,'interdum venenatis'),(76,'congue eget'),(77,'parturient'),(78,'neque libero convallis'),(79,'id pretium iaculis'),(80,'condimentum neque'),(81,'ipsum'),(82,'nisi at nibh'),(83,'non quam nec'),(84,'vivamus'),(85,'ligula vehicula'),(86,'eleifend'),(87,'amet'),(88,'euismod'),(89,'suspendisse potenti cras'),(90,'neque libero'),(91,'habitasse'),(92,'dapibus nulla'),(93,'feugiat et'),(94,'vivamus vel nulla'),(95,'sapien ut nunc'),(96,'felis sed interdum'),(97,'velit eu'),(98,'consequat metus sapien'),(99,'ante nulla justo'),(100,'id nulla ultrices');
/*!40000 ALTER TABLE `application_status` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `application_status_change`
--

DROP TABLE IF EXISTS `application_status_change`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `application_status_change` (
  `applicant_status_change_id` int unsigned NOT NULL,
  `application_status_id` int unsigned NOT NULL,
  `application_id` int unsigned NOT NULL,
  `date_changed` date DEFAULT NULL,
  PRIMARY KEY (`applicant_status_change_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `application_status_change`
--

LOCK TABLES `application_status_change` WRITE;
/*!40000 ALTER TABLE `application_status_change` DISABLE KEYS */;
INSERT INTO `application_status_change` VALUES (1,1,1,'2023-01-11'),(2,2,2,'2023-12-09'),(3,3,3,'2023-06-25'),(4,4,4,'2023-11-19'),(5,5,5,'2023-07-07'),(6,6,6,'2023-02-02'),(7,7,7,'2023-12-10'),(8,8,8,'2023-02-13'),(9,9,9,'2023-02-11'),(10,10,10,'2023-09-17'),(11,11,11,'2023-02-11'),(12,12,12,'2023-03-17'),(13,13,13,'2023-06-14'),(14,14,14,'2023-12-21'),(15,15,15,'2023-09-07'),(16,16,16,'2023-04-19'),(17,17,17,'2023-11-02'),(18,18,18,'2023-12-23'),(19,19,19,'2023-09-24'),(20,20,20,'2023-05-07'),(21,21,21,'2023-04-26'),(22,22,22,'2023-06-11'),(23,23,23,'2023-10-21'),(24,24,24,'2023-07-17'),(25,25,25,'2023-09-02'),(26,26,26,'2023-03-14'),(27,27,27,'2023-01-07'),(28,28,28,'2023-09-01'),(29,29,29,'2023-07-04'),(30,30,30,'2023-11-25'),(31,31,31,'2023-06-19'),(32,32,32,'2023-07-01'),(33,33,33,'2023-06-28'),(34,34,34,'2023-10-20'),(35,35,35,'2023-12-03'),(36,36,36,'2023-01-22'),(37,37,37,'2023-06-30'),(38,38,38,'2023-05-05'),(39,39,39,'2023-11-08'),(40,40,40,'2023-03-12'),(41,41,41,'2023-02-28'),(42,42,42,'2023-09-28'),(43,43,43,'2023-01-14'),(44,44,44,'2023-04-09'),(45,45,45,'2023-10-27'),(46,46,46,'2023-10-24'),(47,47,47,'2023-02-05'),(48,48,48,'2023-04-15'),(49,49,49,'2023-02-16'),(50,50,50,'2023-09-18'),(51,51,51,'2023-01-30'),(52,52,52,'2023-07-11'),(53,53,53,'2023-09-17'),(54,54,54,'2023-12-24'),(55,55,55,'2023-04-27'),(56,56,56,'2023-10-21'),(57,57,57,'2023-06-18'),(58,58,58,'2023-09-16'),(59,59,59,'2023-07-16'),(60,60,60,'2023-07-03'),(61,61,61,'2023-08-01'),(62,62,62,'2023-02-05'),(63,63,63,'2023-07-22'),(64,64,64,'2023-02-19'),(65,65,65,'2023-01-04'),(66,66,66,'2023-06-15'),(67,67,67,'2023-09-10'),(68,68,68,'2023-01-06'),(69,69,69,'2023-02-24'),(70,70,70,'2023-09-21'),(71,71,71,'2023-06-25'),(72,72,72,'2023-05-22'),(73,73,73,'2023-10-14'),(74,74,74,'2023-07-12'),(75,75,75,'2023-06-25'),(76,76,76,'2023-11-22'),(77,77,77,'2023-01-04'),(78,78,78,'2023-11-09'),(79,79,79,'2023-08-12'),(80,80,80,'2023-05-27'),(81,81,81,'2023-04-17'),(82,82,82,'2023-07-26'),(83,83,83,'2023-01-14'),(84,84,84,'2023-09-24'),(85,85,85,'2023-11-08'),(86,86,86,'2023-04-22'),(87,87,87,'2023-07-23'),(88,88,88,'2023-04-09'),(89,89,89,'2023-10-16'),(90,90,90,'2023-09-04'),(91,91,91,'2023-04-10'),(92,92,92,'2023-03-30'),(93,93,93,'2023-11-04'),(94,94,94,'2023-11-17'),(95,95,95,'2023-11-07'),(96,96,96,'2023-03-11'),(97,97,97,'2023-02-18'),(98,98,98,'2023-08-02'),(99,99,99,'2023-12-07'),(100,100,100,'2023-02-28');
/*!40000 ALTER TABLE `application_status_change` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `attendance_records`
--

DROP TABLE IF EXISTS `attendance_records`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `attendance_records` (
  `attendance_record_id` int unsigned NOT NULL,
  `employee_id` int unsigned NOT NULL,
  `attendance_date` date DEFAULT NULL,
  `clock_in_time` time DEFAULT NULL,
  `clock_out_time` time DEFAULT NULL,
  `job_position_id` int NOT NULL,
  `leave_id` int NOT NULL,
  `duty_id` int NOT NULL,
  `total_hours_labor` int unsigned DEFAULT NULL,
  PRIMARY KEY (`attendance_record_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `attendance_records`
--

LOCK TABLES `attendance_records` WRITE;
/*!40000 ALTER TABLE `attendance_records` DISABLE KEYS */;
INSERT INTO `attendance_records` VALUES (1,40,'2023-07-27','10:52:00','20:40:00',1,1,24,46),(2,31,'2023-10-31','08:44:00','19:17:00',2,2,28,1),(3,60,'2023-03-31','10:35:00','03:58:00',3,3,23,76),(4,4,'2023-01-12','13:05:00','10:12:00',4,4,18,34),(5,14,'2023-11-28','13:37:00','20:18:00',5,5,84,98),(6,52,'2023-01-04','03:38:00','11:39:00',6,6,26,14),(7,26,'2023-05-12','21:15:00','01:45:00',7,7,27,55),(8,49,'2023-10-12','02:12:00','19:43:00',8,8,93,18),(9,5,'2023-06-26','17:13:00','10:41:00',9,9,59,5),(10,25,'2023-08-25','21:53:00','15:12:00',10,10,89,39),(11,90,'2023-09-10','20:03:00','05:09:00',11,11,66,37),(12,26,'2023-12-30','17:39:00','09:15:00',12,12,30,42),(13,78,'2023-11-13','08:04:00','06:32:00',13,13,5,87),(14,7,'2023-08-20','20:48:00','17:12:00',14,14,31,60),(15,24,'2023-02-04','19:37:00','17:48:00',15,15,82,86),(16,37,'2023-08-01','00:33:00','06:35:00',16,16,87,19),(17,62,'2023-07-10','02:30:00','22:08:00',17,17,63,67),(18,57,'2023-05-26','23:44:00','11:20:00',18,18,68,15),(19,54,'2023-07-10','20:55:00','03:17:00',19,19,27,94),(20,38,'2023-12-08','04:36:00','05:03:00',20,20,4,4),(21,38,'2023-09-12','14:31:00','14:13:00',21,21,62,98),(22,3,'2023-10-10','19:55:00','17:29:00',22,22,13,95),(23,92,'2023-08-03','03:35:00','07:21:00',23,23,25,73),(24,41,'2023-04-04','04:11:00','20:26:00',24,24,80,71),(25,18,'2023-08-03','07:12:00','20:45:00',25,25,100,72),(26,30,'2023-11-05','07:37:00','03:37:00',26,26,76,8),(27,84,'2023-10-20','12:42:00','17:17:00',27,27,39,18),(28,80,'2023-04-19','18:09:00','05:28:00',28,28,74,40),(29,49,'2023-01-05','20:57:00','03:53:00',29,29,92,41),(30,53,'2023-06-03','21:07:00','13:26:00',30,30,8,12),(31,53,'2023-04-23','21:09:00','15:07:00',31,31,89,18),(32,86,'2023-08-15','22:31:00','06:26:00',32,32,45,42),(33,34,'2023-05-17','13:54:00','01:18:00',33,33,14,85),(34,7,'2023-03-09','00:01:00','18:11:00',34,34,42,82),(35,7,'2023-11-29','12:22:00','12:58:00',35,35,46,56),(36,35,'2023-03-22','19:28:00','16:01:00',36,36,73,96),(37,96,'2023-10-14','00:43:00','04:40:00',37,37,25,66),(38,87,'2023-12-11','20:34:00','23:27:00',38,38,11,10),(39,18,'2023-01-02','23:35:00','23:50:00',39,39,4,12),(40,55,'2023-09-29','00:16:00','04:08:00',40,40,77,46),(41,74,'2023-09-15','12:37:00','22:10:00',41,41,60,55),(42,79,'2023-08-13','06:41:00','19:27:00',42,42,60,82),(43,96,'2023-12-19','12:40:00','18:12:00',43,43,39,57),(44,26,'2023-06-07','06:26:00','13:07:00',44,44,77,26),(45,96,'2023-01-27','06:16:00','05:11:00',45,45,45,79),(46,44,'2023-06-27','22:34:00','21:40:00',46,46,2,24),(47,81,'2023-02-21','00:54:00','04:35:00',47,47,28,11),(48,61,'2023-09-28','14:31:00','08:38:00',48,48,92,35),(49,36,'2023-12-17','08:14:00','05:17:00',49,49,36,73),(50,20,'2023-09-07','04:38:00','10:33:00',50,50,92,74),(51,60,'2023-06-22','07:27:00','15:00:00',51,51,70,58),(52,97,'2023-04-08','17:11:00','12:47:00',52,52,2,74),(53,93,'2023-04-16','05:13:00','18:46:00',53,53,65,85),(54,17,'2023-12-06','03:00:00','13:32:00',54,54,10,80),(55,58,'2023-06-07','16:46:00','14:08:00',55,55,29,44),(56,85,'2023-07-17','00:29:00','11:13:00',56,56,42,81),(57,22,'2023-11-26','02:07:00','10:34:00',57,57,29,8),(58,94,'2023-08-26','21:58:00','17:12:00',58,58,97,32),(59,11,'2023-11-11','10:42:00','23:42:00',59,59,26,14),(60,99,'2023-06-10','20:39:00','16:35:00',60,60,100,70),(61,20,'2023-06-18','05:41:00','02:27:00',61,61,48,17),(62,98,'2023-11-01','01:28:00','05:44:00',62,62,66,86),(63,67,'2023-06-20','08:41:00','07:52:00',63,63,6,57),(64,43,'2023-06-26','15:31:00','01:51:00',64,64,67,39),(65,26,'2023-05-04','06:14:00','04:19:00',65,65,28,68),(66,88,'2023-08-12','11:06:00','07:48:00',66,66,91,40),(67,83,'2023-09-29','10:24:00','23:35:00',67,67,94,2),(68,14,'2023-04-20','14:48:00','20:36:00',68,68,36,38),(69,1,'2023-10-15','17:37:00','21:46:00',69,69,18,88),(70,21,'2023-05-23','16:59:00','01:40:00',70,70,29,67),(71,99,'2023-05-26','12:37:00','11:09:00',71,71,59,24),(72,91,'2023-07-21','01:12:00','19:13:00',72,72,75,80),(73,5,'2023-02-24','03:10:00','05:27:00',73,73,19,78),(74,59,'2023-02-05','20:45:00','19:45:00',74,74,84,28),(75,81,'2023-12-29','14:02:00','21:18:00',75,75,84,79),(76,12,'2023-06-14','02:52:00','15:40:00',76,76,22,5),(77,44,'2023-07-16','10:11:00','07:48:00',77,77,62,91),(78,62,'2023-04-28','09:09:00','14:23:00',78,78,14,85),(79,71,'2023-06-15','00:41:00','13:57:00',79,79,78,16),(80,53,'2023-01-26','23:09:00','12:01:00',80,80,62,51),(81,75,'2023-01-02','22:45:00','17:16:00',81,81,44,60),(82,40,'2023-11-21','20:24:00','12:15:00',82,82,51,26),(83,6,'2023-08-20','22:10:00','00:20:00',83,83,58,82),(84,55,'2023-08-12','10:48:00','14:56:00',84,84,34,45),(85,69,'2023-10-23','20:38:00','16:46:00',85,85,18,74),(86,29,'2023-09-17','07:28:00','03:07:00',86,86,53,2),(87,4,'2023-01-14','04:54:00','11:00:00',87,87,50,73),(88,53,'2023-04-23','02:57:00','12:14:00',88,88,96,89),(89,75,'2023-05-17','22:05:00','20:37:00',89,89,1,57),(90,24,'2023-01-30','14:16:00','09:26:00',90,90,20,52),(91,89,'2023-09-28','05:34:00','14:59:00',91,91,37,65),(92,52,'2023-01-11','02:44:00','15:09:00',92,92,69,5),(93,66,'2023-07-01','13:53:00','23:57:00',93,93,6,92),(94,37,'2023-03-25','04:48:00','18:48:00',94,94,79,53),(95,44,'2023-07-07','15:45:00','16:16:00',95,95,81,91),(96,66,'2023-03-21','19:34:00','15:32:00',96,96,71,64),(97,18,'2023-10-15','05:19:00','09:13:00',97,97,74,84),(98,43,'2023-11-10','10:18:00','22:28:00',98,98,46,76),(99,82,'2023-08-01','10:06:00','02:28:00',99,99,19,47),(100,52,'2023-11-05','09:15:00','00:19:00',100,100,62,1);
/*!40000 ALTER TABLE `attendance_records` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `course_category`
--

DROP TABLE IF EXISTS `course_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `course_category` (
  `course_category_id` int unsigned NOT NULL,
  `course_category_name` varchar(100) DEFAULT NULL,
  `course_category_explain` varchar(100) NOT NULL,
  PRIMARY KEY (`course_category_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `course_category`
--

LOCK TABLES `course_category` WRITE;
/*!40000 ALTER TABLE `course_category` DISABLE KEYS */;
INSERT INTO `course_category` VALUES (1,'massa volutpat convallis','duis consequat dui nec'),(2,'libero nam dui','convallis nulla neque libero convallis'),(3,'amet sapien dignissim vestibulum vestibulum','diam cras pellentesque volutpat dui'),(4,'luctus cum sociis','pretium iaculis justo in'),(5,'vel est donec','dis parturient montes nascetur ridiculus'),(6,'quam pharetra magna ac consequat','morbi non lectus aliquam'),(7,'diam vitae quam suspendisse potenti','proin interdum mauris non ligula'),(8,'ante vel ipsum praesent blandit','dapibus augue vel'),(9,'ipsum primis in','orci luctus et ultrices posuere'),(10,'aliquet massa id lobortis convallis','iaculis diam erat fermentum justo'),(11,'gravida nisi at nibh','rutrum nulla nunc purus'),(12,'cursus vestibulum proin eu','lacus at velit vivamus'),(13,'integer aliquet massa id lobortis','nullam molestie nibh in'),(14,'in quam fringilla','condimentum id luctus nec'),(15,'est quam pharetra magna','turpis integer aliquet massa'),(16,'vitae mattis nibh','quis orci nullam molestie nibh'),(17,'in est risus auctor sed','suscipit nulla elit ac'),(18,'semper rutrum nulla','quis orci eget orci'),(19,'felis ut at dolor quis','suscipit nulla elit'),(20,'nulla justo aliquam quis','vulputate nonummy maecenas tincidunt'),(21,'sociis natoque penatibus et','dis parturient montes nascetur'),(22,'morbi non quam','massa tempor convallis nulla neque'),(23,'curabitur gravida nisi at nibh','curabitur in libero ut massa'),(24,'molestie hendrerit at','sapien in sapien'),(25,'consequat ut nulla','vulputate luctus cum'),(26,'duis mattis egestas','justo aliquam quis turpis'),(27,'convallis morbi odio odio elementum','neque duis bibendum morbi'),(28,'dui luctus rutrum nulla tellus','maecenas tincidunt lacus at velit'),(29,'vel ipsum praesent blandit','fermentum donec ut mauris eget'),(30,'odio donec vitae nisi','mauris vulputate elementum nullam varius'),(31,'vel est donec odio justo','ullamcorper purus sit amet nulla'),(32,'nulla quisque arcu libero','justo in blandit ultrices'),(33,'vitae quam suspendisse potenti','cras pellentesque volutpat'),(34,'magna vestibulum aliquet','vitae consectetuer eget rutrum at'),(35,'aliquam non mauris morbi non','libero ut massa volutpat convallis'),(36,'sed sagittis nam congue','morbi vestibulum velit id'),(37,'praesent blandit lacinia erat vestibulum','ligula pellentesque ultrices'),(38,'neque vestibulum eget','commodo vulputate justo in'),(39,'interdum eu tincidunt in leo','auctor gravida sem praesent id'),(40,'odio porttitor id consequat in','ac consequat metus sapien'),(41,'eleifend donec ut dolor morbi','morbi sem mauris laoreet'),(42,'quis tortor id nulla ultrices','erat quisque erat eros'),(43,'mauris vulputate elementum nullam varius','sem mauris laoreet'),(44,'semper porta volutpat quam pede','congue risus semper porta'),(45,'metus arcu adipiscing molestie','montes nascetur ridiculus mus vivamus'),(46,'et eros vestibulum','convallis tortor risus dapibus'),(47,'amet lobortis sapien sapien','blandit non interdum in'),(48,'ornare imperdiet sapien urna','orci luctus et ultrices posuere'),(49,'purus aliquet at feugiat non','primis in faucibus orci'),(50,'maecenas ut massa','luctus et ultrices'),(51,'euismod scelerisque quam','vestibulum ac est lacinia'),(52,'ut nulla sed accumsan felis','vulputate elementum nullam varius'),(53,'sem duis aliquam convallis','amet lobortis sapien sapien'),(54,'odio elementum eu interdum','nullam varius nulla facilisi'),(55,'quis justo maecenas rhoncus aliquam','nec condimentum neque sapien placerat'),(56,'nulla ac enim in','ut massa volutpat convallis morbi'),(57,'volutpat erat quisque erat eros','nam tristique tortor eu'),(58,'venenatis lacinia aenean sit','lorem vitae mattis'),(59,'eu nibh quisque id','quisque id justo sit'),(60,'sit amet diam in magna','in libero ut massa'),(61,'lacus at turpis donec','vulputate vitae nisl aenean lectus'),(62,'tortor id nulla ultrices aliquet','tellus nulla ut erat id'),(63,'in porttitor pede','id luctus nec molestie'),(64,'elit ac nulla sed vel','etiam justo etiam pretium iaculis'),(65,'enim leo rhoncus','sed lacus morbi sem'),(66,'non mi integer','amet cursus id'),(67,'vestibulum ac est lacinia','odio condimentum id'),(68,'amet sem fusce','quam suspendisse potenti'),(69,'proin leo odio porttitor id','augue aliquam erat'),(70,'eros viverra eget congue eget','vel lectus in quam fringilla'),(71,'vestibulum ante ipsum','porttitor lorem id ligula suspendisse'),(72,'ligula suspendisse ornare consequat lectus','justo pellentesque viverra pede ac'),(73,'nunc rhoncus dui vel','diam neque vestibulum'),(74,'felis sed interdum','sed vel enim sit amet'),(75,'lorem ipsum dolor sit amet','eu interdum eu tincidunt in'),(76,'justo lacinia eget tincidunt','diam cras pellentesque volutpat dui'),(77,'congue elementum in hac','eget semper rutrum nulla nunc'),(78,'id nisl venenatis lacinia','diam neque vestibulum eget vulputate'),(79,'justo nec condimentum','facilisi cras non velit'),(80,'ante vivamus tortor duis','sed vestibulum sit amet cursus'),(81,'parturient montes nascetur','congue elementum in'),(82,'vestibulum velit id pretium iaculis','ac leo pellentesque'),(83,'ac nulla sed vel','nam dui proin leo'),(84,'ac consequat metus sapien ut','vestibulum vestibulum ante'),(85,'nulla nisl nunc nisl','ac nulla sed'),(86,'nulla elit ac nulla','orci luctus et ultrices'),(87,'amet nulla quisque arcu','posuere cubilia curae donec'),(88,'cubilia curae nulla dapibus dolor','lorem ipsum dolor sit'),(89,'congue etiam justo','non mattis pulvinar nulla'),(90,'lacus curabitur at ipsum','justo lacinia eget tincidunt eget'),(91,'sit amet nunc viverra dapibus','amet sapien dignissim vestibulum'),(92,'tempor convallis nulla','ligula vehicula consequat morbi'),(93,'volutpat sapien arcu sed augue','sit amet sapien'),(94,'nec nisi vulputate nonummy maecenas','platea dictumst morbi vestibulum velit'),(95,'cubilia curae donec','consectetuer eget rutrum'),(96,'sed magna at nunc commodo','vel nisl duis ac nibh'),(97,'sit amet lobortis sapien sapien','natoque penatibus et magnis dis'),(98,'molestie hendrerit at','arcu adipiscing molestie'),(99,'in purus eu magna','quis odio consequat varius integer'),(100,'mauris vulputate elementum nullam varius','odio cras mi');
/*!40000 ALTER TABLE `course_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `departments`
--

DROP TABLE IF EXISTS `departments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `departments` (
  `department_id` int unsigned NOT NULL,
  `department_name` varchar(100) DEFAULT NULL,
  `department_head` int unsigned NOT NULL,
  PRIMARY KEY (`department_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `departments`
--

LOCK TABLES `departments` WRITE;
/*!40000 ALTER TABLE `departments` DISABLE KEYS */;
/*!40000 ALTER TABLE `departments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `documents`
--

DROP TABLE IF EXISTS `documents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `documents` (
  `document_id` int unsigned NOT NULL,
  `document_name` varchar(100) DEFAULT NULL,
  `document_binary` blob NOT NULL,
  `document_url` text,
  `document_last_update` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`document_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `documents`
--

LOCK TABLES `documents` WRITE;
/*!40000 ALTER TABLE `documents` DISABLE KEYS */;
/*!40000 ALTER TABLE `documents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `duty_duration`
--

DROP TABLE IF EXISTS `duty_duration`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `duty_duration` (
  `duty_id` int unsigned NOT NULL,
  `employee_id` int unsigned NOT NULL,
  `job_position_id` int unsigned NOT NULL,
  `duration` int DEFAULT NULL,
  `duty_date` date DEFAULT NULL,
  PRIMARY KEY (`duty_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `duty_duration`
--

LOCK TABLES `duty_duration` WRITE;
/*!40000 ALTER TABLE `duty_duration` DISABLE KEYS */;
/*!40000 ALTER TABLE `duty_duration` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `earnings`
--

DROP TABLE IF EXISTS `earnings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `earnings` (
  `earning_id` int unsigned NOT NULL,
  `job_position_id` int unsigned NOT NULL,
  `earning_amount` decimal(10,2) DEFAULT NULL,
  `leave_id` int NOT NULL,
  `remained_earning` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`earning_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `earnings`
--

LOCK TABLES `earnings` WRITE;
/*!40000 ALTER TABLE `earnings` DISABLE KEYS */;
/*!40000 ALTER TABLE `earnings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employee_attend_training`
--

DROP TABLE IF EXISTS `employee_attend_training`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `employee_attend_training` (
  `employee_id` int unsigned NOT NULL,
  `training_plan_id` int unsigned NOT NULL,
  `training_category_explain` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`employee_id`,`training_plan_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employee_attend_training`
--

LOCK TABLES `employee_attend_training` WRITE;
/*!40000 ALTER TABLE `employee_attend_training` DISABLE KEYS */;
INSERT INTO `employee_attend_training` VALUES (1,1,'scelerisque quam turpis adipiscing lorem vitae mattis nibh ligula'),(2,2,'curabitur in libero ut massa volutpat convallis'),(3,3,'venenatis tristique fusce congue diam id'),(4,4,'tortor duis mattis egestas metus'),(5,5,'varius nulla facilisi cras non velit'),(6,6,'porttitor pede justo eu massa donec dapibus'),(7,7,'dictumst maecenas ut massa quis augue luctus'),(8,8,'nulla tellus in sagittis dui vel nisl duis ac'),(9,9,'duis bibendum felis sed interdum venenatis turpis enim blandit'),(10,10,'nulla neque libero convallis eget eleifend luctus ultricies eu'),(11,11,'congue risus semper porta volutpat quam'),(12,12,'magna at nunc commodo placerat praesent blandit'),(13,13,'est quam pharetra magna ac consequat metus sapien ut'),(14,14,'vestibulum ante ipsum primis in faucibus'),(15,15,'cum sociis natoque penatibus et magnis dis parturient montes'),(16,16,'vulputate justo in blandit ultrices'),(17,17,'interdum eu tincidunt in leo'),(18,18,'est congue elementum in hac'),(19,19,'mattis pulvinar nulla pede ullamcorper augue a suscipit'),(20,20,'ut odio cras mi pede'),(21,21,'id consequat in consequat ut nulla sed'),(22,22,'id mauris vulputate elementum nullam varius nulla facilisi cras'),(23,23,'vestibulum ante ipsum primis in faucibus orci luctus et ultrices'),(24,24,'nulla sed vel enim sit amet'),(25,25,'dapibus nulla suscipit ligula in lacus curabitur at ipsum ac'),(26,26,'sapien varius ut blandit non interdum in ante vestibulum ante'),(27,27,'rutrum nulla tellus in sagittis'),(28,28,'ut dolor morbi vel lectus in quam'),(29,29,'imperdiet et commodo vulputate justo in blandit ultrices enim lorem'),(30,30,'porta volutpat quam pede lobortis ligula'),(31,31,'vestibulum velit id pretium iaculis diam erat fermentum justo'),(32,32,'penatibus et magnis dis parturient'),(33,33,'nullam orci pede venenatis non sodales sed tincidunt'),(34,34,'velit donec diam neque vestibulum eget'),(35,35,'nulla quisque arcu libero rutrum ac lobortis vel dapibus'),(36,36,'dignissim vestibulum vestibulum ante ipsum primis in faucibus orci'),(37,37,'est et tempus semper est'),(38,38,'orci mauris lacinia sapien quis libero nullam sit'),(39,39,'duis at velit eu est'),(40,40,'aliquam lacus morbi quis tortor id nulla ultrices aliquet maecenas'),(41,41,'morbi ut odio cras mi pede malesuada in imperdiet'),(42,42,'nulla ultrices aliquet maecenas leo odio condimentum'),(43,43,'iaculis diam erat fermentum justo nec'),(44,44,'nam ultrices libero non mattis pulvinar nulla pede'),(45,45,'in purus eu magna vulputate luctus cum sociis'),(46,46,'hendrerit at vulputate vitae nisl aenean lectus'),(47,47,'quam fringilla rhoncus mauris enim leo rhoncus sed'),(48,48,'rutrum at lorem integer tincidunt ante vel ipsum praesent'),(49,49,'nulla mollis molestie lorem quisque'),(50,50,'urna pretium nisl ut volutpat sapien arcu sed augue'),(51,51,'lobortis est phasellus sit amet erat'),(52,52,'quis odio consequat varius integer'),(53,53,'quis lectus suspendisse potenti in eleifend quam'),(54,54,'nonummy integer non velit donec diam neque vestibulum'),(55,55,'morbi non lectus aliquam sit amet diam in'),(56,56,'dictumst etiam faucibus cursus urna ut tellus'),(57,57,'pede lobortis ligula sit amet eleifend pede libero quis orci'),(58,58,'et ultrices posuere cubilia curae donec pharetra'),(59,59,'vivamus vel nulla eget eros elementum'),(60,60,'sociis natoque penatibus et magnis dis'),(61,61,'lobortis est phasellus sit amet erat'),(62,62,'vel nulla eget eros elementum pellentesque quisque porta volutpat erat'),(63,63,'nunc proin at turpis a pede posuere nonummy'),(64,64,'in eleifend quam a odio in'),(65,65,'duis aliquam convallis nunc proin at turpis a pede posuere'),(66,66,'suspendisse ornare consequat lectus in est risus'),(67,67,'orci nullam molestie nibh in lectus pellentesque'),(68,68,'nibh in quis justo maecenas rhoncus aliquam lacus morbi'),(69,69,'rutrum neque aenean auctor gravida sem praesent id'),(70,70,'curabitur gravida nisi at nibh in hac habitasse platea dictumst'),(71,71,'commodo vulputate justo in blandit ultrices'),(72,72,'risus dapibus augue vel accumsan tellus nisi'),(73,73,'duis bibendum felis sed interdum venenatis turpis enim'),(74,74,'amet justo morbi ut odio'),(75,75,'sapien urna pretium nisl ut volutpat sapien arcu sed'),(76,76,'ante vivamus tortor duis mattis egestas metus aenean fermentum'),(77,77,'curae mauris viverra diam vitae quam'),(78,78,'nam dui proin leo odio porttitor id consequat in consequat'),(79,79,'adipiscing lorem vitae mattis nibh ligula nec sem duis aliquam'),(80,80,'erat vestibulum sed magna at nunc commodo placerat'),(81,81,'integer ac neque duis bibendum morbi'),(82,82,'fermentum donec ut mauris eget massa'),(83,83,'non mi integer ac neque duis bibendum morbi'),(84,84,'at turpis a pede posuere nonummy'),(85,85,'duis bibendum morbi non quam nec dui luctus'),(86,86,'maecenas pulvinar lobortis est phasellus sit'),(87,87,'tincidunt nulla mollis molestie lorem quisque ut erat curabitur gravida'),(88,88,'eget nunc donec quis orci'),(89,89,'cursus urna ut tellus nulla ut erat id mauris'),(90,90,'ligula suspendisse ornare consequat lectus in est risus'),(91,91,'interdum in ante vestibulum ante ipsum primis in'),(92,92,'quisque porta volutpat erat quisque erat eros'),(93,93,'a libero nam dui proin leo odio porttitor id'),(94,94,'nisl nunc rhoncus dui vel sem sed sagittis'),(95,95,'nulla suspendisse potenti cras in purus'),(96,96,'quam fringilla rhoncus mauris enim leo rhoncus sed vestibulum'),(97,97,'faucibus accumsan odio curabitur convallis duis consequat dui nec nisi'),(98,98,'sagittis dui vel nisl duis ac nibh fusce lacus purus'),(99,99,'elit sodales scelerisque mauris sit amet eros suspendisse accumsan tortor'),(100,100,'lectus aliquam sit amet diam in magna bibendum');
/*!40000 ALTER TABLE `employee_attend_training` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employee_bank_info`
--

DROP TABLE IF EXISTS `employee_bank_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `employee_bank_info` (
  `employee_bank_account_number` varchar(100) NOT NULL,
  `employee_bank_account_holder` varchar(100) DEFAULT NULL,
  `employee_bank_account_type` char(100) DEFAULT NULL,
  `employee_bank_branch_name` varchar(100) DEFAULT NULL,
  `employee_id` int unsigned NOT NULL,
  PRIMARY KEY (`employee_bank_account_number`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employee_bank_info`
--

LOCK TABLES `employee_bank_info` WRITE;
/*!40000 ALTER TABLE `employee_bank_info` DISABLE KEYS */;
INSERT INTO `employee_bank_info` VALUES ('00-265-7800','Merill Creelman','mastercard','Runolfsdottir, Bartell and Baumbach',64),('00-466-8562','Nickie Macknish','mastercard','Hettinger, Kuhlman and Russel',95),('01-251-6401','Archy Ruse','diners-club-us-ca','Nicolas Group',15),('03-788-0767','Alfonso Pennacci','jcb','Gottlieb, Mante and Jacobs',49),('04-093-4969','Ki Pavy','jcb','Shields and Sons',85),('06-043-2558','Gunner Simchenko','mastercard','Dooley, Beer and Rogahn',6),('06-265-6648','Miof mela Abramovicz','maestro','Ruecker-McDermott',35),('08-142-6007','Simeon Hardy-Piggin','americanexpress','Auer-Baumbach',51),('09-585-7254','Annalise Noah','jcb','Altenwerth-Lang',22),('10-156-7764','Cristal Croot','mastercard','Johnson, Leannon and Buckridge',75),('11-632-6567','Sandy Fowley','jcb','Fahey and Sons',89),('11-856-5598','Miquela Greydon','jcb','McGlynn-Crona',73),('13-766-6501','Shantee Squirrel','jcb','Hilpert Inc',96),('14-240-4368','Zacharias Ticksall','jcb','Brekke, Davis and White',56),('14-732-4531','Marylin Berzon','maestro','Jacobi-Hintz',82),('14-947-2531','Wells Casado','mastercard','Kihn, Kessler and Rutherford',14),('15-083-8592','Alfons Bagshaw','china-unionpay','Durgan, Reichel and Metz',32),('18-267-7289','Biron Eddison','china-unionpay','O\'Kon and Sons',24),('18-905-4810','Neale Sturm','americanexpress','Monahan Group',21),('19-904-1656','Andi MacBarron','visa','Kuphal Group',25),('20-213-4419','Brandon Gever','visa-electron','McClure, Zulauf and Bode',18),('21-885-2827','Blakelee Grossier','jcb','Kerluke Inc',77),('23-514-7423','Nessa Althorpe','jcb','Ziemann, Hintz and Konopelski',16),('25-061-9832','Odella Danforth','jcb','Runolfsdottir-Mayer',1),('25-170-0433','Tessie Grigaut','mastercard','Russel-Yost',41),('25-617-0657','Salomi Fattorini','mastercard','Abbott, Stanton and Howe',72),('25-909-2521','Tammy Blazevic','jcb','Lebsack, Pouros and Kassulke',74),('26-124-0902','Sherline Hartles','jcb','West Inc',36),('26-208-3095','Hayyim Herculeson','switch','Turcotte, Cronin and Ziemann',37),('28-107-4682','Jourdan Tucsell','jcb','Baumbach, Stanton and Parker',68),('32-759-1609','Ben Mingotti','diners-club-enroute','Schamberger, Reilly and Davis',44),('32-892-7324','Darrin Sauven','bankcard','Gerlach Group',55),('34-147-5131','Toddy Marshfield','jcb','Rice-Ernser',60),('35-735-7094','Jenica Kidner','mastercard','Schimmel-Hickle',11),('36-252-1461','Thelma Daniellot','china-unionpay','Murphy and Sons',39),('36-356-7483','Kathe McAuslan','switch','Ullrich LLC',23),('37-400-4290','Naoma Haley','mastercard','Wolff and Sons',100),('37-529-1942','Benson Heis','switch','Bergnaum and Sons',98),('38-439-8781','Stanislas Tollerton','visa','Price, Klein and Brekke',83),('38-495-4747','Annmarie Mikalski','diners-club-carte-blanche','Ullrich Inc',52),('41-823-9702','Kym Swetland','diners-club-international','Flatley-Daugherty',28),('42-261-9411','Tonie McClune','switch','Leuschke and Sons',59),('42-812-3462','Reggis Delamar','jcb','Jakubowski Group',5),('42-821-7166','Fergus Bewly','maestro','Rice-Volkman',87),('44-272-4237','Fanchette Cecil','jcb','Brakus-Dickens',9),('46-598-4104','Shea Drawmer','jcb','Hackett, Smith and MacGyver',13),('46-754-4207','Dicky Copestake','diners-club-enroute','Swaniawski, Terry and Feil',8),('46-942-2439','Harwell Wordley','americanexpress','Herzog, Upton and Fahey',54),('49-133-4697','Sal Luton','jcb','Cassin Inc',58),('51-894-0515','Norby Amor','jcb','Bahringer-Abernathy',47),('53-621-9898','Edlin Hallagan','diners-club-carte-blanche','Witting, Lesch and Trantow',78),('53-721-4787','Florri Noquet','diners-club-enroute','Sauer, Labadie and Hagenes',42),('54-281-5676','Gery Teodori','jcb','Rogahn and Sons',63),('54-558-0670','Thurstan Hulburt','jcb','Stehr, Breitenberg and Farrell',76),('55-806-9365','Susan Gammel','jcb','Steuber, Veum and Dicki',84),('57-635-8625','Mab Gyorgy','jcb','Graham-O\'Reilly',90),('57-931-7207','Tracey Mingard','maestro','Friesen, Kiehn and Marquardt',81),('59-743-4043','Nancee Helleckas','laser','Kuhic Inc',19),('60-911-9827','Wilhelmine Tison','visa-electron','Klocko, Balistreri and Franecki',92),('62-075-0276','Emyle Stieger','switch','Purdy, Dietrich and Feest',86),('62-082-6139','Cyb Derye-Barrett','china-unionpay','Legros-Mante',34),('65-220-2688','Skip McBrearty','jcb','Von Group',2),('65-757-8654','Merrill Spurritt','mastercard','Hagenes, Harvey and Buckridge',93),('66-764-3635','Jenifer Goodbarr','mastercard','Herzog LLC',3),('67-767-5717','Ashil Domerq','diners-club-us-ca','Veum-Jerde',62),('68-495-2389','Clay Moorerud','americanexpress','Schuster and Sons',66),('68-736-3673','Marshal Iorio','maestro','Kessler, Gutkowski and Willms',50),('69-878-1891','Kerrie Skoggings','diners-club-enroute','Olson, Deckow and Stark',91),('70-094-9388','Millard Stratford','diners-club-carte-blanche','Runolfsdottir-Jenkins',99),('70-452-3580','Barnard Kuhnhardt','jcb','Schulist-Schinner',12),('72-597-2297','Licha Padwick','laser','Yost-Cummerata',71),('74-334-1730','Augustine Balsellie','jcb','Blick-Schneider',31),('74-419-7853','Haskell Stenett','maestro','Nolan-Johnston',57),('76-696-1645','Daveta Weetch','americanexpress','Kunze-Stroman',65),('77-358-5731','Harper McArley','maestro','Altenwerth-Johnson',79),('77-455-8616','Ritchie Marikhin','solo','Roberts-Collier',53),('77-955-1350','Webb O\'Scanlon','visa-electron','Stracke Inc',67),('78-533-9422','Marian Perris','jcb','Armstrong-Bartell',17),('79-736-0727','Elfrieda MacLaughlin','jcb','Hermiston-Carter',40),('80-829-9682','Hunt Beswetherick','mastercard','Aufderhar and Sons',4),('81-504-3289','Pooh Bocking','bankcard','Labadie and Sons',45),('82-361-0527','Gardie Francello','jcb','Langosh LLC',10),('82-569-0094','Ly Missington','jcb','Smitham LLC',26),('83-002-3771','Juieta Letford','visa-electron','Feest, Rolfson and Hagenes',30),('83-728-8985','Rhonda Best','jcb','Farrell and Sons',80),('86-237-2831','Graehme Hens','visa-electron','Mosciski-Johnson',20),('86-875-8869','Ganny Cattle','jcb','Quitzon Inc',27),('87-211-1495','Janetta Udie','diners-club-carte-blanche','Pollich-Turcotte',69),('88-026-4993','Shurlocke Massen','diners-club-us-ca','Hudson LLC',88),('88-223-0860','Ulrike Vassman','switch','Carroll-Kertzmann',33),('89-560-2619','Ceil Stote','jcb','Willms-Koch',46),('91-037-2265','Trina Strickett','laser','Wisoky LLC',29),('91-232-0343','Aleen Gaveltone','jcb','Witting, Oberbrunner and Casper',61),('92-567-2095','Nev Truckett','jcb','Price, Strosin and Raynor',70),('93-116-6133','Savina Lutz','maestro','Gleason and Sons',38),('96-809-7240','Fanchette Farherty','jcb','Zulauf-Cruickshank',48),('97-852-7183','Demott Abazi','mastercard','Boehm-Brown',94),('99-279-1778','Tadeas Denty','jcb','Keebler-Crona',97),('99-695-6126','Merry Ambrogetti','jcb','Homenick and Sons',43),('99-896-6295','Murielle Sher','jcb','Schuppe-Crona',7);
/*!40000 ALTER TABLE `employee_bank_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employee_employment_status`
--

DROP TABLE IF EXISTS `employee_employment_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `employee_employment_status` (
  `employee_employment_status_id` int unsigned NOT NULL,
  `employment_status` varchar(100) DEFAULT NULL,
  `employment_status_change` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`employee_employment_status_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employee_employment_status`
--

LOCK TABLES `employee_employment_status` WRITE;
/*!40000 ALTER TABLE `employee_employment_status` DISABLE KEYS */;
INSERT INTO `employee_employment_status` VALUES (1,'eu massa','lectus pellentesque eget'),(2,'eros elementum pellentesque','ridiculus'),(3,'a ipsum integer','in felis'),(4,'donec','cras in purus'),(5,'pellentesque ultrices phasellus','faucibus'),(6,'ac leo','dapibus'),(7,'eget tempus vel','cras pellentesque'),(8,'aenean lectus','luctus cum sociis'),(9,'sit amet','id pretium'),(10,'in magna bibendum','nulla integer pede'),(11,'etiam justo etiam','ultrices posuere cubilia'),(12,'orci eget orci','sit amet'),(13,'id nulla','etiam'),(14,'cursus','non ligula'),(15,'odio consequat varius','cubilia'),(16,'neque duis','nibh'),(17,'quam pharetra magna','luctus'),(18,'at','vel'),(19,'quis justo maecenas','ante ipsum primis'),(20,'diam neque','at'),(21,'diam erat fermentum','etiam faucibus cursus'),(22,'vestibulum aliquet','vehicula'),(23,'natoque penatibus et','cursus'),(24,'consequat','in lacus curabitur'),(25,'ut','nullam molestie'),(26,'ut','ultrices mattis odio'),(27,'sed','nam tristique'),(28,'cras pellentesque volutpat','nulla facilisi'),(29,'commodo placerat','tristique fusce'),(30,'sagittis dui vel','a'),(31,'curae','iaculis diam erat'),(32,'tristique','curabitur in'),(33,'dapibus','non quam'),(34,'ante vivamus','erat quisque erat'),(35,'dui vel sem','ante nulla justo'),(36,'neque aenean','lobortis convallis'),(37,'morbi sem mauris','quisque'),(38,'enim lorem ipsum','condimentum id luctus'),(39,'pede','posuere metus'),(40,'id sapien in','vehicula'),(41,'massa','morbi non'),(42,'integer aliquet massa','at dolor'),(43,'quam fringilla rhoncus','purus sit'),(44,'lorem','leo rhoncus sed'),(45,'curae nulla dapibus','aliquam'),(46,'luctus ultricies eu','amet nunc'),(47,'erat','volutpat convallis morbi'),(48,'fusce consequat','non ligula'),(49,'amet','tellus'),(50,'eget semper','vel dapibus'),(51,'vestibulum','ac'),(52,'turpis integer','a'),(53,'natoque penatibus et','tincidunt lacus'),(54,'eget','nisi eu orci'),(55,'eros viverra','curabitur'),(56,'pede','at'),(57,'quis tortor id','lectus in quam'),(58,'ultrices','posuere cubilia curae'),(59,'magnis dis','rutrum'),(60,'pretium iaculis diam','gravida sem'),(61,'at nulla','convallis duis'),(62,'ligula nec sem','lacus at turpis'),(63,'ultrices enim','viverra pede ac'),(64,'mauris ullamcorper','nullam varius nulla'),(65,'purus eu','lacinia'),(66,'nascetur ridiculus','ut rhoncus aliquet'),(67,'in','vestibulum sit'),(68,'suspendisse','congue'),(69,'vehicula consequat','vulputate ut ultrices'),(70,'nunc','donec ut'),(71,'nulla suscipit ligula','habitasse'),(72,'magna at nunc','amet cursus'),(73,'amet erat','sagittis nam'),(74,'vitae nisi','luctus et'),(75,'turpis elementum ligula','cubilia curae'),(76,'diam','vel'),(77,'non velit','nisl'),(78,'scelerisque quam turpis','sodales sed'),(79,'mi','iaculis justo in'),(80,'proin leo','eget rutrum'),(81,'massa volutpat','a ipsum integer'),(82,'dis parturient montes','integer'),(83,'dui vel nisl','aliquam'),(84,'penatibus et','ac diam'),(85,'tincidunt eget','nunc vestibulum'),(86,'suspendisse potenti','vestibulum'),(87,'turpis elementum ligula','nisl'),(88,'dui maecenas','gravida'),(89,'nunc nisl','ut mauris'),(90,'massa tempor convallis','phasellus'),(91,'et magnis dis','nulla'),(92,'nulla','sociis natoque'),(93,'fringilla rhoncus mauris','convallis'),(94,'justo etiam','sit amet consectetuer'),(95,'ipsum primis','nunc nisl duis'),(96,'penatibus','tellus'),(97,'erat','sit'),(98,'enim sit','magna'),(99,'turpis donec posuere','turpis nec'),(100,'orci pede','fusce posuere');
/*!40000 ALTER TABLE `employee_employment_status` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employee_employment_type`
--

DROP TABLE IF EXISTS `employee_employment_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `employee_employment_type` (
  `employee_employment_type_id` int unsigned NOT NULL,
  `employment_type` varchar(100) DEFAULT NULL,
  `employment_type_change` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`employee_employment_type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employee_employment_type`
--

LOCK TABLES `employee_employment_type` WRITE;
/*!40000 ALTER TABLE `employee_employment_type` DISABLE KEYS */;
INSERT INTO `employee_employment_type` VALUES (1,'quis','eu mi nulla'),(2,'montes nascetur','venenatis lacinia aenean'),(3,'auctor sed','amet lobortis'),(4,'lectus pellentesque','in'),(5,'amet sem fusce','vel nisl'),(6,'sapien','ultrices'),(7,'sodales scelerisque mauris','ligula'),(8,'in quis justo','sapien dignissim vestibulum'),(9,'vel nulla eget','suscipit ligula'),(10,'dui','morbi vel lectus'),(11,'vulputate','porttitor id'),(12,'sed justo pellentesque','faucibus'),(13,'vel lectus','est'),(14,'etiam','volutpat eleifend donec'),(15,'at','congue risus semper'),(16,'neque aenean','suscipit a feugiat'),(17,'pede','nulla integer'),(18,'suscipit a feugiat','donec vitae nisi'),(19,'urna pretium nisl','imperdiet nullam'),(20,'nascetur','congue etiam justo'),(21,'purus eu magna','nascetur ridiculus mus'),(22,'enim','et tempus semper'),(23,'imperdiet nullam orci','ut'),(24,'felis sed','potenti nullam'),(25,'erat curabitur','quam a odio'),(26,'mauris morbi non','donec quis'),(27,'vel est','habitasse'),(28,'dui','libero quis orci'),(29,'porta','vivamus'),(30,'magna at','semper'),(31,'pellentesque ultrices mattis','velit'),(32,'tristique','nulla tempus'),(33,'felis ut at','placerat praesent blandit'),(34,'non','nec condimentum neque'),(35,'arcu','orci eget orci'),(36,'vehicula','eu pede'),(37,'consequat in consequat','justo maecenas rhoncus'),(38,'in','non'),(39,'iaculis','ligula'),(40,'nunc donec quis','lorem integer tincidunt'),(41,'amet cursus','tempus'),(42,'interdum mauris','pellentesque'),(43,'suspendisse','ultrices mattis odio'),(44,'in','montes'),(45,'morbi odio','sed'),(46,'pede libero quis','pretium quis'),(47,'dolor vel','a ipsum integer'),(48,'pellentesque','enim leo'),(49,'amet lobortis sapien','ut suscipit'),(50,'nibh in hac','nisl duis'),(51,'dolor morbi','mus etiam'),(52,'phasellus sit amet','tincidunt eu felis'),(53,'rhoncus','nibh in'),(54,'id massa','pharetra magna ac'),(55,'sociis','imperdiet sapien urna'),(56,'in','justo nec'),(57,'vel','ante ipsum primis'),(58,'dapibus nulla','cras pellentesque'),(59,'ipsum praesent blandit','tempus sit amet'),(60,'nunc commodo placerat','turpis nec'),(61,'sodales sed','condimentum'),(62,'tempus vivamus','est risus'),(63,'imperdiet','luctus'),(64,'et','turpis'),(65,'bibendum','curae'),(66,'sed ante','id ligula suspendisse'),(67,'magnis','amet nunc'),(68,'bibendum','dapibus duis at'),(69,'parturient','natoque penatibus et'),(70,'donec vitae nisi','sed tristique'),(71,'id ligula suspendisse','sit amet'),(72,'leo rhoncus','ipsum ac'),(73,'orci','eu pede'),(74,'dui vel','sapien placerat'),(75,'risus praesent lectus','faucibus cursus urna'),(76,'aenean lectus pellentesque','leo'),(77,'molestie hendrerit at','est quam pharetra'),(78,'velit','nulla'),(79,'posuere metus','enim'),(80,'egestas metus aenean','nullam varius nulla'),(81,'vel','integer non velit'),(82,'nullam','augue vestibulum rutrum'),(83,'ipsum integer','lacus at velit'),(84,'dolor vel est','porta'),(85,'odio cras','mauris'),(86,'leo','pulvinar sed'),(87,'leo odio porttitor','volutpat quam pede'),(88,'lacus curabitur','volutpat in'),(89,'morbi','accumsan tortor'),(90,'duis mattis egestas','id nisl'),(91,'volutpat','ultrices'),(92,'sit amet','vitae'),(93,'eros viverra eget','eros'),(94,'et','massa tempor'),(95,'proin','quisque erat'),(96,'augue a','accumsan felis'),(97,'primis','quam pede'),(98,'eget massa','non velit'),(99,'elit','enim'),(100,'nulla suspendisse','integer non velit');
/*!40000 ALTER TABLE `employee_employment_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employee_fixed_compenstion`
--

DROP TABLE IF EXISTS `employee_fixed_compenstion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `employee_fixed_compenstion` (
  `employee_fixed_compensation_id` int unsigned NOT NULL,
  `compensation_event` varchar(100) NOT NULL,
  `pay_frequency` varchar(100) DEFAULT NULL,
  `compensation_amount` decimal(10,2) DEFAULT NULL,
  `employee_position` int NOT NULL,
  `employee_id` int NOT NULL,
  PRIMARY KEY (`employee_fixed_compensation_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employee_fixed_compenstion`
--

LOCK TABLES `employee_fixed_compenstion` WRITE;
/*!40000 ALTER TABLE `employee_fixed_compenstion` DISABLE KEYS */;
INSERT INTO `employee_fixed_compenstion` VALUES (1,'nec nisi vulputate','lobortis ligula',87502.13,84,1),(2,'massa id lobortis','dolor quis odio',53291.24,13,2),(3,'dolor sit','eget',77666.86,23,3),(4,'blandit','ut mauris',62543.76,34,4),(5,'eget massa','malesuada in',77918.49,100,5),(6,'diam erat','amet eleifend',54764.09,36,6),(7,'vulputate nonummy','pretium nisl',42901.08,37,7),(8,'orci pede venenatis','velit',61265.21,8,8),(9,'dui vel sem','felis',45418.19,18,9),(10,'est','at turpis',25363.91,94,10),(11,'et ultrices posuere','lorem vitae mattis',22176.49,58,11),(12,'nulla suspendisse','curae',4659.70,94,12),(13,'pretium quis lectus','dis parturient montes',41617.58,55,13),(14,'ut erat','elementum',6276.91,36,14),(15,'vestibulum sagittis sapien','est risus',6513.59,17,15),(16,'in tempus','turpis donec',26837.84,30,16),(17,'integer a nibh','molestie hendrerit',44532.44,81,17),(18,'sed tristique in','erat tortor',48357.78,92,18),(19,'elementum nullam','nisl nunc nisl',19358.14,25,19),(20,'mauris sit','purus phasellus in',67747.51,65,20),(21,'odio cras mi','nisi volutpat',92522.87,38,21),(22,'sapien in sapien','ipsum primis',85648.78,94,22),(23,'sociis natoque penatibus','curae mauris',22224.40,16,23),(24,'nulla nisl','accumsan',36697.48,69,24),(25,'sem mauris laoreet','morbi odio',71826.93,74,25),(26,'nulla nisl','amet sem',3162.19,58,26),(27,'in leo maecenas','a pede posuere',19984.74,23,27),(28,'aenean auctor','potenti nullam porttitor',89858.83,48,28),(29,'interdum','primis in faucibus',50880.22,32,29),(30,'erat id mauris','nec',29723.10,44,30),(31,'duis','maecenas leo',98191.18,76,31),(32,'sapien sapien','habitasse platea dictumst',64576.91,36,32),(33,'lorem id ligula','mi sit amet',73029.61,46,33),(34,'viverra eget','duis',96894.62,27,34),(35,'aliquet at feugiat','orci pede venenatis',97878.30,11,35),(36,'fusce posuere','mi',99933.07,82,36),(37,'est','faucibus orci',48336.85,84,37),(38,'eget semper rutrum','pede posuere',74728.23,93,38),(39,'eleifend','venenatis',87013.86,44,39),(40,'ultrices phasellus id','a nibh',56981.26,75,40),(41,'suscipit nulla','nec',20475.39,46,41),(42,'interdum eu','dui nec nisi',85788.49,89,42),(43,'luctus et','metus aenean',35975.67,13,43),(44,'ac','duis at velit',35162.25,16,44),(45,'nonummy maecenas','ut tellus nulla',3601.22,87,45),(46,'cum','est',58191.21,94,46),(47,'nibh ligula','tempor turpis',73554.70,65,47),(48,'accumsan','luctus et ultrices',94568.03,80,48),(49,'ante vivamus tortor','in est risus',37895.09,36,49),(50,'rutrum','in sapien iaculis',80773.71,83,50),(51,'elit proin','non velit donec',45026.65,14,51),(52,'id nulla','sit amet',42671.10,67,52),(53,'risus dapibus augue','quis orci eget',25107.55,6,53),(54,'felis ut','aliquet massa id',15625.06,85,54),(55,'justo in','erat nulla tempus',32384.78,14,55),(56,'pulvinar nulla','duis',28645.35,11,56),(57,'libero nullam sit','proin',27958.27,5,57),(58,'porttitor lacus at','vestibulum ante',69547.65,50,58),(59,'vulputate vitae','eleifend quam a',56333.60,10,59),(60,'placerat','a suscipit',44600.11,44,60),(61,'a','amet',11830.65,76,61),(62,'pede morbi','risus',95556.11,50,62),(63,'eu magna vulputate','velit eu',94685.69,45,63),(64,'imperdiet sapien urna','suspendisse potenti cras',95227.00,96,64),(65,'nulla sed','in tempus',28134.96,87,65),(66,'cubilia curae mauris','proin risus praesent',22952.21,7,66),(67,'lectus vestibulum','consectetuer adipiscing elit',77405.15,80,67),(68,'enim','elit ac',36024.86,42,68),(69,'nulla quisque arcu','sed magna',79939.74,98,69),(70,'nulla','ut',11386.24,15,70),(71,'pharetra magna','elit',402.16,79,71),(72,'suscipit nulla','nulla',6119.27,100,72),(73,'lacinia','sociis natoque penatibus',8604.93,97,73),(74,'aliquet ultrices','luctus',12381.75,54,74),(75,'nam ultrices libero','vitae',51521.88,47,75),(76,'lorem id ligula','quam fringilla rhoncus',73085.31,72,76),(77,'eget tincidunt eget','tortor',54165.89,2,77),(78,'eros vestibulum','mi sit amet',62616.18,12,78),(79,'metus aenean fermentum','integer tincidunt ante',38583.06,68,79),(80,'justo nec condimentum','eleifend quam a',58738.49,95,80),(81,'porttitor pede','fermentum justo',81795.17,27,81),(82,'morbi vestibulum velit','varius',57174.58,55,82),(83,'sagittis nam congue','in hac habitasse',62737.60,81,83),(84,'justo in blandit','vestibulum',30975.93,43,84),(85,'odio cras mi','augue',96374.12,74,85),(86,'in','at feugiat',22793.87,80,86),(87,'ut dolor morbi','orci nullam',89252.32,79,87),(88,'cursus urna ut','mollis molestie',82722.99,14,88),(89,'lectus suspendisse','justo',95223.00,27,89),(90,'fringilla rhoncus','orci',94105.99,13,90),(91,'convallis','eu nibh',4769.62,92,91),(92,'diam','orci luctus',95426.40,96,92),(93,'donec','vel',26605.32,4,93),(94,'rutrum','praesent blandit',85749.72,43,94),(95,'massa quis','nulla suscipit ligula',954.60,39,95),(96,'nulla','nisl duis',4789.93,89,96),(97,'mattis pulvinar nulla','id',41546.70,28,97),(98,'lectus','platea',10065.13,37,98),(99,'lobortis sapien','auctor',97092.38,35,99),(100,'cras','vivamus tortor',79523.31,78,100);
/*!40000 ALTER TABLE `employee_fixed_compenstion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employee_personal_info`
--

DROP TABLE IF EXISTS `employee_personal_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `employee_personal_info` (
  `employee_perosnal_info_id` int NOT NULL,
  `employee_ethnic_origin` varchar(100) DEFAULT NULL,
  `employee_native_language` varchar(100) DEFAULT NULL,
  `employee_veteran_status` tinyint(1) DEFAULT NULL,
  `employee_id` int NOT NULL,
  PRIMARY KEY (`employee_perosnal_info_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employee_personal_info`
--

LOCK TABLES `employee_personal_info` WRITE;
/*!40000 ALTER TABLE `employee_personal_info` DISABLE KEYS */;
INSERT INTO `employee_personal_info` VALUES (1,'urna pretium nisl','Greek',1,79),(2,'in faucibus orci','Tsonga',1,24),(3,'at velit','Malayalam',1,18),(4,'morbi','Quechua',0,65),(5,'suspendisse accumsan tortor','Kashmiri',0,3),(6,'aliquet massa id','Kazakh',1,49),(7,'quis libero nullam','Moldovan',0,41),(8,'lacus curabitur','Malayalam',0,34),(9,'vestibulum aliquet','Maltese',0,100),(10,'sed augue aliquam','Hindi',1,54),(11,'libero non','Swahili',1,59),(12,'cras non velit','Sotho',0,52),(13,'elit','Kazakh',0,65),(14,'fermentum','Japanese',0,84),(15,'augue vel','West Frisian',0,10),(16,'mollis molestie lorem','Catalan',0,83),(17,'nulla nisl nunc','Albanian',0,17),(18,'sodales','Italian',0,3),(19,'turpis eget elit','Spanish',1,26),(20,'hac','Tsonga',1,57),(21,'sit amet consectetuer','Punjabi',1,72),(22,'nunc donec','Czech',0,99),(23,'suspendisse potenti in','Khmer',1,13),(24,'sit','Dhivehi',0,59),(25,'amet diam','Czech',0,47),(26,'risus dapibus augue','Gujarati',0,76),(27,'etiam faucibus cursus','Belarusian',1,60),(28,'iaculis congue','Romanian',0,69),(29,'fusce posuere felis','Danish',1,73),(30,'quam','Arabic',1,93),(31,'semper est','Papiamento',0,52),(32,'ultrices libero','New Zealand Sign Language',1,40),(33,'sit amet sem','Czech',1,19),(34,'aliquet','German',0,100),(35,'justo morbi ut','Catalan',1,16),(36,'nibh','Latvian',0,86),(37,'nulla mollis molestie','Assamese',0,42),(38,'in','Bislama',0,82),(39,'suspendisse potenti','Bulgarian',0,66),(40,'integer non velit','Hiri Motu',1,9),(41,'justo','English',0,14),(42,'vestibulum proin eu','Croatian',0,62),(43,'blandit ultrices','Tetum',0,58),(44,'ligula','Gujarati',0,91),(45,'porta volutpat quam','Quechua',1,99),(46,'venenatis turpis','Gujarati',1,100),(47,'quam','Thai',1,31),(48,'suspendisse potenti cras','Zulu',0,52),(49,'massa donec','New Zealand Sign Language',1,2),(50,'nunc viverra dapibus','Afrikaans',1,84),(51,'nulla elit ac','Romanian',1,48),(52,'tincidunt lacus','New Zealand Sign Language',1,41),(53,'vulputate','Afrikaans',0,75),(54,'duis bibendum felis','Norwegian',1,67),(55,'ut erat curabitur','Kannada',1,87),(56,'at','Kurdish',1,22),(57,'a','Belarusian',0,51),(58,'penatibus','Irish Gaelic',1,97),(59,'faucibus orci luctus','Albanian',0,75),(60,'orci luctus et','Greek',1,48),(61,'risus auctor','Burmese',1,63),(62,'diam','Thai',0,25),(63,'sapien','English',1,72),(64,'faucibus cursus','Irish Gaelic',1,5),(65,'condimentum neque','Haitian Creole',1,66),(66,'facilisi cras','Yiddish',1,39),(67,'in','Aymara',1,4),(68,'nam tristique tortor','Kashmiri',1,33),(69,'ac leo','M?ori',0,95),(70,'elit','Irish Gaelic',0,46),(71,'congue vivamus','Polish',0,36),(72,'commodo vulputate justo','Japanese',1,25),(73,'in ante','Malayalam',0,32),(74,'donec','Papiamento',1,5),(75,'orci','Swati',0,37),(76,'eros','Czech',0,24),(77,'in felis','Gujarati',0,20),(78,'lacinia eget','Finnish',0,22),(79,'viverra diam vitae','Icelandic',0,5),(80,'erat curabitur','Filipino',0,64),(81,'nunc donec quis','Persian',1,66),(82,'justo maecenas rhoncus','Luxembourgish',1,5),(83,'non velit','Azeri',1,98),(84,'felis eu sapien','Georgian',1,38),(85,'sed','Punjabi',1,43),(86,'vel enim sit','Gujarati',1,42),(87,'odio','Burmese',1,58),(88,'porttitor','Italian',0,64),(89,'augue','Afrikaans',0,85),(90,'cursus','Croatian',0,18),(91,'duis consequat dui','Bengali',1,68),(92,'suscipit','Norwegian',0,60),(93,'justo lacinia','Sotho',0,32),(94,'ipsum dolor sit','Greek',1,47),(95,'dis parturient','New Zealand Sign Language',0,65),(96,'at lorem integer','Armenian',1,60),(97,'non quam','Oriya',1,87),(98,'curae donec pharetra','Luxembourgish',0,43),(99,'lectus pellentesque','Oriya',0,49),(100,'cum sociis natoque','Sotho',0,1);
/*!40000 ALTER TABLE `employee_personal_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employees`
--

DROP TABLE IF EXISTS `employees`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `employees` (
  `employee_id` int unsigned NOT NULL,
  `employee_firstname` char(100) DEFAULT NULL,
  `employee_lastname` char(100) DEFAULT NULL,
  `employee_dob` date DEFAULT NULL,
  `employee_gender` varchar(100) DEFAULT NULL,
  `employee_contact_number` varchar(15) DEFAULT NULL,
  `employee_id_card_no` varchar(20) DEFAULT NULL,
  `employee_emergency_contact_name` char(100) DEFAULT NULL,
  `employee_emergency_contact_number` varchar(100) DEFAULT NULL,
  `employee_status` bit(1) DEFAULT NULL,
  `employee_employment_type` varchar(100) DEFAULT NULL,
  `employee_department` int NOT NULL,
  `employee_position` int NOT NULL,
  `employee_hire_date` date NOT NULL,
  `employee_termination_date` date DEFAULT NULL,
  `employee_employment_status` int NOT NULL,
  `employee_manager` int DEFAULT NULL,
  `employee_salary_info` int NOT NULL,
  `employee_benefits` int NOT NULL,
  `employee_skills_qualifications` blob,
  PRIMARY KEY (`employee_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employees`
--

LOCK TABLES `employees` WRITE;
/*!40000 ALTER TABLE `employees` DISABLE KEYS */;
/*!40000 ALTER TABLE `employees` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `interview_note`
--

DROP TABLE IF EXISTS `interview_note`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `interview_note` (
  `interview_note_id` int unsigned NOT NULL,
  `applicant_id` int unsigned NOT NULL,
  `notes` longtext,
  `interview_id` int NOT NULL,
  `interviewer_notes` blob,
  `interview_score` int NOT NULL,
  `interviewer_id` int unsigned NOT NULL,
  PRIMARY KEY (`interview_note_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `interview_note`
--

LOCK TABLES `interview_note` WRITE;
/*!40000 ALTER TABLE `interview_note` DISABLE KEYS */;
/*!40000 ALTER TABLE `interview_note` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `interviewers`
--

DROP TABLE IF EXISTS `interviewers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `interviewers` (
  `interviewer_id` int unsigned NOT NULL,
  `interviewer_fname` char(100) DEFAULT NULL,
  `interviewer_lname` char(100) DEFAULT NULL,
  PRIMARY KEY (`interviewer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `interviewers`
--

LOCK TABLES `interviewers` WRITE;
/*!40000 ALTER TABLE `interviewers` DISABLE KEYS */;
INSERT INTO `interviewers` VALUES (1,'Elena','Lamshead'),(2,'Krispin','Stonham'),(3,'Felicle','Caiger'),(4,'Dulcie','Rehm'),(5,'Belicia','Gaine'),(6,'Roosevelt','Parlott'),(7,'Chere','Le Guin'),(8,'Brennan','Birkin'),(9,'Lina','Daysh'),(10,'Jakob','Di Biagi'),(11,'Elva','Bleas'),(12,'Alaster','Huey'),(13,'Phineas','Copeland'),(14,'Curtis','Bewley'),(15,'Suki','Eastway'),(16,'Morgan','Manske'),(17,'Farley','Marris'),(18,'Abdel','Jump'),(19,'Rochella','Iowarch'),(20,'Eben','Stoyles'),(21,'Pris','Wickson'),(22,'Lyman','Walford'),(23,'Pammy','Pynner'),(24,'Osborn','Cleary'),(25,'Rock','Necolds'),(26,'Reidar','Aberkirdo'),(27,'Vinny','Caw'),(28,'Alonso','Klaffs'),(29,'Lucky','Peacher'),(30,'Cathryn','Treker'),(31,'Harp','Olekhov'),(32,'Flo','Kolak'),(33,'Jakie','Rivaland'),(34,'Paddy','Grimley'),(35,'Igor','Phipson'),(36,'Kalil','Vesque'),(37,'Godfrey','Diben'),(38,'Jessie','Matanin'),(39,'Nanny','Cosans'),(40,'Whit','Attenborrow'),(41,'Keary','Christy'),(42,'Forbes','Tack'),(43,'Bondy','Ellerton'),(44,'Donetta','Jeffries'),(45,'Inge','Gecke'),(46,'Ugo','Tebbitt'),(47,'Meridel','Baudry'),(48,'Greggory','Prestney'),(49,'Kelsi','Teenan'),(50,'Wait','Higgan'),(51,'Carmon','Currm'),(52,'Burch','Bertelmot'),(53,'Sawyere','Nobriga'),(54,'Mela','Selman'),(55,'Kirby','McNickle'),(56,'Joelie','Garcia'),(57,'Hollyanne','Gonet'),(58,'Sumner','Domegan'),(59,'Ardelia','Showt'),(60,'Haleigh','Asbrey'),(61,'Arline','Quilter'),(62,'Bamby','Pagden'),(63,'Susi','Marklow'),(64,'Bil','Wingate'),(65,'Lauritz','McKechnie'),(66,'Twyla','Devine'),(67,'Tiffi','Bloschke'),(68,'Hazlett','Graeser'),(69,'Madelle','Warrener'),(70,'Munroe','Kiddye'),(71,'Bellina','Dagleas'),(72,'Aarika','Pfeiffer'),(73,'Bryan','Nekrews'),(74,'Netta','Smiths'),(75,'Desiri','Ewbach'),(76,'Jory','Ianno'),(77,'Sebastiano','Mapplebeck'),(78,'Andres','Este'),(79,'Nadean','Flamank'),(80,'Veronike','Bodleigh'),(81,'Skipper','Donizeau'),(82,'Nonah','McGarvey'),(83,'Titos','Derham'),(84,'Teressa','Alebrooke'),(85,'Hannie','Schober'),(86,'Eimile','Jiran'),(87,'Roxi','Minchinden'),(88,'Opaline','Norman'),(89,'Gerianne','Hamerton'),(90,'Ulla','Peplow'),(91,'Kendell','Cowterd'),(92,'Nat','Pandey'),(93,'Charlean','Cundey'),(94,'Mignonne','Gouldstone'),(95,'Josias','Pescud'),(96,'Bobbe','Ewols'),(97,'Curtis','McFarland'),(98,'Dorry','Aers'),(99,'Stafford','McQuorkel'),(100,'Rikki','Chauvey');
/*!40000 ALTER TABLE `interviewers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `interviews`
--

DROP TABLE IF EXISTS `interviews`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `interviews` (
  `interview_id` int unsigned NOT NULL,
  `applicant_id` int unsigned NOT NULL,
  `interviewer_id` int unsigned NOT NULL,
  `interview_date` date DEFAULT NULL,
  `interview_time` time DEFAULT NULL,
  PRIMARY KEY (`interview_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `interviews`
--

LOCK TABLES `interviews` WRITE;
/*!40000 ALTER TABLE `interviews` DISABLE KEYS */;
/*!40000 ALTER TABLE `interviews` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_position_task_list`
--

DROP TABLE IF EXISTS `job_position_task_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `job_position_task_list` (
  `job_position_task_list_id` int unsigned NOT NULL,
  `task_description` blob,
  `job_position_id` int unsigned NOT NULL,
  `task_location` varchar(1000) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `task_department_id` int unsigned NOT NULL,
  PRIMARY KEY (`job_position_task_list_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_position_task_list`
--

LOCK TABLES `job_position_task_list` WRITE;
/*!40000 ALTER TABLE `job_position_task_list` DISABLE KEYS */;
/*!40000 ALTER TABLE `job_position_task_list` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_positions`
--

DROP TABLE IF EXISTS `job_positions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `job_positions` (
  `job_position_id` int unsigned NOT NULL,
  `department_id` int unsigned NOT NULL,
  `job_id` int unsigned NOT NULL,
  `position_requirements` blob,
  `position_benefits` text,
  PRIMARY KEY (`job_position_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_positions`
--

LOCK TABLES `job_positions` WRITE;
/*!40000 ALTER TABLE `job_positions` DISABLE KEYS */;
INSERT INTO `job_positions` VALUES (1,1,1,_binary 'nulla suscipit ligula','sit amet consectetuer adipiscing elit'),(2,2,2,_binary 'convallis nulla neque','amet erat nulla tempus'),(3,3,3,_binary 'dictumst aliquam augue','erat nulla tempus vivamus'),(4,4,4,_binary 'lacinia nisi venenatis tristique','purus aliquet at feugiat non'),(5,5,5,_binary 'nulla nunc purus','quis justo maecenas rhoncus aliquam'),(6,6,6,_binary 'orci luctus et ultrices','massa quis augue luctus'),(7,7,7,_binary 'nulla pede ullamcorper augue a','augue vel accumsan'),(8,8,8,_binary 'ac est lacinia nisi','rutrum ac lobortis vel dapibus'),(9,9,9,_binary 'morbi non quam nec dui','in imperdiet et commodo vulputate'),(10,10,10,_binary 'nisl venenatis lacinia','vel sem sed sagittis nam'),(11,11,11,_binary 'phasellus sit amet erat nulla','congue diam id ornare'),(12,12,12,_binary 'aenean lectus pellentesque eget nunc','ipsum praesent blandit lacinia'),(13,13,13,_binary 'mattis egestas metus aenean fermentum','erat volutpat in congue etiam'),(14,14,14,_binary 'vulputate luctus cum','sit amet consectetuer adipiscing'),(15,15,15,_binary 'orci mauris lacinia','aliquam sit amet diam in'),(16,16,16,_binary 'in sagittis dui vel','lectus in quam fringilla rhoncus'),(17,17,17,_binary 'non mattis pulvinar nulla','vestibulum ante ipsum primis in'),(18,18,18,_binary 'nunc donec quis','sed vestibulum sit amet'),(19,19,19,_binary 'pede posuere nonummy','amet cursus id'),(20,20,20,_binary 'platea dictumst aliquam','molestie hendrerit at vulputate'),(21,21,21,_binary 'vestibulum ante ipsum','at ipsum ac tellus semper'),(22,22,22,_binary 'est congue elementum in','ut nulla sed accumsan felis'),(23,23,23,_binary 'id mauris vulputate elementum','aliquet pulvinar sed'),(24,24,24,_binary 'semper sapien a libero nam','aenean lectus pellentesque eget nunc'),(25,25,25,_binary 'eu massa donec dapibus duis','mauris lacinia sapien quis libero'),(26,26,26,_binary 'magna at nunc commodo placerat','nulla dapibus dolor'),(27,27,27,_binary 'duis faucibus accumsan','ipsum dolor sit amet'),(28,28,28,_binary 'morbi vestibulum velit id','turpis nec euismod scelerisque'),(29,29,29,_binary 'ut dolor morbi','condimentum id luctus nec'),(30,30,30,_binary 'lorem vitae mattis nibh ligula','etiam faucibus cursus'),(31,31,31,_binary 'ut massa quis','volutpat dui maecenas'),(32,32,32,_binary 'hac habitasse platea dictumst','tortor quis turpis'),(33,33,33,_binary 'at lorem integer','amet nulla quisque'),(34,34,34,_binary 'est quam pharetra','at diam nam'),(35,35,35,_binary 'morbi porttitor lorem','ut nulla sed accumsan'),(36,36,36,_binary 'dolor sit amet consectetuer','ante vivamus tortor duis'),(37,37,37,_binary 'varius integer ac leo pellentesque','ac tellus semper interdum'),(38,38,38,_binary 'nisl nunc rhoncus','quam suspendisse potenti'),(39,39,39,_binary 'non velit donec diam','phasellus sit amet'),(40,40,40,_binary 'suspendisse potenti cras in purus','purus sit amet nulla quisque'),(41,41,41,_binary 'maecenas tincidunt lacus','porttitor lorem id'),(42,42,42,_binary 'rutrum rutrum neque aenean','quisque erat eros'),(43,43,43,_binary 'habitasse platea dictumst aliquam augue','a pede posuere nonummy'),(44,44,44,_binary 'urna pretium nisl','nulla tempus vivamus in felis'),(45,45,45,_binary 'amet eleifend pede libero quis','eu felis fusce'),(46,46,46,_binary 'posuere cubilia curae nulla dapibus','tempus vivamus in felis'),(47,47,47,_binary 'cum sociis natoque penatibus et','semper sapien a libero nam'),(48,48,48,_binary 'platea dictumst aliquam','lectus vestibulum quam sapien'),(49,49,49,_binary 'quam pede lobortis ligula sit','nullam orci pede venenatis'),(50,50,50,_binary 'ultrices posuere cubilia curae mauris','nisl nunc nisl'),(51,51,51,_binary 'ac lobortis vel dapibus at','congue eget semper rutrum'),(52,52,52,_binary 'ullamcorper purus sit','ante nulla justo'),(53,53,53,_binary 'gravida sem praesent id','ultrices posuere cubilia curae nulla'),(54,54,54,_binary 'interdum eu tincidunt in','sociis natoque penatibus et'),(55,55,55,_binary 'ultrices libero non','aenean lectus pellentesque'),(56,56,56,_binary 'mauris laoreet ut','duis bibendum felis sed'),(57,57,57,_binary 'aliquet at feugiat','mauris lacinia sapien'),(58,58,58,_binary 'volutpat in congue','luctus et ultrices posuere'),(59,59,59,_binary 'aliquet massa id lobortis convallis','curabitur gravida nisi'),(60,60,60,_binary 'ut dolor morbi vel','odio porttitor id consequat in'),(61,61,61,_binary 'nisi nam ultrices libero non','ac leo pellentesque'),(62,62,62,_binary 'fringilla rhoncus mauris enim','bibendum imperdiet nullam'),(63,63,63,_binary 'donec quis orci eget','in sagittis dui vel nisl'),(64,64,64,_binary 'augue aliquam erat volutpat','potenti in eleifend quam a'),(65,65,65,_binary 'pretium quis lectus suspendisse potenti','sed magna at nunc commodo'),(66,66,66,_binary 'bibendum morbi non quam','nisi vulputate nonummy'),(67,67,67,_binary 'sem duis aliquam','cras pellentesque volutpat dui maecenas'),(68,68,68,_binary 'lacus morbi quis tortor id','duis bibendum felis sed'),(69,69,69,_binary 'odio odio elementum eu','nulla ac enim in'),(70,70,70,_binary 'sapien cursus vestibulum','donec ut dolor morbi'),(71,71,71,_binary 'vestibulum ac est','eget semper rutrum nulla nunc'),(72,72,72,_binary 'enim in tempor turpis','est et tempus semper est'),(73,73,73,_binary 'orci vehicula condimentum','vestibulum ante ipsum'),(74,74,74,_binary 'curabitur gravida nisi at','suscipit ligula in'),(75,75,75,_binary 'odio justo sollicitudin ut suscipit','sollicitudin mi sit amet'),(76,76,76,_binary 'laoreet ut rhoncus aliquet pulvinar','sociis natoque penatibus et magnis'),(77,77,77,_binary 'commodo placerat praesent','in leo maecenas pulvinar lobortis'),(78,78,78,_binary 'congue etiam justo etiam pretium','diam vitae quam suspendisse potenti'),(79,79,79,_binary 'sollicitudin vitae consectetuer','pretium iaculis diam erat fermentum'),(80,80,80,_binary 'ultrices enim lorem ipsum','nunc viverra dapibus nulla suscipit'),(81,81,81,_binary 'ullamcorper purus sit','lacinia aenean sit amet'),(82,82,82,_binary 'vulputate nonummy maecenas tincidunt lacus','luctus nec molestie'),(83,83,83,_binary 'tempus vel pede morbi','eget orci vehicula condimentum'),(84,84,84,_binary 'mattis egestas metus','tristique fusce congue diam id'),(85,85,85,_binary 'sit amet lobortis sapien sapien','porta volutpat erat quisque erat'),(86,86,86,_binary 'ut dolor morbi vel lectus','orci luctus et ultrices'),(87,87,87,_binary 'nibh in lectus','eget nunc donec quis orci'),(88,88,88,_binary 'primis in faucibus orci luctus','rutrum at lorem integer'),(89,89,89,_binary 'nisi eu orci mauris','quis justo maecenas'),(90,90,90,_binary 'non mattis pulvinar','accumsan felis ut at dolor'),(91,91,91,_binary 'lacus curabitur at ipsum ac','volutpat sapien arcu'),(92,92,92,_binary 'quis lectus suspendisse potenti in','nibh in lectus pellentesque at'),(93,93,93,_binary 'sed vestibulum sit amet cursus','tempor turpis nec'),(94,94,94,_binary 'enim sit amet nunc','dolor sit amet'),(95,95,95,_binary 'donec quis orci','scelerisque mauris sit'),(96,96,96,_binary 'quam sollicitudin vitae','ultrices mattis odio donec vitae'),(97,97,97,_binary 'sapien in sapien','congue eget semper rutrum nulla'),(98,98,98,_binary 'at feugiat non pretium quis','libero quis orci nullam'),(99,99,99,_binary 'faucibus orci luctus et','maecenas rhoncus aliquam'),(100,100,100,_binary 'eleifend luctus ultricies','vel enim sit');
/*!40000 ALTER TABLE `job_positions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_type`
--

DROP TABLE IF EXISTS `job_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `job_type` (
  `job_type_id` int unsigned NOT NULL,
  `job_type_name` varchar(100) DEFAULT NULL,
  `job_type_rules` text NOT NULL,
  PRIMARY KEY (`job_type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_type`
--

LOCK TABLES `job_type` WRITE;
/*!40000 ALTER TABLE `job_type` DISABLE KEYS */;
INSERT INTO `job_type` VALUES (1,'Training','12'),(2,'Business Development','21'),(3,'Legal','7'),(4,'Marketing','30'),(5,'Business Development','18'),(6,'Business Development','11'),(7,'Research and Development','22'),(8,'Services','22'),(9,'Sales','9'),(10,'Sales','17'),(11,'Sales','16'),(12,'Services','1'),(13,'Training','21'),(14,'Business Development','24'),(15,'Support','22'),(16,'Accounting','19'),(17,'Marketing','29'),(18,'Sales','30'),(19,'Research and Development','15'),(20,'Marketing','11'),(21,'Marketing','1'),(22,'Services','1'),(23,'Accounting','9'),(24,'Support','10'),(25,'Product Management','3'),(26,'Marketing','22'),(27,'Engineering','1'),(28,'Accounting','17'),(29,'Sales','8'),(30,'Accounting','8');
/*!40000 ALTER TABLE `job_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_vacancies`
--

DROP TABLE IF EXISTS `job_vacancies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `job_vacancies` (
  `job_vacancies_id` int unsigned NOT NULL,
  `job_position_id` int unsigned NOT NULL,
  `job_description` text,
  `date_published` date DEFAULT NULL,
  `date_close` date DEFAULT NULL,
  `job_vacancy_department` int NOT NULL,
  `job vacancy skills qualifications` tinyint(1) DEFAULT NULL,
  `no_vacancies` int NOT NULL,
  PRIMARY KEY (`job_vacancies_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_vacancies`
--

LOCK TABLES `job_vacancies` WRITE;
/*!40000 ALTER TABLE `job_vacancies` DISABLE KEYS */;
INSERT INTO `job_vacancies` VALUES (1,1,'vestibulum sagittis sapien cum','2023-06-28','2023-07-13',54,0,55),(2,2,'nulla dapibus dolor vel','2023-03-28','2023-05-21',16,1,87),(3,3,'habitasse platea dictumst maecenas ut','2023-04-02','2023-11-15',13,1,27),(4,4,'quam pharetra magna','2023-01-25','2023-07-05',45,0,82),(5,5,'amet cursus id turpis','2023-04-16','2023-09-08',59,1,36),(6,6,'non velit donec','2023-06-17','2023-08-20',63,1,44),(7,7,'quis turpis sed ante vivamus','2023-03-01','2023-12-23',49,0,98),(8,8,'in purus eu magna vulputate','2023-02-21','2023-10-29',98,1,37),(9,9,'penatibus et magnis','2023-03-07','2023-03-02',68,0,31),(10,10,'augue luctus tincidunt nulla','2023-06-03','2023-07-17',68,0,56),(11,11,'non mattis pulvinar nulla','2023-01-27','2023-04-12',49,1,29),(12,12,'urna pretium nisl','2023-06-23','2023-11-09',11,1,90),(13,13,'sapien arcu sed','2023-04-09','2023-11-03',99,0,79),(14,14,'ut massa volutpat','2023-05-13','2023-06-20',78,0,89),(15,15,'cubilia curae duis faucibus accumsan','2023-02-27','2023-02-07',4,0,1),(16,16,'morbi porttitor lorem','2023-01-07','2023-06-03',48,0,63),(17,17,'nunc purus phasellus in','2023-06-07','2023-11-12',2,0,18),(18,18,'eget tempus vel pede','2023-03-13','2023-08-23',38,1,3),(19,19,'tincidunt nulla mollis molestie lorem','2023-04-16','2023-10-04',54,1,59),(20,20,'donec semper sapien a','2023-04-20','2023-06-08',24,1,67),(21,21,'nulla tellus in','2023-05-14','2023-04-24',43,1,86),(22,22,'curae donec pharetra','2023-06-15','2023-08-07',7,1,60),(23,23,'interdum in ante vestibulum','2023-05-17','2023-07-05',75,0,84),(24,24,'nulla eget eros elementum pellentesque','2023-06-05','2023-08-31',24,1,92),(25,25,'curae mauris viverra','2023-03-01','2023-08-15',39,0,96),(26,26,'risus auctor sed tristique in','2023-06-07','2023-12-18',60,1,62),(27,27,'tempus semper est','2023-06-17','2023-05-15',99,0,43),(28,28,'semper rutrum nulla nunc purus','2023-02-26','2023-11-14',62,0,55),(29,29,'condimentum curabitur in libero','2023-01-10','2023-06-28',32,0,88),(30,30,'urna pretium nisl','2023-03-31','2023-05-23',30,1,28),(31,31,'mauris laoreet ut rhoncus aliquet','2023-03-29','2023-02-18',80,1,47),(32,32,'donec pharetra magna','2023-05-20','2023-04-09',66,0,65),(33,33,'id sapien in sapien iaculis','2023-02-24','2023-02-03',70,0,79),(34,34,'nisi venenatis tristique fusce congue','2023-03-19','2023-11-14',60,0,70),(35,35,'placerat praesent blandit nam','2023-05-30','2023-04-18',33,0,14),(36,36,'duis mattis egestas metus aenean','2023-01-25','2023-04-29',60,1,1),(37,37,'ac nibh fusce lacus purus','2023-04-12','2023-07-15',49,0,39),(38,38,'quam pharetra magna','2023-01-24','2023-04-23',35,1,98),(39,39,'eu tincidunt in','2023-01-05','2023-01-20',43,1,17),(40,40,'habitasse platea dictumst maecenas','2023-02-12','2023-04-10',24,1,91),(41,41,'est lacinia nisi','2023-03-22','2023-01-24',8,0,10),(42,42,'luctus et ultrices','2023-05-10','2023-08-17',19,1,77),(43,43,'velit vivamus vel nulla eget','2023-02-05','2023-04-07',95,0,76),(44,44,'aliquam quis turpis eget elit','2023-03-21','2023-09-24',93,0,33),(45,45,'id mauris vulputate elementum nullam','2023-02-22','2023-09-16',68,0,37),(46,46,'mauris laoreet ut rhoncus','2023-05-12','2023-10-23',49,1,76),(47,47,'primis in faucibus','2023-06-16','2023-06-23',47,1,99),(48,48,'sapien dignissim vestibulum','2023-02-25','2023-12-28',57,0,83),(49,49,'duis faucibus accumsan odio','2023-03-25','2023-07-24',15,0,81),(50,50,'nulla sed accumsan felis','2023-01-06','2023-05-31',50,1,94),(51,51,'blandit nam nulla integer','2023-06-10','2023-06-21',19,1,31),(52,52,'accumsan tortor quis','2023-06-23','2023-11-30',54,1,29),(53,53,'tempus vel pede morbi','2023-02-26','2023-06-23',40,1,19),(54,54,'odio donec vitae nisi','2023-02-19','2023-08-08',28,1,65),(55,55,'leo pellentesque ultrices mattis','2023-06-10','2023-02-21',12,0,98),(56,56,'nullam varius nulla','2023-02-17','2023-05-28',45,1,54),(57,57,'habitasse platea dictumst aliquam augue','2023-03-15','2023-01-21',29,0,41),(58,58,'commodo vulputate justo in','2023-03-05','2023-07-07',100,1,52),(59,59,'duis bibendum felis sed interdum','2023-04-02','2023-07-23',63,1,24),(60,60,'integer a nibh','2023-02-06','2023-02-13',65,0,30),(61,61,'sem sed sagittis nam congue','2023-04-01','2023-11-20',59,0,4),(62,62,'pellentesque eget nunc donec','2023-04-06','2023-04-04',80,0,72),(63,63,'libero nullam sit','2023-03-01','2023-06-23',22,1,62),(64,64,'velit donec diam neque vestibulum','2023-04-24','2023-08-12',87,0,30),(65,65,'sed nisl nunc rhoncus','2023-06-01','2023-10-13',35,0,39),(66,66,'fusce consequat nulla','2023-06-12','2023-03-12',94,0,66),(67,67,'bibendum morbi non','2023-06-12','2023-10-06',22,1,26),(68,68,'blandit ultrices enim lorem','2023-06-13','2023-09-23',24,1,39),(69,69,'quam pharetra magna ac','2023-05-24','2023-05-14',46,0,88),(70,70,'non pretium quis lectus','2023-02-26','2023-12-14',50,0,29),(71,71,'suspendisse ornare consequat lectus','2023-05-19','2023-11-20',99,1,65),(72,72,'mollis molestie lorem quisque','2023-02-23','2023-08-16',6,1,66),(73,73,'ante ipsum primis in faucibus','2023-04-13','2023-12-05',20,1,56),(74,74,'est risus auctor sed','2023-06-24','2023-10-13',94,0,51),(75,75,'justo in hac','2023-06-20','2023-01-24',13,1,25),(76,76,'pretium quis lectus','2023-05-30','2023-10-29',16,1,70),(77,77,'nulla suscipit ligula in lacus','2023-03-28','2023-10-05',79,0,9),(78,78,'curae duis faucibus','2023-04-02','2023-02-01',5,0,21),(79,79,'nisi vulputate nonummy','2023-04-03','2023-11-07',90,0,45),(80,80,'nibh ligula nec sem','2023-01-20','2023-06-09',48,0,95),(81,81,'est congue elementum in','2023-03-25','2023-06-20',17,1,92),(82,82,'vestibulum ante ipsum primis in','2023-04-25','2023-11-17',98,1,79),(83,83,'vestibulum sagittis sapien cum','2023-03-16','2023-05-18',43,0,90),(84,84,'donec ut mauris eget massa','2023-06-14','2023-07-16',22,1,20),(85,85,'pulvinar lobortis est phasellus sit','2023-01-28','2023-10-14',60,1,31),(86,86,'in ante vestibulum ante ipsum','2023-01-15','2023-07-31',21,0,75),(87,87,'vestibulum sagittis sapien cum','2023-01-25','2023-02-16',13,1,2),(88,88,'risus praesent lectus vestibulum quam','2023-06-13','2023-02-26',9,0,82),(89,89,'odio odio elementum eu','2023-04-28','2023-01-08',52,0,6),(90,90,'hendrerit at vulputate vitae nisl','2023-05-15','2023-08-25',66,1,62),(91,91,'aliquam sit amet diam','2023-02-17','2023-05-31',90,0,98),(92,92,'a odio in hac habitasse','2023-01-31','2023-08-07',65,1,65),(93,93,'vel ipsum praesent','2023-03-10','2023-06-28',29,1,58),(94,94,'eget congue eget semper','2023-04-22','2023-11-17',61,0,73),(95,95,'consequat ut nulla','2023-06-07','2023-03-13',10,0,56),(96,96,'sed magna at nunc commodo','2023-01-12','2023-12-10',9,0,14),(97,97,'montes nascetur ridiculus','2023-04-02','2023-10-11',44,0,57),(98,98,'vestibulum ante ipsum primis in','2023-06-25','2023-03-13',19,0,29),(99,99,'cursus id turpis integer aliquet','2023-05-09','2023-07-31',63,0,75),(100,100,'elementum in hac habitasse','2023-02-26','2023-05-05',95,0,98);
/*!40000 ALTER TABLE `job_vacancies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jobs`
--

DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `jobs` (
  `job_id` int unsigned NOT NULL,
  `job_function` text,
  `job_type_id` int unsigned NOT NULL,
  PRIMARY KEY (`job_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jobs`
--

LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
INSERT INTO `jobs` VALUES (1,'vestibulum',1),(2,'cubilia curae',2),(3,'duis',3),(4,'fusce congue diam',4),(5,'non mauris morbi',5),(6,'molestie nibh in',6),(7,'porttitor id',7),(8,'dapibus at',8),(9,'quam sapien',9),(10,'vestibulum',10),(11,'sed tristique in',11),(12,'ultrices posuere',12),(13,'dui',13),(14,'in faucibus orci',14),(15,'velit vivamus',15),(16,'quisque porta volutpat',16),(17,'mauris viverra diam',17),(18,'vehicula condimentum',18),(19,'nisi vulputate',19),(20,'ligula nec sem',20),(21,'convallis tortor risus',21),(22,'penatibus et magnis',22),(23,'ut',23),(24,'pellentesque at',24),(25,'nisl duis ac',25),(26,'fusce congue diam',26),(27,'at velit vivamus',27),(28,'mauris laoreet ut',28),(29,'suspendisse accumsan tortor',29),(30,'ultrices',30);
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `leave_requests`
--

DROP TABLE IF EXISTS `leave_requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `leave_requests` (
  `leave_id` int unsigned NOT NULL,
  `employee_id` int unsigned NOT NULL,
  `leave_type_id` int unsigned NOT NULL,
  `leave_start_date` date DEFAULT NULL,
  `leave_end_date` date DEFAULT NULL,
  `leave_duration` int DEFAULT NULL,
  `leave_request_status` varchar(100) DEFAULT NULL,
  `leave_comment` text,
  PRIMARY KEY (`leave_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `leave_requests`
--

LOCK TABLES `leave_requests` WRITE;
/*!40000 ALTER TABLE `leave_requests` DISABLE KEYS */;
/*!40000 ALTER TABLE `leave_requests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `leave_type`
--

DROP TABLE IF EXISTS `leave_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `leave_type` (
  `leave_type_id` int unsigned NOT NULL,
  `leave_type_name` varchar(100) DEFAULT NULL,
  `leave_type_rules` text,
  PRIMARY KEY (`leave_type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `leave_type`
--

LOCK TABLES `leave_type` WRITE;
/*!40000 ALTER TABLE `leave_type` DISABLE KEYS */;
INSERT INTO `leave_type` VALUES (1,'Hannah Jakucewicz','proin'),(2,'Erie Kief','in'),(3,'Raddie Hubner','nonummy maecenas tincidunt'),(4,'Hilarius Dahler','venenatis non'),(5,'Kalina Grzelewski','eget'),(6,'Sari Kenafaque','nam'),(7,'Wileen Featonby','neque'),(8,'Iggy Klein','quis'),(9,'Thekla Roz','arcu adipiscing molestie'),(10,'Francine Dallman','primis in faucibus'),(11,'Germana Kilban','odio donec'),(12,'Stephannie Uebel','nulla'),(13,'Lura Mac Giolla Pheadair','dolor'),(14,'Winna Capnerhurst','congue vivamus'),(15,'Claiborne Blunn','morbi'),(16,'Chadwick Wetherick','rhoncus mauris'),(17,'Nisse Mandeville','vivamus'),(18,'Thomasina Sandford','quis orci'),(19,'Bonnie Gentle','amet'),(20,'Bambie Giovannoni','dapibus nulla'),(21,'Taylor Knowlden','justo lacinia eget'),(22,'Egon Leist','id ligula suspendisse'),(23,'Roobbie Nicklinson','nullam porttitor'),(24,'Gunar Allbut','pulvinar sed nisl'),(25,'Brit Advani','non lectus'),(26,'Dal Perelli','tellus nisi'),(27,'Heida Chang','sollicitudin'),(28,'Cecilia Cordle','nulla quisque'),(29,'Rudie Youngs','pulvinar nulla pede'),(30,'Erskine Dear','elementum pellentesque quisque'),(31,'Jamil Garman','mauris'),(32,'Kin Denzilow','orci vehicula condimentum'),(33,'Margi Parbrook','primis'),(34,'Rozella Lounds','interdum mauris'),(35,'Rita Sayward','lacinia sapien'),(36,'Ansley Bowyer','felis eu'),(37,'Kris Veschambre','vestibulum sagittis sapien'),(38,'Leonardo Kermott','viverra'),(39,'Aindrea Samet','luctus'),(40,'Denny Mogey','eu tincidunt in'),(41,'Erhard Just','fusce lacus'),(42,'Astra Faudrie','tortor duis'),(43,'Carolyn Altimas','libero quis'),(44,'Brannon Billingsly','justo'),(45,'Cordell Macrow','imperdiet sapien'),(46,'Lin Cogan','ipsum dolor'),(47,'Phyllida Collcott','lobortis'),(48,'Barth Sambals','iaculis'),(49,'Mabelle Malimoe','eget nunc donec'),(50,'Alvy Sprason','quam suspendisse'),(51,'Ric Iggalden','velit eu est'),(52,'Amery Goodyear','massa'),(53,'Christophorus Kirckman','sed'),(54,'Barnabe Spurgin','donec diam'),(55,'Sarina Stebles','amet'),(56,'Corinna Alpe','vitae quam suspendisse'),(57,'Suellen Mugford','vulputate elementum'),(58,'Jessee Dilks','ultrices'),(59,'Pierette Macvain','maecenas'),(60,'Genny Cullimore','pede lobortis'),(61,'Sandra Sandlin','nisl nunc nisl'),(62,'Ad Caron','nibh quisque id'),(63,'Mari Hampshaw','eget tincidunt'),(64,'Lilli Udy','pellentesque volutpat dui'),(65,'Rennie Ofield','tortor'),(66,'Renae Maylard','duis faucibus accumsan'),(67,'Say Shackesby','quisque erat'),(68,'Siward Naish','nulla'),(69,'Taffy Gladdish','mus'),(70,'Minor Halton','leo'),(71,'Rafael Clemetts','maecenas'),(72,'Ring Gergely','quam'),(73,'Leese Sunshine','potenti cras in'),(74,'Ashleigh Titcomb','pretium quis'),(75,'Giorgia Davioud','suspendisse potenti'),(76,'Alvinia Kimmince','donec semper'),(77,'Daniella Beevens','eros viverra eget'),(78,'Jamima Longthorne','quis tortor'),(79,'Hartley Fairbrass','nunc purus phasellus'),(80,'Joseph Mixture','in'),(81,'Freedman Kopisch','eu'),(82,'Helaina Pleace','interdum eu tincidunt'),(83,'Claudianus Ayliff','mauris sit amet'),(84,'Raimondo Pieter','gravida'),(85,'Gherardo Jerschke','leo odio'),(86,'Timmy Nelm','pede'),(87,'Meghann Cardenosa','duis'),(88,'Phillipp Pordall','faucibus orci'),(89,'Benjamen Whitcher','sem sed sagittis'),(90,'Derek Pittman','ante ipsum'),(91,'Bee Silverson','nulla integer'),(92,'Hirsch Bullivant','consequat varius'),(93,'Beryle Gerling','justo'),(94,'Colan Melville','sit amet sapien'),(95,'Zandra Smitheman','congue'),(96,'Grazia Woolfenden','tincidunt nulla mollis'),(97,'Lolly Sellors','lectus pellentesque at'),(98,'Elsie Skains','lobortis est phasellus'),(99,'Joline Samwyse','vehicula'),(100,'Celestina Costell','eros suspendisse');
/*!40000 ALTER TABLE `leave_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `offboarders`
--

DROP TABLE IF EXISTS `offboarders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `offboarders` (
  `offboarder_id` int unsigned NOT NULL,
  `year_contribution` int unsigned DEFAULT NULL,
  `job_position_id` int unsigned NOT NULL,
  `offboarder_name` char(100) DEFAULT NULL,
  `offboarding_reason` text,
  `offboarder_work_feedback` text,
  PRIMARY KEY (`offboarder_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `offboarders`
--

LOCK TABLES `offboarders` WRITE;
/*!40000 ALTER TABLE `offboarders` DISABLE KEYS */;
INSERT INTO `offboarders` VALUES (1,10,37,'Kanya Lakey','vitae nisl aenean','tristique in tempus'),(2,6,76,'Ezequiel Britian','rhoncus sed vestibulum sit amet','sit amet justo morbi ut'),(3,5,22,'Carlina Dumbrall','non quam nec dui','maecenas leo odio condimentum'),(4,8,75,'Guss Jewks','rutrum nulla nunc','eget tempus vel pede morbi'),(5,6,55,'Gwenny Januszewski','magnis dis parturient','quis lectus suspendisse'),(6,8,13,'Rosamond Sandland','vivamus metus arcu adipiscing molestie','fusce posuere felis sed lacus'),(7,9,88,'Morty Keatley','ornare consequat lectus in est','risus praesent lectus vestibulum quam'),(8,1,44,'Elinore Kenward','id mauris vulputate elementum nullam','in lacus curabitur at ipsum'),(9,9,8,'Ulla Ethridge','posuere nonummy integer non velit','sapien urna pretium nisl ut'),(10,9,66,'Benny Hambric','orci pede venenatis','magna bibendum imperdiet nullam orci'),(11,10,80,'Alejandra Pagin','ultrices aliquet maecenas leo','a ipsum integer a nibh'),(12,3,41,'Berkly Jeness','ultrices erat tortor sollicitudin','iaculis congue vivamus metus arcu'),(13,2,3,'Lucie Krier','porttitor id consequat','maecenas rhoncus aliquam lacus morbi'),(14,9,23,'Angil Bagot','lorem integer tincidunt ante','id mauris vulputate'),(15,2,73,'Marissa Oakhill','sit amet justo','luctus et ultrices'),(16,5,55,'Oran Sorby','vel nulla eget','sagittis dui vel nisl'),(17,6,96,'Bevvy MacLeese','vestibulum sagittis sapien cum sociis','odio odio elementum'),(18,3,45,'Larine Eslie','dui proin leo','eu tincidunt in leo'),(19,3,97,'Kellen Mamwell','lobortis convallis tortor risus','massa quis augue luctus'),(20,10,6,'Tootsie Stockney','nulla ut erat id mauris','sociis natoque penatibus'),(21,9,30,'Dennie Reims','sit amet consectetuer adipiscing elit','in blandit ultrices enim'),(22,1,26,'Ivett Willgoss','in purus eu magna vulputate','vestibulum ante ipsum primis'),(23,2,11,'Lissa Sparway','rhoncus dui vel sem','nonummy maecenas tincidunt'),(24,1,33,'Harlene Chasmer','vel augue vestibulum','ipsum primis in faucibus'),(25,10,25,'Desiri Widdecombe','cum sociis natoque penatibus','eu est congue'),(26,1,57,'Reider Smylie','justo pellentesque viverra pede ac','platea dictumst morbi'),(27,5,62,'Melitta Parks','platea dictumst etiam faucibus','consectetuer eget rutrum at'),(28,2,74,'Rowena Yell','consequat ut nulla','luctus rutrum nulla tellus in'),(29,5,79,'Hastings Fairham','nisi eu orci mauris','libero nullam sit amet turpis'),(30,3,52,'Laurice Michelmore','phasellus id sapien in sapien','in quis justo maecenas rhoncus'),(31,10,8,'Aleda Jiggins','consequat dui nec nisi volutpat','in hac habitasse platea'),(32,10,4,'Adelaide McNab','nec dui luctus','non interdum in'),(33,6,20,'Olia Kilsby','neque duis bibendum','quisque porta volutpat erat quisque'),(34,9,78,'Stan Cutress','odio in hac','eleifend donec ut dolor morbi'),(35,4,82,'Emile Klimes','cras pellentesque volutpat dui','vitae mattis nibh ligula nec'),(36,4,10,'Giles Heed','pede ullamcorper augue a suscipit','amet sapien dignissim vestibulum'),(37,2,69,'Tannie Evitts','et ultrices posuere cubilia','semper rutrum nulla nunc purus'),(38,6,59,'Demetris Burlingham','varius integer ac leo','vestibulum ac est lacinia'),(39,6,78,'Pavia Arnely','velit vivamus vel','nulla elit ac nulla'),(40,3,32,'Sal Wallenger','risus semper porta','ridiculus mus vivamus'),(41,7,83,'Esme Evill','convallis eget eleifend luctus','molestie nibh in lectus pellentesque'),(42,10,68,'Karlene Escreet','duis ac nibh fusce lacus','vel lectus in'),(43,6,63,'Toinette Hicks','sapien urna pretium nisl','convallis nunc proin at turpis'),(44,6,73,'Donia McArthur','aliquam erat volutpat','condimentum neque sapien placerat ante'),(45,4,65,'Zara Dewerson','fusce consequat nulla','vivamus metus arcu adipiscing molestie'),(46,1,15,'Bettina Nolte','turpis a pede','ante vel ipsum praesent'),(47,4,7,'Gleda Axton','nulla suscipit ligula in lacus','nec euismod scelerisque quam'),(48,4,52,'Phoebe Smissen','in lacus curabitur','dolor quis odio consequat varius'),(49,7,51,'Dieter Waddy','vel accumsan tellus nisi eu','enim in tempor turpis'),(50,5,46,'Yuri Treweke','urna pretium nisl','et ultrices posuere cubilia'),(51,4,31,'Bastien Bucknell','diam neque vestibulum eget vulputate','sed interdum venenatis turpis'),(52,4,81,'Gleda Giacomini','vivamus metus arcu','mauris enim leo rhoncus'),(53,9,40,'Shina De Lascy','nulla integer pede justo lacinia','turpis donec posuere metus vitae'),(54,5,2,'Meaghan Gerasch','posuere felis sed lacus morbi','sapien arcu sed'),(55,10,52,'Constantine Toopin','proin leo odio porttitor','turpis enim blandit mi'),(56,3,25,'Wilie Gaule','risus auctor sed tristique in','mus etiam vel augue'),(57,1,91,'Jeniffer Tunnicliff','erat nulla tempus','volutpat eleifend donec ut dolor'),(58,3,11,'Ikey Ivanchikov','praesent id massa id nisl','iaculis diam erat fermentum justo'),(59,2,39,'Clark Niesel','quis augue luctus','in imperdiet et commodo vulputate'),(60,1,39,'Jacquenette Hudspeth','ante ipsum primis in','curae mauris viverra diam'),(61,1,97,'Aguste MacGorley','nullam porttitor lacus','quisque ut erat curabitur'),(62,10,43,'Bren Derington','natoque penatibus et magnis','sollicitudin mi sit amet'),(63,6,33,'Berky Blowne','sapien sapien non','eget congue eget'),(64,7,77,'Ciro O\'Hoey','posuere cubilia curae nulla','odio donec vitae nisi'),(65,3,19,'Raquel Webben','in hac habitasse','ut rhoncus aliquet'),(66,4,49,'Stephanus Hannay','est congue elementum','metus sapien ut'),(67,7,69,'Emmalynn MacTrustey','tempor turpis nec euismod','cras in purus eu'),(68,1,32,'Valeda Ahrenius','consectetuer adipiscing elit proin risus','quisque ut erat curabitur'),(69,7,57,'Wolfgang Germain','sociis natoque penatibus','rhoncus mauris enim'),(70,5,84,'Benjamin Folliss','enim blandit mi in','amet sapien dignissim vestibulum vestibulum'),(71,9,87,'Robbie Wadeson','amet erat nulla tempus','in faucibus orci'),(72,1,75,'Mag Buckam','proin eu mi nulla','lacinia sapien quis'),(73,1,85,'Sue Dumini','interdum mauris non','diam id ornare imperdiet sapien'),(74,4,93,'Tabbie Zoephel','quam pede lobortis ligula sit','justo lacinia eget'),(75,9,14,'Darren Frear','vel est donec odio','erat id mauris'),(76,7,96,'Ally Lincoln','in quam fringilla rhoncus mauris','pede malesuada in'),(77,2,78,'Jaymee Cardenoza','duis bibendum felis sed','nulla ultrices aliquet'),(78,5,25,'Oliy Endon','hac habitasse platea dictumst','tempus semper est'),(79,9,57,'Michelle Gillyett','in congue etiam justo','cum sociis natoque penatibus et'),(80,5,28,'Clea Digweed','luctus et ultrices','pulvinar lobortis est phasellus sit'),(81,7,85,'Gabie Elphick','tempor turpis nec euismod scelerisque','sem duis aliquam'),(82,5,20,'Neda Varnham','neque aenean auctor gravida','praesent blandit nam nulla integer'),(83,8,48,'Gabbie Couthard','ac nulla sed','lobortis est phasellus'),(84,1,23,'Grethel Walduck','mauris vulputate elementum nullam','tempor turpis nec'),(85,1,49,'Evonne Eames','in felis eu','imperdiet et commodo vulputate'),(86,4,24,'Melodee Moorhead','quis orci nullam','donec vitae nisi nam'),(87,6,95,'Rozamond Kentish','ante ipsum primis in faucibus','suscipit ligula in lacus curabitur'),(88,9,23,'Tilly Brain','morbi non lectus','ultrices posuere cubilia'),(89,5,89,'Donovan Geerits','vestibulum quam sapien','quam turpis adipiscing lorem'),(90,2,45,'Chester Robrow','gravida sem praesent id','eu interdum eu'),(91,1,32,'Mattie Abrashkov','rhoncus aliquam lacus','nulla nisl nunc'),(92,6,6,'Lebbie Povele','vel nisl duis','feugiat non pretium quis lectus'),(93,7,45,'Tony Feeny','velit donec diam neque vestibulum','ridiculus mus vivamus vestibulum'),(94,6,34,'Abagail Boyland','pellentesque viverra pede','quam sollicitudin vitae'),(95,10,11,'Curr Lauridsen','fusce posuere felis sed','magnis dis parturient montes nascetur'),(96,6,37,'Rooney Jinkin','curae duis faucibus','nec sem duis aliquam'),(97,1,56,'Rob Bolton','metus sapien ut nunc','nulla sed vel enim sit'),(98,5,19,'Orsola Lemmers','eu felis fusce','diam vitae quam suspendisse potenti'),(99,5,69,'Link Erley','ac enim in tempor turpis','lacinia nisi venenatis tristique'),(100,10,16,'Jana Hendrikse','est quam pharetra magna ac','semper porta volutpat');
/*!40000 ALTER TABLE `offboarders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `on_offboarding_assignment`
--

DROP TABLE IF EXISTS `on_offboarding_assignment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `on_offboarding_assignment` (
  `on_offboarding_assignmet_id` int unsigned NOT NULL,
  `onboarder_id` int unsigned NOT NULL,
  `offboarder_id` int unsigned NOT NULL,
  `onboarder_contact` varchar(100) DEFAULT NULL,
  `offboarder_contact` varchar(100) DEFAULT NULL,
  `job_position_task_list _id` int unsigned NOT NULL,
  `onboarder_comments` text,
  `offboarder_comments` text,
  PRIMARY KEY (`on_offboarding_assignmet_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `on_offboarding_assignment`
--

LOCK TABLES `on_offboarding_assignment` WRITE;
/*!40000 ALTER TABLE `on_offboarding_assignment` DISABLE KEYS */;
INSERT INTO `on_offboarding_assignment` VALUES (5,648,60,'302-182-0712','922-117-4783',24,'sapien urna pretium nisl ut volutpat sapien arcu sed augue aliquam erat volutpat in congue etiam justo','ligula sit amet eleifend pede libero quis orci nullam molestie'),(7,253,193,'961-266-4308','132-291-3512',710,'leo odio porttitor id consequat in consequat ut nulla sed accumsan felis ut at dolor quis','habitasse platea dictumst etiam faucibus cursus urna ut tellus nulla ut erat id mauris vulputate elementum nullam varius nulla'),(48,718,650,'139-922-4538','164-297-6833',183,'eget eros elementum pellentesque quisque porta volutpat erat quisque erat eros viverra eget congue eget semper rutrum nulla nunc','ut mauris eget massa tempor convallis nulla neque libero convallis eget eleifend luctus ultricies eu nibh'),(51,336,934,'724-460-8266','827-897-7745',730,'nisi vulputate nonummy maecenas tincidunt lacus at velit vivamus vel nulla eget','molestie nibh in lectus pellentesque at nulla suspendisse potenti cras in'),(56,276,635,'142-948-1824','216-529-9390',606,'pellentesque ultrices phasellus id sapien in sapien iaculis congue vivamus metus arcu adipiscing molestie hendrerit','rutrum at lorem integer tincidunt ante vel ipsum praesent blandit lacinia erat vestibulum sed magna at nunc'),(79,194,779,'603-545-3803','919-828-6169',34,'velit vivamus vel nulla eget eros elementum pellentesque quisque porta volutpat erat','nisi venenatis tristique fusce congue diam id ornare imperdiet sapien urna pretium nisl ut volutpat sapien arcu sed'),(80,160,564,'416-393-6179','247-751-2978',597,'aenean sit amet justo morbi ut odio cras mi pede malesuada in imperdiet et commodo','ut erat curabitur gravida nisi at nibh in hac habitasse platea dictumst aliquam augue quam sollicitudin vitae consectetuer eget rutrum'),(93,749,761,'202-985-7803','753-898-9963',714,'convallis morbi odio odio elementum eu interdum eu tincidunt in leo maecenas pulvinar lobortis','mauris lacinia sapien quis libero nullam sit amet turpis elementum ligula'),(95,581,899,'334-462-8802','948-790-5593',491,'curabitur gravida nisi at nibh in hac habitasse platea dictumst aliquam augue quam sollicitudin vitae consectetuer','sapien quis libero nullam sit amet turpis elementum ligula vehicula consequat morbi a ipsum integer a nibh in quis justo'),(101,443,906,'686-339-3950','490-480-0939',702,'amet lobortis sapien sapien non mi integer ac neque duis bibendum morbi non','vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae nulla dapibus dolor'),(115,993,511,'601-357-5997','892-388-4423',759,'quisque ut erat curabitur gravida nisi at nibh in hac habitasse platea','etiam faucibus cursus urna ut tellus nulla ut erat id'),(133,607,473,'933-478-1227','755-137-3032',912,'aliquam lacus morbi quis tortor id nulla ultrices aliquet maecenas leo odio condimentum id','maecenas ut massa quis augue luctus tincidunt nulla mollis molestie lorem quisque'),(141,644,605,'923-947-4516','562-768-9760',72,'sem duis aliquam convallis nunc proin at turpis a pede posuere nonummy integer non velit donec diam neque','lectus vestibulum quam sapien varius ut blandit non interdum in ante vestibulum ante ipsum primis'),(142,953,495,'806-780-9461','309-366-3700',225,'tempus sit amet sem fusce consequat nulla nisl nunc nisl duis bibendum felis sed interdum venenatis','natoque penatibus et magnis dis parturient montes nascetur ridiculus mus vivamus vestibulum sagittis sapien cum sociis natoque penatibus et magnis'),(153,268,93,'662-522-9464','793-840-0224',257,'ligula sit amet eleifend pede libero quis orci nullam molestie nibh','ac est lacinia nisi venenatis tristique fusce congue diam id ornare imperdiet sapien urna pretium'),(160,818,900,'360-446-2464','857-468-4007',613,'elementum pellentesque quisque porta volutpat erat quisque erat eros viverra eget congue eget semper rutrum','aenean fermentum donec ut mauris eget massa tempor convallis nulla neque libero convallis eget eleifend'),(197,616,782,'666-833-7113','776-892-1376',740,'dolor quis odio consequat varius integer ac leo pellentesque ultrices mattis odio donec vitae nisi nam ultrices','nibh in quis justo maecenas rhoncus aliquam lacus morbi quis tortor id nulla ultrices aliquet'),(209,441,735,'363-985-1189','414-300-3181',304,'sed sagittis nam congue risus semper porta volutpat quam pede lobortis ligula sit amet eleifend','vitae quam suspendisse potenti nullam porttitor lacus at turpis donec posuere metus'),(218,920,401,'319-695-4345','647-820-3559',79,'a ipsum integer a nibh in quis justo maecenas rhoncus aliquam lacus morbi quis','ornare consequat lectus in est risus auctor sed tristique in tempus sit amet sem'),(235,289,295,'685-487-9100','335-930-5428',60,'nascetur ridiculus mus etiam vel augue vestibulum rutrum rutrum neque aenean','curae nulla dapibus dolor vel est donec odio justo sollicitudin ut suscipit a feugiat et eros vestibulum ac est lacinia'),(244,886,110,'641-617-8543','190-503-1649',483,'diam neque vestibulum eget vulputate ut ultrices vel augue vestibulum ante ipsum primis in faucibus orci luctus et','porttitor pede justo eu massa donec dapibus duis at velit eu est congue'),(263,318,785,'338-598-0802','699-870-2240',723,'tellus nisi eu orci mauris lacinia sapien quis libero nullam sit amet','nulla ultrices aliquet maecenas leo odio condimentum id luctus nec molestie sed justo pellentesque viverra pede ac diam cras pellentesque'),(264,99,784,'571-752-5348','906-440-0819',225,'nulla quisque arcu libero rutrum ac lobortis vel dapibus at','risus semper porta volutpat quam pede lobortis ligula sit amet eleifend pede libero quis orci'),(265,910,647,'565-378-1057','936-888-0968',539,'amet nulla quisque arcu libero rutrum ac lobortis vel dapibus at diam nam tristique tortor','orci eget orci vehicula condimentum curabitur in libero ut massa volutpat convallis morbi odio odio'),(269,292,394,'728-735-0839','987-237-0899',8,'vivamus metus arcu adipiscing molestie hendrerit at vulputate vitae nisl aenean lectus pellentesque eget nunc donec quis orci eget orci','leo odio porttitor id consequat in consequat ut nulla sed accumsan felis ut'),(270,443,855,'144-912-5945','802-629-9760',251,'lorem id ligula suspendisse ornare consequat lectus in est risus','proin at turpis a pede posuere nonummy integer non velit donec diam neque vestibulum eget'),(277,441,255,'662-660-0742','764-689-1587',754,'neque sapien placerat ante nulla justo aliquam quis turpis eget elit sodales scelerisque mauris sit amet eros suspendisse accumsan','nec dui luctus rutrum nulla tellus in sagittis dui vel nisl duis'),(280,579,203,'369-345-2489','109-801-4354',246,'elementum ligula vehicula consequat morbi a ipsum integer a nibh in','elit sodales scelerisque mauris sit amet eros suspendisse accumsan tortor quis'),(295,982,456,'268-225-6016','388-521-2700',636,'lectus vestibulum quam sapien varius ut blandit non interdum in ante vestibulum ante ipsum primis in faucibus orci luctus','nulla ac enim in tempor turpis nec euismod scelerisque quam turpis adipiscing lorem vitae mattis nibh ligula nec sem duis'),(296,640,354,'136-778-9074','480-376-4721',796,'platea dictumst morbi vestibulum velit id pretium iaculis diam erat fermentum justo nec condimentum neque','volutpat sapien arcu sed augue aliquam erat volutpat in congue etiam justo etiam pretium iaculis justo in hac habitasse'),(311,843,107,'237-932-8918','340-409-9485',766,'ligula in lacus curabitur at ipsum ac tellus semper interdum mauris ullamcorper purus','amet justo morbi ut odio cras mi pede malesuada in imperdiet et commodo'),(318,374,386,'998-644-9448','801-231-5580',189,'libero quis orci nullam molestie nibh in lectus pellentesque at nulla suspendisse potenti cras in purus eu magna vulputate luctus','mauris morbi non lectus aliquam sit amet diam in magna bibendum'),(349,478,685,'816-658-4666','984-496-0717',439,'augue vel accumsan tellus nisi eu orci mauris lacinia sapien quis libero nullam sit amet turpis elementum','ut nulla sed accumsan felis ut at dolor quis odio consequat varius integer'),(359,533,667,'347-944-7228','654-642-3519',942,'venenatis non sodales sed tincidunt eu felis fusce posuere felis sed','ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae donec pharetra magna'),(362,281,962,'957-870-8139','390-660-1643',345,'ligula suspendisse ornare consequat lectus in est risus auctor sed tristique in tempus sit amet sem','tristique fusce congue diam id ornare imperdiet sapien urna pretium nisl ut'),(372,45,628,'306-948-4737','308-334-9825',441,'mi nulla ac enim in tempor turpis nec euismod scelerisque quam turpis adipiscing lorem vitae','maecenas ut massa quis augue luctus tincidunt nulla mollis molestie lorem quisque ut'),(377,634,342,'153-511-4513','321-459-2621',343,'viverra eget congue eget semper rutrum nulla nunc purus phasellus in felis','faucibus orci luctus et ultrices posuere cubilia curae duis faucibus'),(387,821,300,'635-274-7410','409-196-1384',732,'pellentesque viverra pede ac diam cras pellentesque volutpat dui maecenas tristique est et tempus semper est quam pharetra magna','montes nascetur ridiculus mus vivamus vestibulum sagittis sapien cum sociis natoque penatibus et magnis dis parturient montes nascetur'),(388,299,356,'644-700-4043','980-441-4698',556,'id massa id nisl venenatis lacinia aenean sit amet justo','sit amet nunc viverra dapibus nulla suscipit ligula in lacus curabitur at ipsum ac tellus'),(404,834,354,'649-125-4587','424-598-3516',476,'in hac habitasse platea dictumst maecenas ut massa quis augue','curabitur in libero ut massa volutpat convallis morbi odio odio elementum'),(408,689,580,'526-811-6850','872-669-7407',391,'massa id lobortis convallis tortor risus dapibus augue vel accumsan tellus nisi eu orci mauris','ac nulla sed vel enim sit amet nunc viverra dapibus nulla suscipit ligula in'),(438,789,783,'346-131-4218','980-895-8049',940,'pretium iaculis justo in hac habitasse platea dictumst etiam faucibus cursus','molestie nibh in lectus pellentesque at nulla suspendisse potenti cras in purus eu magna vulputate luctus cum'),(441,543,979,'478-599-5266','420-297-8073',450,'tempus sit amet sem fusce consequat nulla nisl nunc nisl duis bibendum felis sed interdum venenatis turpis enim blandit mi','quis orci nullam molestie nibh in lectus pellentesque at nulla suspendisse potenti cras in purus eu magna'),(449,34,309,'557-932-2684','433-619-5463',473,'metus vitae ipsum aliquam non mauris morbi non lectus aliquam sit amet diam','sem duis aliquam convallis nunc proin at turpis a pede posuere nonummy integer non velit'),(468,607,994,'132-675-1375','113-679-7762',424,'vitae mattis nibh ligula nec sem duis aliquam convallis nunc proin at turpis a pede posuere nonummy integer non velit','primis in faucibus orci luctus et ultrices posuere cubilia curae donec pharetra magna vestibulum aliquet ultrices erat tortor sollicitudin'),(486,487,199,'334-325-1903','202-806-2074',840,'id luctus nec molestie sed justo pellentesque viverra pede ac diam cras pellentesque volutpat dui maecenas tristique','in magna bibendum imperdiet nullam orci pede venenatis non sodales sed tincidunt eu felis fusce posuere felis sed lacus morbi'),(487,618,750,'140-532-2869','177-311-4812',309,'ut suscipit a feugiat et eros vestibulum ac est lacinia nisi venenatis','mattis nibh ligula nec sem duis aliquam convallis nunc proin at'),(521,168,899,'493-735-1507','814-518-8121',949,'ultrices posuere cubilia curae donec pharetra magna vestibulum aliquet ultrices erat tortor sollicitudin mi sit amet lobortis','a odio in hac habitasse platea dictumst maecenas ut massa quis augue luctus tincidunt nulla mollis molestie'),(522,163,460,'920-835-9191','838-151-6133',423,'dapibus duis at velit eu est congue elementum in hac','tincidunt nulla mollis molestie lorem quisque ut erat curabitur gravida nisi at nibh in hac habitasse platea'),(544,612,200,'281-407-9769','288-778-5910',175,'maecenas pulvinar lobortis est phasellus sit amet erat nulla tempus vivamus in','arcu libero rutrum ac lobortis vel dapibus at diam nam'),(556,482,109,'866-476-6368','976-296-7396',281,'aliquet at feugiat non pretium quis lectus suspendisse potenti in','aenean lectus pellentesque eget nunc donec quis orci eget orci vehicula condimentum'),(558,509,302,'872-666-9095','761-313-9431',884,'sem sed sagittis nam congue risus semper porta volutpat quam pede lobortis ligula sit amet eleifend pede libero','libero ut massa volutpat convallis morbi odio odio elementum eu interdum eu tincidunt'),(564,836,90,'136-971-8405','319-106-5608',646,'pede justo lacinia eget tincidunt eget tempus vel pede morbi porttitor lorem id ligula','non ligula pellentesque ultrices phasellus id sapien in sapien iaculis congue vivamus'),(572,327,376,'212-966-0564','425-395-9429',752,'justo eu massa donec dapibus duis at velit eu est congue elementum in hac habitasse platea dictumst','ultrices libero non mattis pulvinar nulla pede ullamcorper augue a suscipit nulla'),(576,795,245,'179-710-2154','811-276-6842',736,'interdum mauris non ligula pellentesque ultrices phasellus id sapien in sapien iaculis congue vivamus metus arcu adipiscing','sem praesent id massa id nisl venenatis lacinia aenean sit amet justo morbi ut'),(578,369,140,'901-597-8700','585-388-2548',431,'quis turpis eget elit sodales scelerisque mauris sit amet eros','cras mi pede malesuada in imperdiet et commodo vulputate justo in blandit'),(579,81,183,'245-439-3288','754-142-7397',988,'tortor sollicitudin mi sit amet lobortis sapien sapien non mi integer ac neque duis bibendum','justo in hac habitasse platea dictumst etiam faucibus cursus urna'),(584,637,966,'398-639-0616','565-107-1271',59,'in quam fringilla rhoncus mauris enim leo rhoncus sed vestibulum','nunc commodo placerat praesent blandit nam nulla integer pede justo lacinia'),(597,514,218,'304-123-9312','228-134-8376',353,'mi integer ac neque duis bibendum morbi non quam nec dui luctus rutrum nulla tellus in sagittis dui vel','vestibulum sagittis sapien cum sociis natoque penatibus et magnis dis parturient montes nascetur ridiculus'),(605,265,712,'943-837-1032','302-313-2280',89,'massa volutpat convallis morbi odio odio elementum eu interdum eu tincidunt in leo maecenas pulvinar lobortis est','turpis integer aliquet massa id lobortis convallis tortor risus dapibus augue vel accumsan tellus nisi eu orci'),(635,336,880,'805-484-5942','656-946-4086',122,'aliquet ultrices erat tortor sollicitudin mi sit amet lobortis sapien sapien','ac leo pellentesque ultrices mattis odio donec vitae nisi nam ultrices libero non'),(637,816,451,'979-783-0466','140-460-4562',432,'praesent id massa id nisl venenatis lacinia aenean sit amet justo morbi ut odio cras mi pede','velit donec diam neque vestibulum eget vulputate ut ultrices vel'),(642,456,931,'109-692-4894','723-948-4597',492,'etiam justo etiam pretium iaculis justo in hac habitasse platea dictumst etiam faucibus cursus','augue quam sollicitudin vitae consectetuer eget rutrum at lorem integer tincidunt'),(648,741,376,'988-915-8295','656-113-7861',780,'bibendum imperdiet nullam orci pede venenatis non sodales sed tincidunt eu felis fusce posuere felis','suscipit nulla elit ac nulla sed vel enim sit amet nunc viverra dapibus nulla suscipit ligula in'),(665,282,373,'634-684-7083','423-779-1729',328,'pellentesque volutpat dui maecenas tristique est et tempus semper est quam pharetra magna ac consequat metus sapien ut nunc','sem mauris laoreet ut rhoncus aliquet pulvinar sed nisl nunc'),(680,653,893,'818-692-3323','491-757-6492',594,'praesent lectus vestibulum quam sapien varius ut blandit non interdum in ante vestibulum ante ipsum primis in','ligula nec sem duis aliquam convallis nunc proin at turpis a pede posuere nonummy'),(690,584,971,'847-979-0408','391-467-9808',774,'id justo sit amet sapien dignissim vestibulum vestibulum ante ipsum primis in','vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae'),(710,897,891,'937-380-2496','575-667-9538',223,'sit amet consectetuer adipiscing elit proin risus praesent lectus vestibulum quam sapien varius ut','sed tincidunt eu felis fusce posuere felis sed lacus morbi'),(721,879,671,'205-769-1168','855-147-5269',865,'nulla suscipit ligula in lacus curabitur at ipsum ac tellus semper interdum mauris ullamcorper purus sit amet nulla quisque arcu','eget eros elementum pellentesque quisque porta volutpat erat quisque erat eros viverra eget congue eget semper rutrum'),(728,210,452,'152-108-1590','715-878-3433',533,'ut volutpat sapien arcu sed augue aliquam erat volutpat in congue etiam justo','morbi non lectus aliquam sit amet diam in magna bibendum imperdiet nullam orci pede venenatis non sodales'),(740,332,312,'122-941-6680','290-555-4241',124,'venenatis turpis enim blandit mi in porttitor pede justo eu massa donec dapibus duis at velit eu est congue','mi nulla ac enim in tempor turpis nec euismod scelerisque quam turpis adipiscing lorem vitae mattis nibh ligula'),(746,752,696,'961-680-3419','270-975-8073',334,'ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae mauris viverra diam vitae quam','erat fermentum justo nec condimentum neque sapien placerat ante nulla'),(748,793,119,'502-426-1419','878-521-7379',699,'nulla tempus vivamus in felis eu sapien cursus vestibulum proin eu mi nulla','natoque penatibus et magnis dis parturient montes nascetur ridiculus mus etiam vel'),(753,484,532,'978-620-3771','674-727-5002',9,'aenean fermentum donec ut mauris eget massa tempor convallis nulla neque libero convallis eget eleifend luctus','nulla ut erat id mauris vulputate elementum nullam varius nulla facilisi cras non velit nec nisi vulputate nonummy maecenas tincidunt'),(760,332,916,'247-769-4322','688-270-2434',381,'blandit ultrices enim lorem ipsum dolor sit amet consectetuer adipiscing elit proin interdum','quam a odio in hac habitasse platea dictumst maecenas ut massa quis augue luctus tincidunt nulla mollis molestie lorem quisque'),(770,460,620,'862-721-3393','929-703-6854',755,'molestie nibh in lectus pellentesque at nulla suspendisse potenti cras in purus','platea dictumst aliquam augue quam sollicitudin vitae consectetuer eget rutrum at lorem'),(773,872,90,'630-941-0832','733-140-7089',673,'diam in magna bibendum imperdiet nullam orci pede venenatis non','molestie sed justo pellentesque viverra pede ac diam cras pellentesque volutpat dui maecenas'),(774,817,72,'992-672-0250','287-744-7574',991,'in hac habitasse platea dictumst etiam faucibus cursus urna ut tellus','id pretium iaculis diam erat fermentum justo nec condimentum neque'),(779,981,282,'803-932-4481','272-665-4347',591,'ut suscipit a feugiat et eros vestibulum ac est lacinia nisi venenatis tristique fusce','in ante vestibulum ante ipsum primis in faucibus orci luctus'),(780,771,548,'104-447-2286','948-494-3117',450,'ac enim in tempor turpis nec euismod scelerisque quam turpis','lacus purus aliquet at feugiat non pretium quis lectus suspendisse potenti in eleifend quam a odio in'),(788,796,19,'378-201-5044','129-443-0848',97,'facilisi cras non velit nec nisi vulputate nonummy maecenas tincidunt lacus at velit vivamus vel nulla eget eros elementum pellentesque','odio justo sollicitudin ut suscipit a feugiat et eros vestibulum ac est lacinia nisi venenatis tristique fusce congue'),(797,617,83,'735-796-8699','571-753-0437',691,'velit vivamus vel nulla eget eros elementum pellentesque quisque porta','curabitur in libero ut massa volutpat convallis morbi odio odio elementum eu interdum eu tincidunt in leo maecenas pulvinar'),(810,538,178,'440-185-1828','888-491-4698',86,'sed augue aliquam erat volutpat in congue etiam justo etiam pretium iaculis justo in','fusce congue diam id ornare imperdiet sapien urna pretium nisl'),(815,704,443,'368-232-8831','432-205-5893',885,'tempor turpis nec euismod scelerisque quam turpis adipiscing lorem vitae mattis','ut blandit non interdum in ante vestibulum ante ipsum primis in faucibus orci'),(820,497,43,'831-354-4433','870-962-1541',567,'bibendum morbi non quam nec dui luctus rutrum nulla tellus in sagittis dui vel nisl duis ac nibh','cursus vestibulum proin eu mi nulla ac enim in tempor turpis nec euismod'),(821,808,559,'388-928-9041','135-359-0760',356,'ultrices posuere cubilia curae mauris viverra diam vitae quam suspendisse potenti nullam porttitor lacus at','eu tincidunt in leo maecenas pulvinar lobortis est phasellus sit'),(823,954,852,'482-391-2209','823-737-5872',219,'in hac habitasse platea dictumst maecenas ut massa quis augue luctus tincidunt nulla mollis molestie lorem quisque','at dolor quis odio consequat varius integer ac leo pellentesque ultrices mattis odio donec vitae nisi nam'),(848,991,410,'566-694-7002','752-384-2763',813,'adipiscing elit proin interdum mauris non ligula pellentesque ultrices phasellus','erat tortor sollicitudin mi sit amet lobortis sapien sapien non mi integer ac neque duis bibendum'),(858,361,597,'691-201-9999','190-681-3501',91,'augue vestibulum rutrum rutrum neque aenean auctor gravida sem praesent','nisl ut volutpat sapien arcu sed augue aliquam erat volutpat'),(872,533,790,'255-414-4002','467-786-6960',1000,'sapien dignissim vestibulum vestibulum ante ipsum primis in faucibus orci luctus','mauris ullamcorper purus sit amet nulla quisque arcu libero rutrum ac lobortis vel dapibus'),(879,526,10,'190-793-1569','156-375-0307',136,'sagittis sapien cum sociis natoque penatibus et magnis dis parturient montes nascetur ridiculus mus etiam','molestie nibh in lectus pellentesque at nulla suspendisse potenti cras in purus'),(880,289,463,'270-889-8801','815-602-1377',830,'et ultrices posuere cubilia curae duis faucibus accumsan odio curabitur convallis duis consequat dui nec nisi volutpat','dapibus duis at velit eu est congue elementum in hac habitasse platea dictumst morbi'),(893,729,347,'183-640-3385','962-862-7085',2,'elementum in hac habitasse platea dictumst morbi vestibulum velit id pretium iaculis diam erat fermentum justo nec condimentum','maecenas ut massa quis augue luctus tincidunt nulla mollis molestie lorem quisque ut'),(899,478,618,'450-795-0521','116-538-6572',247,'vestibulum vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae nulla dapibus','vel lectus in quam fringilla rhoncus mauris enim leo rhoncus sed vestibulum sit amet cursus id turpis'),(946,616,879,'870-428-1944','742-366-6956',269,'elementum in hac habitasse platea dictumst morbi vestibulum velit id pretium iaculis diam erat fermentum justo nec','convallis nulla neque libero convallis eget eleifend luctus ultricies eu nibh quisque'),(949,867,211,'573-948-6460','713-586-3183',162,'fermentum justo nec condimentum neque sapien placerat ante nulla justo aliquam quis turpis eget','luctus tincidunt nulla mollis molestie lorem quisque ut erat curabitur gravida nisi'),(966,925,361,'989-539-8376','216-125-9458',322,'enim lorem ipsum dolor sit amet consectetuer adipiscing elit proin interdum mauris non ligula pellentesque','a nibh in quis justo maecenas rhoncus aliquam lacus morbi quis tortor id nulla ultrices aliquet maecenas leo odio condimentum'),(968,460,441,'578-690-6821','509-568-8320',821,'ultrices mattis odio donec vitae nisi nam ultrices libero non mattis pulvinar nulla pede','ultricies eu nibh quisque id justo sit amet sapien dignissim vestibulum vestibulum ante'),(980,808,605,'901-528-1823','543-876-1961',68,'vitae consectetuer eget rutrum at lorem integer tincidunt ante vel ipsum praesent blandit lacinia erat vestibulum sed magna at nunc','fringilla rhoncus mauris enim leo rhoncus sed vestibulum sit amet cursus id turpis integer aliquet massa id lobortis'),(990,844,719,'457-966-8130','829-230-4018',39,'praesent blandit nam nulla integer pede justo lacinia eget tincidunt eget tempus vel pede morbi','faucibus orci luctus et ultrices posuere cubilia curae mauris viverra diam vitae');
/*!40000 ALTER TABLE `on_offboarding_assignment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `onboarders`
--

DROP TABLE IF EXISTS `onboarders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `onboarders` (
  `onboarder_id` int unsigned NOT NULL,
  `years_experienced` int unsigned DEFAULT NULL,
  `onboarder_name` char(100) DEFAULT NULL,
  `job_position_id` int unsigned NOT NULL,
  `onboarder_notes` text,
  PRIMARY KEY (`onboarder_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `onboarders`
--

LOCK TABLES `onboarders` WRITE;
/*!40000 ALTER TABLE `onboarders` DISABLE KEYS */;
INSERT INTO `onboarders` VALUES (1,3,'Randie O\'Lyhane',22,'vulputate luctus cum'),(2,4,'Reggie Allder',75,'leo rhoncus sed'),(3,1,'Winny Spoor',72,'nulla mollis molestie lorem quisque'),(4,1,'Kort Threadkell',76,'donec vitae nisi nam ultrices'),(5,1,'Beverlee Koschek',20,'vel est donec'),(6,4,'Darin Conrard',15,'tortor id nulla ultrices aliquet'),(7,4,'Evered Moan',73,'fermentum donec ut'),(8,4,'Sauveur Triplett',16,'diam id ornare imperdiet'),(9,4,'Britt Couzens',76,'augue luctus tincidunt nulla'),(10,4,'Krista Dowles',55,'at diam nam tristique'),(11,4,'Winnifred Wagerfield',22,'consectetuer adipiscing elit proin risus'),(12,2,'Emmit Rickards',49,'mauris enim leo rhoncus'),(13,5,'Valeda List',67,'pede lobortis ligula sit'),(14,1,'Carver Reneke',56,'ligula nec sem duis'),(15,4,'Dre Rao',1,'elementum nullam varius nulla facilisi'),(16,5,'Kitty Le Merchant',60,'aliquam sit amet diam in'),(17,1,'Helyn McGarrell',2,'sodales sed tincidunt eu felis'),(18,2,'Orelie Hedden',47,'quisque ut erat'),(19,4,'Margo Mangeney',69,'blandit non interdum in ante'),(20,4,'Garald Ludee',67,'sapien urna pretium nisl ut'),(21,1,'Curcio Dayment',14,'et ultrices posuere cubilia curae'),(22,5,'Napoleon Vannacci',26,'eget massa tempor convallis'),(23,1,'Eduardo Guihen',29,'quisque erat eros viverra'),(24,3,'Sioux Mewha',62,'congue elementum in'),(25,3,'Raynard Lammenga',37,'pellentesque ultrices mattis odio donec'),(26,5,'Neilla Laffoley-Lane',56,'aliquet maecenas leo odio'),(27,2,'Dela Leacy',3,'mi pede malesuada'),(28,4,'Annetta Streeten',84,'gravida nisi at nibh'),(29,3,'Emmye Barltrop',14,'nulla ultrices aliquet maecenas'),(30,4,'Gayleen Busfield',52,'mus etiam vel augue vestibulum'),(31,3,'Faun Broadway',19,'dapibus duis at velit'),(32,4,'Brandise McLaverty',5,'dui luctus rutrum'),(33,3,'Latrena Renwick',67,'nisl nunc nisl duis bibendum'),(34,5,'Katalin Geck',27,'metus vitae ipsum aliquam'),(35,2,'Wilek Carswell',15,'adipiscing elit proin'),(36,4,'Cully Comar',25,'pharetra magna vestibulum aliquet ultrices'),(37,5,'Syd Domeney',98,'ipsum primis in faucibus orci'),(38,4,'Dallas Olney',9,'nascetur ridiculus mus vivamus'),(39,1,'Theodor Attow',4,'rhoncus aliquet pulvinar'),(40,2,'Reinold Ielden',14,'in hac habitasse platea dictumst'),(41,5,'Jeanette Allflatt',99,'consectetuer adipiscing elit proin risus'),(42,3,'Chicky Hearsey',50,'sollicitudin ut suscipit'),(43,5,'Shawnee Savaage',35,'nisl aenean lectus'),(44,4,'Kalinda Hairs',13,'quis turpis eget'),(45,4,'Kaila Olekhov',68,'amet sem fusce consequat'),(46,1,'Brade Impey',66,'magnis dis parturient montes'),(47,2,'Nessie Embury',43,'purus eu magna'),(48,1,'Dusty Claypool',84,'et commodo vulputate justo'),(49,2,'Mahalia Giacobini',19,'leo odio porttitor id'),(50,3,'Hewett Potebury',10,'pulvinar nulla pede ullamcorper'),(51,5,'Byrann Mealiffe',21,'erat quisque erat'),(52,2,'Rozella Greenhaugh',18,'donec ut mauris eget massa'),(53,1,'Hendrik Avrahamoff',95,'eu nibh quisque'),(54,5,'Christopher Heaselgrave',53,'leo maecenas pulvinar lobortis est'),(55,4,'Cullen Miskin',99,'fusce lacus purus aliquet at'),(56,3,'Joye Libbie',57,'nascetur ridiculus mus etiam vel'),(57,1,'Sylvan Chetwin',43,'justo aliquam quis turpis'),(58,1,'Rozele O\'Kennavain',90,'nunc purus phasellus in'),(59,1,'Lorette Tolcharde',45,'porta volutpat quam pede'),(60,2,'Madelene Bon',54,'morbi non lectus aliquam'),(61,2,'Elonore Rayman',11,'mi sit amet'),(62,3,'Krystal Keeney',12,'nec nisi volutpat'),(63,2,'Cher Scott',89,'eros vestibulum ac'),(64,1,'Templeton Loeber',17,'lobortis ligula sit amet eleifend'),(65,3,'Rosemonde Rosson',82,'sagittis sapien cum sociis'),(66,3,'Bryn Dand',63,'in ante vestibulum ante ipsum'),(67,2,'Alfred Schultheiss',92,'mi pede malesuada'),(68,4,'Arlin Ferrolli',55,'pede venenatis non sodales sed'),(69,5,'Belita Batty',21,'at lorem integer'),(70,1,'Penny Keyho',38,'ultrices mattis odio donec vitae'),(71,1,'Annemarie Buzzing',41,'nunc purus phasellus in'),(72,1,'Nathalia Letford',70,'sit amet turpis elementum ligula'),(73,1,'Charmaine Bending',73,'a ipsum integer'),(74,1,'Bessie Tonnesen',38,'nam dui proin leo odio'),(75,2,'Aida Targetter',44,'tortor risus dapibus augue vel'),(76,5,'Edmon Choat',46,'sem sed sagittis nam'),(77,2,'Dianne Franceschino',55,'tortor id nulla ultrices'),(78,3,'Dorie Scoines',18,'magna bibendum imperdiet nullam'),(79,5,'Daisey Lambert-Ciorwyn',49,'nunc proin at turpis'),(80,5,'Meara Keaveny',28,'praesent id massa id nisl'),(81,1,'Ambrosius McKiddin',79,'tortor id nulla'),(82,5,'Russell Oulet',17,'eu nibh quisque id justo'),(83,1,'Fons Stot',73,'nibh in quis'),(84,4,'Danice Crimin',66,'mauris eget massa'),(85,2,'Rog Hegden',5,'ridiculus mus vivamus vestibulum sagittis'),(86,5,'Renault Dukelow',41,'turpis integer aliquet massa'),(87,3,'Mohandis Goodbarne',24,'vel augue vestibulum rutrum'),(88,5,'Korie Ritmeyer',92,'lobortis convallis tortor risus dapibus'),(89,3,'Christie Stearn',59,'et ultrices posuere'),(90,3,'Lotte Wedlake',41,'nulla integer pede justo lacinia'),(91,5,'Amara Necrews',47,'integer aliquet massa id lobortis'),(92,5,'Kippie Annott',58,'velit nec nisi vulputate'),(93,3,'Joline Cassimer',33,'nullam molestie nibh in lectus'),(94,4,'Liam Elph',12,'eu mi nulla'),(95,2,'Jefferson Verrill',77,'ante ipsum primis in'),(96,2,'Kissee Brummitt',82,'neque duis bibendum morbi'),(97,1,'Vasili Poynor',57,'risus praesent lectus'),(98,5,'Quincy McArdell',58,'risus dapibus augue vel accumsan'),(99,1,'Jen Jannasch',17,'mi pede malesuada in'),(100,2,'Zandra Brickell',55,'vehicula consequat morbi a ipsum');
/*!40000 ALTER TABLE `onboarders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payroll`
--

DROP TABLE IF EXISTS `payroll`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `payroll` (
  `payroll_id` int unsigned NOT NULL,
  `employee_id` int unsigned NOT NULL,
  `payroll_period` date DEFAULT NULL,
  `calculated_earnings` decimal(10,2) DEFAULT NULL,
  `deductions` decimal(10,2) DEFAULT NULL,
  `netpay` decimal(10,2) NOT NULL,
  `overtime_hours` decimal(10,2) DEFAULT NULL,
  `payroll_date` date DEFAULT NULL,
  `compensation_id` int unsigned NOT NULL,
  `tax_deduction` int NOT NULL,
  PRIMARY KEY (`payroll_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payroll`
--

LOCK TABLES `payroll` WRITE;
/*!40000 ALTER TABLE `payroll` DISABLE KEYS */;
/*!40000 ALTER TABLE `payroll` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `performance_reviews`
--

DROP TABLE IF EXISTS `performance_reviews`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `performance_reviews` (
  `performance_review_id` int unsigned NOT NULL,
  `employee_id` int unsigned NOT NULL,
  `performance_review_date` date DEFAULT NULL,
  `reviewer` int NOT NULL,
  `performance_rating` int DEFAULT NULL,
  `reviewer_comments` text,
  `development_plans` text,
  `training_areas` text,
  PRIMARY KEY (`performance_review_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `performance_reviews`
--

LOCK TABLES `performance_reviews` WRITE;
/*!40000 ALTER TABLE `performance_reviews` DISABLE KEYS */;
INSERT INTO `performance_reviews` VALUES (1,1,'2023-05-05',45,10,'morbi non lectus','pharetra magna vestibulum aliquet ultrices erat tortor sollicitudin','ante'),(2,2,'2023-08-12',32,9,'fusce congue','etiam justo etiam pretium iaculis justo in','proin'),(3,3,'2023-09-19',38,6,'vel pede morbi','cubilia curae duis faucibus accumsan','vulputate'),(4,4,'2023-03-14',7,4,'non pretium','eu tincidunt in leo maecenas pulvinar lobortis','faucibus cursus'),(5,5,'2023-01-09',36,9,'ipsum','nisi volutpat eleifend donec ut','blandit'),(6,6,'2023-10-11',25,4,'nullam','pretium nisl ut volutpat sapien arcu sed augue','ullamcorper purus'),(7,7,'2023-11-02',66,8,'dictumst maecenas ut','venenatis turpis enim blandit mi in porttitor','et eros'),(8,8,'2023-06-28',13,2,'diam cras pellentesque','fusce consequat nulla nisl nunc nisl duis','ante'),(9,9,'2023-11-19',80,7,'orci luctus','integer ac neque duis bibendum morbi non','ipsum'),(10,10,'2023-05-15',6,2,'tristique','mi nulla ac enim in tempor turpis','ultrices'),(11,11,'2023-04-17',90,7,'diam nam','lectus aliquam sit amet diam','etiam'),(12,12,'2023-12-17',37,1,'nam tristique tortor','nulla suspendisse potenti cras in purus','donec posuere metus'),(13,13,'2023-05-14',43,10,'quis tortor id','tempus semper est quam pharetra','mauris morbi non'),(14,14,'2023-04-27',47,7,'fusce posuere','consectetuer adipiscing elit proin interdum mauris non ligula','curae'),(15,15,'2023-10-28',18,4,'curabitur','erat quisque erat eros viverra eget congue','luctus et ultrices'),(16,16,'2023-09-06',9,5,'pede ullamcorper augue','est phasellus sit amet erat nulla tempus vivamus','curabitur gravida'),(17,17,'2023-02-04',63,4,'pellentesque viverra','hendrerit at vulputate vitae nisl aenean lectus pellentesque','donec odio justo'),(18,18,'2023-03-29',42,6,'a libero nam','bibendum imperdiet nullam orci pede venenatis non','duis'),(19,19,'2023-11-15',15,2,'lorem vitae mattis','dis parturient montes nascetur ridiculus mus etiam','lorem quisque ut'),(20,20,'2023-01-22',38,3,'lacus at','interdum eu tincidunt in leo maecenas','et eros vestibulum'),(21,21,'2023-01-13',18,2,'vestibulum ante','placerat ante nulla justo aliquam','libero ut'),(22,22,'2023-02-05',29,8,'dapibus nulla','vel enim sit amet nunc viverra','pellentesque quisque porta'),(23,23,'2023-06-18',81,5,'rutrum','ut rhoncus aliquet pulvinar sed nisl nunc rhoncus','fusce lacus purus'),(24,24,'2023-06-11',91,7,'eros viverra eget','dignissim vestibulum vestibulum ante ipsum','blandit non'),(25,25,'2023-08-24',7,2,'accumsan','lectus pellentesque at nulla suspendisse potenti cras in','ante vel ipsum'),(26,26,'2023-06-04',24,6,'convallis','ut nunc vestibulum ante ipsum','fusce lacus purus'),(27,27,'2023-06-26',39,1,'at nunc','convallis morbi odio odio elementum','suspendisse ornare consequat'),(28,28,'2023-06-22',75,3,'donec','ut rhoncus aliquet pulvinar sed','convallis tortor risus'),(29,29,'2023-09-21',79,4,'sit amet','lacus morbi quis tortor id nulla ultrices','vel pede'),(30,30,'2023-12-14',32,10,'pede','ut nunc vestibulum ante ipsum primis','ante'),(31,31,'2023-08-31',88,5,'eu tincidunt','risus auctor sed tristique in tempus','sapien cum sociis'),(32,32,'2023-09-04',92,7,'scelerisque mauris sit','accumsan tellus nisi eu orci mauris lacinia','tortor risus dapibus'),(33,33,'2023-12-10',15,7,'tortor risus dapibus','in hac habitasse platea dictumst aliquam','integer ac neque'),(34,34,'2023-07-09',20,3,'eget','sed vel enim sit amet nunc','tempus'),(35,35,'2023-05-30',23,10,'vel','et ultrices posuere cubilia curae','praesent lectus vestibulum'),(36,36,'2023-08-19',42,7,'turpis','bibendum imperdiet nullam orci pede venenatis non sodales','sed'),(37,37,'2023-07-21',18,6,'amet diam','sit amet nulla quisque arcu libero rutrum','pulvinar nulla'),(38,38,'2023-06-27',2,9,'pede','nulla mollis molestie lorem quisque','ut volutpat sapien'),(39,39,'2023-07-13',75,2,'phasellus','velit eu est congue elementum in hac','varius'),(40,40,'2023-10-10',46,10,'venenatis lacinia aenean','dui vel nisl duis ac nibh fusce','convallis nunc proin'),(41,41,'2023-10-10',97,7,'metus aenean','dapibus duis at velit eu est congue elementum','vel est donec'),(42,42,'2023-08-12',16,4,'pede justo eu','metus vitae ipsum aliquam non mauris morbi non','dapibus dolor vel'),(43,43,'2023-04-18',70,1,'nulla justo aliquam','justo etiam pretium iaculis justo','nibh'),(44,44,'2023-03-21',78,6,'sit','dapibus nulla suscipit ligula in lacus','aliquam erat'),(45,45,'2023-01-24',2,8,'mattis','lectus in est risus auctor sed tristique','hac habitasse platea'),(46,46,'2023-11-08',72,6,'nullam orci pede','sed interdum venenatis turpis enim','mus etiam'),(47,47,'2023-10-28',96,4,'in hac habitasse','odio odio elementum eu interdum','at nulla suspendisse'),(48,48,'2023-09-27',49,2,'tortor risus dapibus','interdum mauris non ligula pellentesque','orci pede venenatis'),(49,49,'2023-01-30',42,4,'convallis tortor','sapien non mi integer ac neque duis','enim'),(50,50,'2023-11-17',31,2,'nam','tellus in sagittis dui vel','pretium'),(51,51,'2023-09-04',28,6,'quis turpis eget','pellentesque ultrices phasellus id sapien','nisl'),(52,52,'2023-08-02',25,2,'hac habitasse','et eros vestibulum ac est lacinia','dictumst morbi'),(53,53,'2023-08-21',14,10,'nulla','quis tortor id nulla ultrices','ipsum'),(54,54,'2023-03-29',62,10,'sit amet turpis','donec diam neque vestibulum eget vulputate ut ultrices','cum'),(55,55,'2023-11-08',45,9,'nulla tempus vivamus','at vulputate vitae nisl aenean lectus pellentesque eget','tempus'),(56,56,'2023-10-08',12,2,'morbi','justo nec condimentum neque sapien placerat ante nulla','morbi'),(57,57,'2023-07-02',1,7,'nonummy','nulla tempus vivamus in felis eu','luctus cum'),(58,58,'2023-04-12',70,4,'eget rutrum','massa id nisl venenatis lacinia','duis bibendum'),(59,59,'2023-09-26',85,5,'ornare consequat lectus','nisl ut volutpat sapien arcu sed augue','ornare consequat lectus'),(60,60,'2023-12-16',9,2,'in congue etiam','proin leo odio porttitor id consequat in consequat','sit'),(61,61,'2023-12-21',65,5,'at','erat id mauris vulputate elementum nullam varius nulla','molestie hendrerit'),(62,62,'2023-08-30',25,2,'posuere','lacus at velit vivamus vel nulla eget eros','donec posuere'),(63,63,'2023-12-27',57,2,'curabitur in','primis in faucibus orci luctus','eget massa tempor'),(64,64,'2023-07-20',34,6,'morbi','ac nulla sed vel enim sit amet','ut suscipit'),(65,65,'2023-09-15',98,3,'imperdiet','nulla suspendisse potenti cras in purus eu','tristique fusce'),(66,66,'2023-10-26',23,3,'neque sapien placerat','molestie sed justo pellentesque viverra pede ac','sem fusce'),(67,67,'2023-07-11',60,1,'sit','in sagittis dui vel nisl duis','in lectus pellentesque'),(68,68,'2023-03-20',89,8,'leo odio','ullamcorper augue a suscipit nulla','donec pharetra magna'),(69,69,'2023-04-13',46,1,'vestibulum','et ultrices posuere cubilia curae nulla','cursus vestibulum proin'),(70,70,'2023-10-07',94,6,'sed vel','magna bibendum imperdiet nullam orci pede','at turpis'),(71,71,'2023-04-29',70,9,'eget vulputate','pede ullamcorper augue a suscipit nulla elit ac','a feugiat'),(72,72,'2023-01-04',78,1,'purus aliquet at','turpis adipiscing lorem vitae mattis','interdum'),(73,73,'2023-04-20',92,9,'maecenas tincidunt lacus','ut massa quis augue luctus tincidunt nulla mollis','morbi'),(74,74,'2023-02-06',79,1,'neque vestibulum eget','nullam sit amet turpis elementum ligula vehicula','nam congue'),(75,75,'2023-09-04',8,10,'in','phasellus in felis donec semper sapien a','vel pede morbi'),(76,76,'2023-08-29',42,3,'porttitor','nonummy maecenas tincidunt lacus at','duis faucibus accumsan'),(77,77,'2023-11-23',69,2,'vehicula','habitasse platea dictumst etiam faucibus cursus urna','luctus rutrum'),(78,78,'2023-05-10',12,6,'odio','nonummy maecenas tincidunt lacus at velit vivamus vel','accumsan'),(79,79,'2023-07-27',24,5,'in faucibus orci','nunc purus phasellus in felis donec semper sapien','justo sollicitudin'),(80,80,'2023-07-22',87,8,'ipsum praesent blandit','tellus nulla ut erat id','nulla elit'),(81,81,'2023-09-17',29,4,'dolor sit amet','elit proin risus praesent lectus vestibulum quam sapien','nisl'),(82,82,'2023-01-19',85,2,'dui luctus rutrum','dui maecenas tristique est et tempus semper','aenean'),(83,83,'2023-02-09',37,6,'consectetuer','eu nibh quisque id justo sit amet sapien','nulla tellus'),(84,84,'2023-08-14',63,3,'id pretium iaculis','praesent blandit lacinia erat vestibulum sed magna','auctor sed tristique'),(85,85,'2023-03-24',68,4,'placerat ante nulla','lobortis vel dapibus at diam nam tristique tortor','massa'),(86,86,'2023-11-17',73,7,'posuere cubilia','pellentesque at nulla suspendisse potenti cras in purus','euismod scelerisque'),(87,87,'2023-11-05',63,7,'curae nulla','enim in tempor turpis nec euismod scelerisque quam','cubilia curae mauris'),(88,88,'2023-07-27',31,1,'ultrices mattis','pulvinar nulla pede ullamcorper augue a suscipit nulla','et eros'),(89,89,'2023-11-27',85,2,'dignissim','sit amet erat nulla tempus vivamus in felis','eget'),(90,90,'2023-03-01',90,8,'nibh in','non pretium quis lectus suspendisse potenti','in quam fringilla'),(91,91,'2023-02-14',26,8,'rhoncus mauris','adipiscing lorem vitae mattis nibh ligula','iaculis'),(92,92,'2023-03-13',10,9,'sapien arcu','bibendum imperdiet nullam orci pede','diam'),(93,93,'2023-11-11',37,9,'consequat','posuere metus vitae ipsum aliquam non mauris','suspendisse'),(94,94,'2023-04-30',3,4,'aliquam non','molestie lorem quisque ut erat curabitur gravida nisi','hendrerit at'),(95,95,'2023-02-13',66,1,'sapien varius','sem fusce consequat nulla nisl','vivamus'),(96,96,'2023-10-21',30,7,'non lectus','aliquam convallis nunc proin at turpis a pede','in'),(97,97,'2023-12-28',75,5,'lacinia eget','convallis eget eleifend luctus ultricies eu nibh','auctor sed'),(98,98,'2023-07-15',43,8,'condimentum','ut ultrices vel augue vestibulum ante','ac consequat'),(99,99,'2023-03-14',92,2,'sit amet','aliquam quis turpis eget elit','aliquet maecenas'),(100,100,'2023-06-09',61,3,'sed vel enim','in faucibus orci luctus et ultrices','dolor');
/*!40000 ALTER TABLE `performance_reviews` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `position_employee_assignment`
--

DROP TABLE IF EXISTS `position_employee_assignment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `position_employee_assignment` (
  `position_employee_assignment_id` int unsigned NOT NULL,
  `job_position_id` int unsigned NOT NULL,
  `employee_id` int unsigned NOT NULL,
  PRIMARY KEY (`position_employee_assignment_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `position_employee_assignment`
--

LOCK TABLES `position_employee_assignment` WRITE;
/*!40000 ALTER TABLE `position_employee_assignment` DISABLE KEYS */;
INSERT INTO `position_employee_assignment` VALUES (1,1,10),(2,2,81),(3,3,9),(4,4,50),(5,5,86),(6,6,90),(7,7,14),(8,8,58),(9,9,27),(10,10,84),(11,11,46),(12,12,92),(13,13,83),(14,14,80),(15,15,28),(16,16,43),(17,17,97),(18,18,80),(19,19,50),(20,20,4),(21,21,39),(22,22,15),(23,23,34),(24,24,91),(25,25,3),(26,26,53),(27,27,15),(28,28,78),(29,29,47),(30,30,37),(31,31,99),(32,32,48),(33,33,75),(34,34,63),(35,35,2),(36,36,42),(37,37,13),(38,38,57),(39,39,37),(40,40,33),(41,41,69),(42,42,76),(43,43,72),(44,44,78),(45,45,35),(46,46,50),(47,47,92),(48,48,62),(49,49,33),(50,50,26),(51,51,2),(52,52,20),(53,53,37),(54,54,66),(55,55,74),(56,56,40),(57,57,96),(58,58,93),(59,59,63),(60,60,53),(61,61,43),(62,62,57),(63,63,67),(64,64,90),(65,65,11),(66,66,58),(67,67,24),(68,68,47),(69,69,65),(70,70,9),(71,71,93),(72,72,24),(73,73,50),(74,74,82),(75,75,87),(76,76,53),(77,77,42),(78,78,87),(79,79,50),(80,80,96),(81,81,31),(82,82,51),(83,83,97),(84,84,18),(85,85,6),(86,86,99),(87,87,88),(88,88,70),(89,89,64),(90,90,50),(91,91,91),(92,92,60),(93,93,84),(94,94,80),(95,95,50),(96,96,42),(97,97,74),(98,98,57),(99,99,2),(100,100,57);
/*!40000 ALTER TABLE `position_employee_assignment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tax_identification_no`
--

DROP TABLE IF EXISTS `tax_identification_no`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tax_identification_no` (
  `tax_identification_number` int NOT NULL,
  `identification_type` varchar(100) DEFAULT NULL,
  `issuing_agency` varchar(100) DEFAULT NULL,
  `employee_id` int DEFAULT NULL,
  PRIMARY KEY (`tax_identification_number`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tax_identification_no`
--

LOCK TABLES `tax_identification_no` WRITE;
/*!40000 ALTER TABLE `tax_identification_no` DISABLE KEYS */;
/*!40000 ALTER TABLE `tax_identification_no` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `training_category`
--

DROP TABLE IF EXISTS `training_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `training_category` (
  `training_category_id` int unsigned NOT NULL,
  `training_category_name` varchar(100) DEFAULT NULL,
  `training_category_explain` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`training_category_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `training_category`
--

LOCK TABLES `training_category` WRITE;
/*!40000 ALTER TABLE `training_category` DISABLE KEYS */;
INSERT INTO `training_category` VALUES (1,'Sari Blick','cubilia curae donec pharetra'),(2,'Cornelle Bayley','accumsan odio curabitur'),(3,'Harv Addams','eros suspendisse accumsan tortor quis'),(4,'Loria Linforth','nulla suscipit ligula in'),(5,'Odey Auguste','ante vivamus tortor duis mattis'),(6,'Ivan Conry','est risus auctor'),(7,'Ryun Robertson','curabitur gravida nisi at nibh'),(8,'Julia Mowlam','mattis pulvinar nulla pede ullamcorper'),(9,'Terrance Senecaut','lectus aliquam sit'),(10,'Hewitt Turville','tempor turpis nec euismod'),(11,'Heath Pavier','sed sagittis nam congue'),(12,'Scott Bamford','mi pede malesuada in imperdiet'),(13,'Angelico Carnier','id luctus nec'),(14,'Blaire Beau','massa donec dapibus'),(15,'Ginnifer Roake','arcu adipiscing molestie'),(16,'Shara Franz-Schoninger','pulvinar sed nisl nunc'),(17,'Kalvin Scarbarrow','congue eget semper rutrum nulla'),(18,'Marven Annesley','metus aenean fermentum'),(19,'Beryl Kurton','sapien sapien non'),(20,'Meta Cowherd','vivamus vestibulum sagittis'),(21,'Federica Knowller','nisl nunc nisl duis bibendum'),(22,'Alf Hars','quisque id justo sit amet'),(23,'Niall McAloren','in magna bibendum imperdiet nullam'),(24,'Pace Quinane','amet cursus id'),(25,'Zondra Estable','in tempus sit amet sem'),(26,'Roldan Swatten','semper sapien a libero nam'),(27,'Judi McGonigle','dui luctus rutrum'),(28,'Jannel Astupenas','eget tempus vel pede morbi'),(29,'Malvin Jadczak','vestibulum ante ipsum primis'),(30,'Jorie Guise','ut dolor morbi vel'),(31,'Hinda McManamen','vitae mattis nibh'),(32,'Dinny Simeons','ligula suspendisse ornare consequat lectus'),(33,'Kerrill Gotliffe','nisi vulputate nonummy maecenas'),(34,'Allix Finnes','porta volutpat erat'),(35,'Adriane Kennifeck','sed vestibulum sit amet'),(36,'Zaneta Furmagier','semper rutrum nulla nunc purus'),(37,'Leonardo Clubbe','suspendisse potenti nullam'),(38,'Engracia Howles','vel ipsum praesent blandit lacinia'),(39,'Humfried Fairhead','massa id lobortis convallis'),(40,'Gweneth Lambarth','vel augue vestibulum'),(41,'Marmaduke Vigours','non mauris morbi'),(42,'Blythe Swendell','ante ipsum primis in'),(43,'Berty Delve','magna vestibulum aliquet'),(44,'Natka Minney','integer non velit donec'),(45,'Carmela Eliyahu','venenatis tristique fusce congue diam'),(46,'Katerina Burdett','ligula suspendisse ornare'),(47,'Georgena Gretton','curae nulla dapibus'),(48,'Anny Screeton','nulla quisque arcu libero rutrum'),(49,'Mead Alennikov','quam pharetra magna'),(50,'Sissy Fincke','sit amet sapien'),(51,'Beatrix Vlahos','id mauris vulputate elementum'),(52,'Craggie Gyver','ut erat id mauris'),(53,'Zelma Bullough','donec diam neque'),(54,'Micky Corsor','aliquam sit amet'),(55,'Cos Spataro','ultricies eu nibh quisque'),(56,'Kariotta Iglesias','vulputate justo in blandit ultrices'),(57,'Elsy Crumpe','amet sapien dignissim vestibulum'),(58,'Chaddie Bottomer','dapibus nulla suscipit'),(59,'Lilly Mowle','velit donec diam'),(60,'Britta Weir','felis fusce posuere felis sed'),(61,'Florance Putten','maecenas leo odio condimentum'),(62,'Waite Harriday','ante vel ipsum'),(63,'Dev Doodney','interdum venenatis turpis enim'),(64,'Melessa Macbeth','nulla integer pede justo lacinia'),(65,'Drusie Camocke','ipsum primis in faucibus'),(66,'Domingo Pardoe','ultrices posuere cubilia curae mauris'),(67,'Prentice Deare','donec ut dolor'),(68,'Gwenny Hindmore','ridiculus mus etiam vel augue'),(69,'Nanice Krysztowczyk','ligula sit amet'),(70,'Cairistiona Fitzpatrick','potenti nullam porttitor'),(71,'Stillman Lewnden','montes nascetur ridiculus mus etiam'),(72,'Yvonne Skerritt','rhoncus mauris enim leo rhoncus'),(73,'Uriah Bompas','convallis nunc proin'),(74,'Tommy Featherstone','felis sed lacus morbi sem'),(75,'Timmi Kerrod','turpis sed ante vivamus'),(76,'Ardisj McAtamney','ligula nec sem duis'),(77,'Jefferson Leonarde','in hac habitasse platea'),(78,'Aubrey Renols','nonummy maecenas tincidunt lacus at'),(79,'Hermann Whyatt','tristique est et'),(80,'Kaila Bates','risus auctor sed tristique'),(81,'Rodney Larmour','erat id mauris'),(82,'Land Dodamead','nunc nisl duis bibendum felis'),(83,'Kelsi Gouldstraw','potenti cras in purus eu'),(84,'Ara Warin','ut massa quis'),(85,'Elisha Overil','at dolor quis'),(86,'Wood Klehn','nec molestie sed'),(87,'Jaye Prescot','nunc donec quis orci'),(88,'Perice Beales','nullam molestie nibh in lectus'),(89,'Hansiain Gloyens','ut volutpat sapien arcu sed'),(90,'Jenny Danielsson','amet justo morbi ut odio'),(91,'Junia Soughton','ut blandit non interdum'),(92,'Orson Ayris','in sagittis dui vel nisl'),(93,'Moises Cathenod','posuere felis sed lacus'),(94,'Rebekkah McCullock','scelerisque mauris sit'),(95,'Caye Rappaport','ut suscipit a'),(96,'Dayna Kuhlmey','ante vestibulum ante'),(97,'Sarette Sergison','cubilia curae donec pharetra'),(98,'Rice Maidment','sed augue aliquam'),(99,'Renato Coopland','pulvinar lobortis est phasellus'),(100,'Leonerd Blount','quam sollicitudin vitae consectetuer');
/*!40000 ALTER TABLE `training_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `training_certifications`
--

DROP TABLE IF EXISTS `training_certifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `training_certifications` (
  `certification_id` int unsigned NOT NULL,
  `employee_id` int unsigned NOT NULL,
  `certification_name` varchar(100) DEFAULT NULL,
  `certification_date` date DEFAULT NULL,
  `expiration_date` date DEFAULT NULL,
  `training_provider` varchar(1000) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `training_comments` text,
  PRIMARY KEY (`certification_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `training_certifications`
--

LOCK TABLES `training_certifications` WRITE;
/*!40000 ALTER TABLE `training_certifications` DISABLE KEYS */;
INSERT INTO `training_certifications` VALUES (1,1,'Madlin Agirre','2024-02-16','2030-08-07','Sawyere de Lloyd','aliquam quis turpis eget'),(2,2,'Rickey Goodwell','2024-06-05','2030-01-06','Kerrill Bertelsen','vel lectus in quam'),(3,3,'Cesar Michurin','2024-07-20','2030-06-30','Cherri MacGuffie','maecenas tristique est et'),(4,4,'Gale Smiths','2024-09-04','2030-02-13','Vanna Blum','posuere cubilia curae duis faucibus'),(5,5,'Hester MacDuffie','2024-11-17','2030-09-17','Angelle Jagiela','justo lacinia eget tincidunt eget'),(6,6,'Melodie Fairclough','2024-04-15','2030-08-27','Fulton Bozworth','venenatis turpis enim blandit'),(7,7,'Blanch Popplewell','2024-07-09','2030-12-22','Taite Barszczewski','sed lacus morbi sem'),(8,8,'Kathleen Dionis','2024-08-28','2030-12-12','Toinette Antczak','nullam porttitor lacus at turpis'),(9,9,'Terrell Aymes','2024-09-16','2030-06-20','Bliss Magwood','libero nam dui proin'),(10,10,'Jasmin Wemes','2024-09-23','2030-05-14','Matthew Tattershaw','lorem quisque ut erat curabitur'),(11,11,'Berget O\'Towey','2024-05-10','2030-09-03','Gerrie Trewinnard','vestibulum sagittis sapien cum'),(12,12,'Milly Canfer','2024-02-04','2030-12-18','Billie Stroulger','leo pellentesque ultrices'),(13,13,'Audie Richarson','2024-01-26','2030-02-05','Breanne Grimstead','lacus purus aliquet at'),(14,14,'Mona Lampard','2024-05-03','2030-12-30','Curt Curley','quam pede lobortis ligula'),(15,15,'Orelle Hadley','2024-05-31','2030-01-28','Philbert Lago','sapien in sapien'),(16,16,'Hesther Goodnow','2024-02-16','2030-09-12','Giacopo Mirfin','vehicula consequat morbi'),(17,17,'Rivy Nathan','2024-08-23','2030-11-19','Jodi Yaxley','magna ac consequat metus sapien'),(18,18,'Brinn Desquesnes','2024-02-03','2030-04-01','Gregory Monkhouse','praesent blandit nam nulla'),(19,19,'Barbaraanne Derisley','2024-04-19','2030-01-22','Liliane McBrearty','turpis adipiscing lorem'),(20,20,'Nanci Service','2024-12-04','2030-03-26','Cassie Elks','sapien dignissim vestibulum'),(21,21,'Antonietta Bissell','2024-02-05','2030-11-26','Allayne Aizkovitch','fusce lacus purus aliquet'),(22,22,'Darb Cowope','2024-12-02','2030-06-06','Glenn Yewen','pellentesque eget nunc'),(23,23,'Concordia Scammonden','2024-09-23','2030-02-09','Zonnya Orans','ut odio cras'),(24,24,'Thomasin Arnley','2024-08-01','2030-05-16','Susie Simony','platea dictumst morbi'),(25,25,'Poul Tzuker','2024-03-10','2030-09-15','Jenda McIntee','congue eget semper rutrum'),(26,26,'Shelli Meas','2024-02-05','2030-01-24','Amalle Pentin','eget eros elementum pellentesque'),(27,27,'Robbin Haggath','2024-10-22','2030-05-27','Everard Engley','consequat ut nulla'),(28,28,'Sarine Vannozzii','2024-03-02','2030-05-05','Zaccaria Souch','tortor quis turpis sed ante'),(29,29,'Gerick Wilstead','2024-06-30','2030-10-26','Patrice Bailles','rhoncus mauris enim leo'),(30,30,'Suzie Saenz','2024-06-24','2030-09-04','Ruby Stoakes','sapien ut nunc'),(31,31,'Morgan Utton','2024-10-18','2030-03-10','Virgie Hofler','sagittis dui vel nisl duis'),(32,32,'Jodi Angove','2024-07-06','2030-10-25','Wald Verheijden','bibendum felis sed interdum'),(33,33,'Janette Eddy','2024-06-03','2030-11-01','Kienan Klugman','massa id nisl venenatis lacinia'),(34,34,'Burl Greenside','2024-10-28','2030-04-10','Saunders Clarke-Williams','rhoncus mauris enim'),(35,35,'Kirsten Farndell','2024-12-19','2030-08-26','Diane Hughson','nisi venenatis tristique fusce congue'),(36,36,'Courtnay Willshaw','2024-04-26','2030-02-02','Candide McCaffrey','dictumst aliquam augue'),(37,37,'Marie Frankel','2024-11-24','2030-05-29','Marena Studd','molestie lorem quisque'),(38,38,'Ingaberg Vines','2024-06-13','2030-05-05','Natalina Ivashintsov','id massa id nisl'),(39,39,'Erminia Grandison','2024-04-23','2030-06-12','Leif Tottie','vel accumsan tellus nisi eu'),(40,40,'August Silson','2024-09-28','2030-01-09','Dalila Reede','sed accumsan felis ut'),(41,41,'Lowrance Olivetti','2024-10-09','2030-09-20','Manuel Gilliver','sodales scelerisque mauris sit'),(42,42,'Gerardo Mount','2024-02-04','2030-11-10','Homer Bogie','duis faucibus accumsan odio curabitur'),(43,43,'Lotty Lindup','2024-11-04','2030-08-28','Friedrick Managh','tristique fusce congue diam id'),(44,44,'Edd Gregersen','2024-07-05','2030-11-23','Teddy Greenman','justo nec condimentum neque sapien'),(45,45,'Dolly Gilffillan','2024-05-07','2030-09-04','Jonas Toghill','luctus ultricies eu'),(46,46,'Gasparo Roseborough','2024-10-27','2030-01-12','Elspeth Skeen','integer ac neque'),(47,47,'Cecile Celli','2024-05-14','2030-07-02','Rab Brobak','dolor quis odio consequat varius'),(48,48,'Vito Pleasants','2024-12-26','2030-01-20','Philbert McMorland','ultrices posuere cubilia curae donec'),(49,49,'Brunhilda Gilbane','2024-02-12','2030-05-20','Felicio Lope','maecenas leo odio'),(50,50,'Durward Pegg','2024-04-19','2030-06-02','Onida Canero','faucibus accumsan odio curabitur convallis'),(51,51,'Audie Dolan','2024-01-13','2030-01-18','Owen Spores','tellus semper interdum mauris'),(52,52,'Stephi Rheubottom','2024-02-29','2030-06-21','Alfy Cockren','sapien varius ut blandit non'),(53,53,'Shayna Boichat','2024-01-25','2030-05-25','Lee McElroy','fermentum justo nec condimentum neque'),(54,54,'Franklyn Kemmer','2024-09-14','2030-12-08','Ringo Corwood','volutpat convallis morbi odio'),(55,55,'Isabelle Headland','2024-03-26','2030-09-27','Alie Rallin','morbi sem mauris laoreet'),(56,56,'Hedvige Synke','2024-01-04','2030-03-25','Errol Rothera','at nunc commodo'),(57,57,'Lydie MacLleese','2024-02-27','2030-04-09','Dall Josskovitz','eget massa tempor convallis'),(58,58,'Danita Dowdeswell','2024-02-14','2030-08-22','Glenden Bellow','mattis pulvinar nulla'),(59,59,'Francois Ennion','2024-12-25','2030-09-21','Gwennie Paschek','eu nibh quisque'),(60,60,'Horace Hartrick','2024-06-26','2030-01-24','Homere LAbbet','semper sapien a'),(61,61,'Caleb Grumbridge','2024-04-27','2030-04-23','Cacilie Steane','integer pede justo lacinia'),(62,62,'Harland Ridett','2024-06-25','2030-05-05','Blondell Constance','semper porta volutpat quam pede'),(63,63,'Calli Freckleton','2024-08-19','2030-02-17','Joelly St. Ledger','convallis eget eleifend luctus ultricies'),(64,64,'Richy Petyt','2024-11-15','2030-07-15','Caesar Feek','vel augue vestibulum rutrum'),(65,65,'Julee Fellow','2024-05-01','2030-12-12','Lina Maes','pulvinar lobortis est'),(66,66,'Georgena Brennans','2024-01-23','2030-11-03','Garrek Ellicock','morbi non quam nec'),(67,67,'Grazia Antony','2024-07-11','2030-01-16','Almeda Moulden','hac habitasse platea'),(68,68,'Ynez Fotherby','2024-02-04','2030-08-12','Jena Rabbitt','vel augue vestibulum ante'),(69,69,'Norean Bullimore','2024-12-12','2030-04-19','Mireielle Regglar','quam a odio in hac'),(70,70,'Marcelia Goding','2024-09-02','2030-06-30','Hardy Dennes','at nibh in'),(71,71,'Joeann Roocroft','2024-09-22','2030-08-12','Martynne Dudman','ipsum dolor sit'),(72,72,'Aurilia Brydie','2024-01-17','2030-12-23','Lynn Emmert','et ultrices posuere cubilia curae'),(73,73,'Celinda Hentzeler','2024-07-28','2030-03-31','Rivy Buckston','posuere cubilia curae nulla'),(74,74,'Joice Bellerby','2024-10-03','2030-01-30','Lesley Proswell','ac consequat metus sapien ut'),(75,75,'Ugo Berriman','2024-02-29','2030-12-13','Devlin O\'Hare','a ipsum integer a'),(76,76,'Crosby Dionsetti','2024-06-15','2030-05-10','Gleda Pedracci','dui vel nisl duis ac'),(77,77,'Claiborne Chucks','2024-08-04','2030-08-06','Livvy Takle','amet eros suspendisse accumsan tortor'),(78,78,'Karina Besset','2024-06-14','2030-11-24','Harland Surfleet','rutrum ac lobortis'),(79,79,'Emmi Gabbitas','2024-01-31','2030-03-20','Abramo Kennon','vel nisl duis ac'),(80,80,'Flossy Trumble','2024-08-17','2030-01-04','Lise Abotson','a odio in hac habitasse'),(81,81,'Nilson Wasselin','2024-09-12','2030-03-31','Gunter Vollam','vestibulum ante ipsum primis'),(82,82,'Erasmus Goskar','2024-02-20','2030-10-08','Ad Pelzer','nulla suspendisse potenti cras in'),(83,83,'Cordula Neles','2024-02-24','2030-02-21','Florella Choak','lacus purus aliquet at'),(84,84,'Malachi Vere','2024-02-16','2030-10-21','Delmore Maffioni','massa id lobortis'),(85,85,'Moe Sarton','2024-08-27','2030-07-07','Michel Paulet','non interdum in'),(86,86,'Claiborne Gettins','2024-05-31','2030-09-05','Brok Thys','nibh ligula nec sem duis'),(87,87,'Evyn Sacks','2024-05-15','2030-02-15','Beulah Emer','leo odio porttitor id'),(88,88,'Christy O\' Shea','2024-01-17','2030-06-30','Lorinda Dumpleton','consequat nulla nisl nunc nisl'),(89,89,'Tandi Insko','2024-08-31','2030-11-11','Sunshine Rainey','lacus at turpis donec posuere'),(90,90,'Brnaba Camamile','2024-07-06','2030-08-02','Hedwig Paulazzi','erat vestibulum sed magna at'),(91,91,'Farly McDarmid','2024-03-15','2030-08-27','Eolande Ousley','accumsan tortor quis'),(92,92,'Kristofor Davidovic','2024-09-24','2030-12-08','Roda Bourgeois','faucibus cursus urna ut'),(93,93,'Ara Bengall','2024-11-16','2030-10-14','Eugenius Wittrington','lacus purus aliquet at'),(94,94,'Codi Snoding','2024-08-31','2030-03-18','Genni Bygreaves','id mauris vulputate elementum nullam'),(95,95,'Rebecca Slimmon','2024-11-09','2030-11-15','Addia Slaymaker','platea dictumst maecenas'),(96,96,'Reinold Doohey','2024-05-29','2030-06-24','Annnora Lanfranchi','id pretium iaculis'),(97,97,'Hetty Jaegar','2024-09-13','2030-09-24','Caprice Moro','tincidunt eget tempus'),(98,98,'Vikki Cadlock','2024-01-16','2030-06-16','Sherie Philip','orci luctus et ultrices'),(99,99,'Rurik Riggulsford','2024-09-11','2030-10-27','Conroy Busby','amet justo morbi ut'),(100,100,'Giffie Volonte','2024-04-14','2030-11-08','Meredithe Faircliff','vel sem sed');
/*!40000 ALTER TABLE `training_certifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `training_courses`
--

DROP TABLE IF EXISTS `training_courses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `training_courses` (
  `course_id` int unsigned NOT NULL,
  `course_name` varchar(100) DEFAULT NULL,
  `course_category_id` int unsigned NOT NULL,
  `class_hours` int DEFAULT NULL,
  `credit_hours` int DEFAULT NULL,
  `examination_method` varchar(100) DEFAULT NULL,
  `instructor_name` varchar(100) DEFAULT NULL,
  `course_explain` text,
  PRIMARY KEY (`course_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `training_courses`
--

LOCK TABLES `training_courses` WRITE;
/*!40000 ALTER TABLE `training_courses` DISABLE KEYS */;
INSERT INTO `training_courses` VALUES (1,'lobortis sapien sapien non mi integer ac neque duis bibendum',97,48,5,'arcu adipiscing molestie hendrerit','Dani Golly','accumsan odio curabitur convallis duis'),(2,'dapibus dolor vel est donec odio justo sollicitudin ut suscipit a feugiat',66,43,5,'orci luctus et ultrices','Jabez Pettingill','condimentum curabitur in libero ut'),(3,'vel lectus in quam fringilla rhoncus mauris enim leo rhoncus sed vestibulum',81,47,3,'semper interdum mauris ullamcorper purus','Yetta Deacon','ac nibh fusce lacus'),(5,'convallis tortor risus dapibus augue vel accumsan tellus nisi eu orci mauris lacinia sapien quis',10,47,4,'mi integer ac neque duis','Luce Blesli','integer ac leo pellentesque'),(7,'maecenas pulvinar lobortis est phasellus sit amet erat nulla tempus vivamus in felis eu sapien',94,45,5,'quis orci eget','Anne-corinne Woodeson','nunc purus phasellus in felis'),(8,'vitae quam suspendisse potenti nullam porttitor lacus at turpis donec posuere metus vitae ipsum',33,49,3,'nulla quisque arcu','Julianne Zoren','blandit ultrices enim lorem ipsum'),(10,'non mauris morbi non lectus aliquam sit amet diam in magna bibendum imperdiet nullam orci',36,50,5,'primis in faucibus','Izaak Callinan','elit proin risus praesent'),(12,'mattis pulvinar nulla pede ullamcorper augue a suscipit nulla elit ac nulla sed',10,43,4,'cras pellentesque volutpat','Sheppard Juschka','dictumst maecenas ut'),(14,'ut tellus nulla ut erat id mauris vulputate elementum nullam varius nulla facilisi cras',76,42,5,'tortor sollicitudin mi','Valma Cutts','nulla quisque arcu libero rutrum'),(15,'curabitur gravida nisi at nibh in hac habitasse platea dictumst aliquam augue',47,49,4,'habitasse platea dictumst maecenas','Jessy Tomley','quis turpis sed'),(16,'cursus id turpis integer aliquet massa id lobortis convallis tortor risus dapibus augue',62,48,4,'habitasse platea dictumst aliquam augue','Constantina Hugues','vivamus vestibulum sagittis sapien cum'),(17,'at feugiat non pretium quis lectus suspendisse potenti in eleifend quam a odio in',42,47,3,'quis orci nullam molestie nibh','Cecil Peeter','fermentum justo nec condimentum'),(18,'quam sollicitudin vitae consectetuer eget rutrum at lorem integer tincidunt ante vel',66,46,4,'proin leo odio porttitor id','Valery Margarson','sit amet nulla quisque arcu'),(19,'donec pharetra magna vestibulum aliquet ultrices erat tortor sollicitudin mi',86,42,3,'pellentesque ultrices mattis odio','Lyman Melmar','ac est lacinia nisi'),(20,'ante vestibulum ante ipsum primis in faucibus orci luctus et',20,46,3,'molestie sed justo','Ruth Hallmark','luctus rutrum nulla'),(21,'neque sapien placerat ante nulla justo aliquam quis turpis eget',1,48,4,'ac leo pellentesque ultrices mattis','Shanan Sparry','id justo sit amet'),(24,'orci pede venenatis non sodales sed tincidunt eu felis fusce posuere felis sed lacus morbi sem',79,44,3,'lorem vitae mattis','Starla Willatt','enim lorem ipsum dolor sit'),(26,'nulla neque libero convallis eget eleifend luctus ultricies eu nibh quisque id justo',22,40,4,'habitasse platea dictumst aliquam','Ruperta Purser','ligula nec sem duis aliquam'),(29,'eget eros elementum pellentesque quisque porta volutpat erat quisque erat eros',71,49,4,'libero ut massa','Ole McMains','diam id ornare imperdiet sapien'),(31,'dapibus dolor vel est donec odio justo sollicitudin ut suscipit a feugiat et eros vestibulum',84,49,4,'at nulla suspendisse potenti','Melva MacConnulty','integer ac leo'),(32,'ligula suspendisse ornare consequat lectus in est risus auctor sed',90,47,3,'parturient montes nascetur','Trix Connolly','quis augue luctus tincidunt'),(33,'lectus pellentesque eget nunc donec quis orci eget orci vehicula condimentum',59,49,3,'nam tristique tortor','Toni Munford','nisl ut volutpat sapien arcu'),(34,'ultrices posuere cubilia curae nulla dapibus dolor vel est donec odio justo sollicitudin ut suscipit',14,48,5,'vestibulum ante ipsum primis in','Neilla Barke','integer ac neque duis bibendum'),(35,'justo maecenas rhoncus aliquam lacus morbi quis tortor id nulla ultrices aliquet maecenas',100,47,5,'proin at turpis a pede','Tine Klehyn','id nisl venenatis lacinia aenean'),(36,'ut erat curabitur gravida nisi at nibh in hac habitasse platea dictumst aliquam augue',11,40,4,'sed vestibulum sit','Alexandrina Wardlaw','lacus at turpis donec'),(41,'nec dui luctus rutrum nulla tellus in sagittis dui vel nisl duis ac',43,47,3,'in congue etiam justo etiam','Janeen MacQueen','pede malesuada in imperdiet'),(44,'phasellus in felis donec semper sapien a libero nam dui',94,42,5,'scelerisque quam turpis adipiscing','Quintin Rozet','eu nibh quisque id justo'),(45,'in hac habitasse platea dictumst etiam faucibus cursus urna ut tellus nulla ut erat id',36,41,3,'sapien in sapien','Liuka Eaklee','posuere cubilia curae mauris'),(46,'nisl venenatis lacinia aenean sit amet justo morbi ut odio cras mi pede malesuada',55,45,5,'nunc donec quis orci eget','Sari Vela','pede malesuada in imperdiet et'),(47,'ut erat id mauris vulputate elementum nullam varius nulla facilisi cras',36,42,5,'nam tristique tortor','Liane Drysdell','pede justo lacinia eget'),(51,'morbi non quam nec dui luctus rutrum nulla tellus in sagittis dui vel nisl duis ac',95,41,4,'in consequat ut','Sigismundo McGahy','convallis eget eleifend'),(52,'cubilia curae donec pharetra magna vestibulum aliquet ultrices erat tortor',48,40,3,'dui nec nisi volutpat','Kristen Wills','felis fusce posuere felis'),(53,'integer a nibh in quis justo maecenas rhoncus aliquam lacus morbi quis',22,43,4,'duis bibendum morbi','Jerrold Biner','in eleifend quam a odio'),(54,'at vulputate vitae nisl aenean lectus pellentesque eget nunc donec quis orci eget orci vehicula',34,49,4,'augue vestibulum rutrum rutrum','Walther Limprecht','blandit lacinia erat vestibulum'),(55,'imperdiet nullam orci pede venenatis non sodales sed tincidunt eu felis fusce posuere felis sed',30,47,4,'vitae mattis nibh ligula','Cynde Mattes','non lectus aliquam'),(56,'vel sem sed sagittis nam congue risus semper porta volutpat',83,42,4,'suspendisse potenti nullam','Chane Sarsfield','leo maecenas pulvinar'),(57,'felis sed lacus morbi sem mauris laoreet ut rhoncus aliquet pulvinar sed',20,47,3,'aliquam sit amet diam','Gunilla Geratasch','nullam sit amet'),(58,'bibendum felis sed interdum venenatis turpis enim blandit mi in porttitor',16,43,3,'fusce consequat nulla','Evangelia Duthy','elementum in hac habitasse'),(60,'justo morbi ut odio cras mi pede malesuada in imperdiet et commodo vulputate justo in',9,50,3,'cras in purus eu magna','Nickolas Figgs','sodales sed tincidunt'),(61,'elit proin risus praesent lectus vestibulum quam sapien varius ut blandit non interdum in ante',11,40,4,'vel augue vestibulum ante ipsum','Wallie Ferriby','pulvinar sed nisl'),(62,'nullam varius nulla facilisi cras non velit nec nisi vulputate nonummy maecenas tincidunt lacus at',93,40,4,'magna ac consequat metus sapien','Lev Dory','potenti cras in purus eu'),(63,'tincidunt nulla mollis molestie lorem quisque ut erat curabitur gravida nisi at nibh in',91,43,5,'sem fusce consequat nulla','Kirsteni Michallat','neque sapien placerat'),(64,'rhoncus mauris enim leo rhoncus sed vestibulum sit amet cursus',82,41,5,'accumsan tortor quis','Gonzalo Helliker','lacinia erat vestibulum'),(66,'ornare consequat lectus in est risus auctor sed tristique in tempus sit amet sem',60,40,3,'ultrices erat tortor sollicitudin','Kathy Dillaway','porta volutpat quam pede'),(68,'curae mauris viverra diam vitae quam suspendisse potenti nullam porttitor lacus',62,45,3,'lacinia sapien quis libero','Cherye Barnsley','elit sodales scelerisque mauris'),(69,'quam suspendisse potenti nullam porttitor lacus at turpis donec posuere',96,44,5,'in ante vestibulum','Jennie Whitelaw','diam in magna'),(70,'justo sollicitudin ut suscipit a feugiat et eros vestibulum ac est lacinia',24,41,5,'integer ac neque duis','Dianna Roggers','elit sodales scelerisque'),(71,'urna pretium nisl ut volutpat sapien arcu sed augue aliquam erat volutpat in congue etiam justo',14,49,4,'congue elementum in hac habitasse','Rafaello Lithgow','consequat lectus in'),(73,'sapien cursus vestibulum proin eu mi nulla ac enim in tempor',57,50,4,'dapibus augue vel accumsan','Ebenezer Broadfield','sed magna at'),(74,'nulla tempus vivamus in felis eu sapien cursus vestibulum proin eu',67,43,3,'suscipit a feugiat et','Nealson Gullberg','vel pede morbi'),(78,'eu orci mauris lacinia sapien quis libero nullam sit amet turpis elementum ligula vehicula consequat',47,47,3,'quis odio consequat varius','Horatio Challace','lacinia nisi venenatis tristique fusce'),(80,'sed magna at nunc commodo placerat praesent blandit nam nulla integer pede justo lacinia',2,43,3,'in hac habitasse platea dictumst','Tomasine Keemer','curae nulla dapibus'),(82,'ut blandit non interdum in ante vestibulum ante ipsum primis',50,41,5,'cum sociis natoque penatibus et','Ferdinanda Devennie','a odio in hac'),(83,'adipiscing elit proin risus praesent lectus vestibulum quam sapien varius',46,46,4,'amet sapien dignissim vestibulum vestibulum','Kelwin Beneix','dolor vel est donec'),(84,'mattis egestas metus aenean fermentum donec ut mauris eget massa',8,49,4,'lorem vitae mattis','Lorry Molyneaux','sapien arcu sed augue aliquam'),(87,'lorem integer tincidunt ante vel ipsum praesent blandit lacinia erat',73,46,3,'pulvinar nulla pede','Sally Tonkin','morbi ut odio'),(88,'nulla eget eros elementum pellentesque quisque porta volutpat erat quisque erat eros',61,40,5,'primis in faucibus orci','Neddie Mizen','maecenas tincidunt lacus'),(89,'ac nibh fusce lacus purus aliquet at feugiat non pretium quis lectus suspendisse potenti in eleifend',11,49,4,'odio porttitor id consequat in','Arni Boutcher','semper rutrum nulla'),(92,'quam pharetra magna ac consequat metus sapien ut nunc vestibulum ante ipsum primis',87,48,4,'id pretium iaculis diam','Sharline Lickess','vitae consectetuer eget rutrum'),(93,'consequat nulla nisl nunc nisl duis bibendum felis sed interdum venenatis turpis',57,42,5,'donec dapibus duis at','Courtney Di Biaggi','parturient montes nascetur ridiculus'),(95,'sem praesent id massa id nisl venenatis lacinia aenean sit',43,48,4,'vel lectus in quam fringilla','Mag Heersma','morbi porttitor lorem id'),(97,'justo in blandit ultrices enim lorem ipsum dolor sit amet',11,50,3,'vivamus vel nulla eget','Carree Millins','imperdiet sapien urna pretium'),(98,'viverra pede ac diam cras pellentesque volutpat dui maecenas tristique est et',69,50,3,'integer a nibh in','Mellisa Cosker','ullamcorper purus sit'),(100,'pellentesque at nulla suspendisse potenti cras in purus eu magna vulputate',27,44,5,'augue quam sollicitudin vitae','Ephrayim Ortega','semper sapien a libero nam');
/*!40000 ALTER TABLE `training_courses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `training_plan_courses`
--

DROP TABLE IF EXISTS `training_plan_courses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `training_plan_courses` (
  `training_plan_id` int unsigned NOT NULL,
  `course_code` int unsigned NOT NULL,
  `course_duration` int unsigned DEFAULT NULL,
  PRIMARY KEY (`training_plan_id`,`course_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `training_plan_courses`
--

LOCK TABLES `training_plan_courses` WRITE;
/*!40000 ALTER TABLE `training_plan_courses` DISABLE KEYS */;
INSERT INTO `training_plan_courses` VALUES (1,61,45),(2,11,45),(3,37,42),(4,97,45),(5,32,50),(6,42,48),(7,94,40),(8,64,47),(9,23,46),(10,3,45),(11,58,49),(12,45,45),(13,54,48),(14,68,46),(15,12,49),(16,48,49),(17,18,44),(18,27,40),(19,29,49),(20,14,47),(21,3,41),(22,52,44),(23,28,48),(24,55,47),(25,5,41),(26,55,40),(27,38,41),(28,62,49),(29,76,41),(30,55,43);
/*!40000 ALTER TABLE `training_plan_courses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `training_plans`
--

DROP TABLE IF EXISTS `training_plans`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `training_plans` (
  `training_plan_id` int unsigned NOT NULL,
  `training_plan_name` varchar(100) DEFAULT NULL,
  `training_category_code` char(100) DEFAULT NULL,
  `training_plan_description` varchar(2500) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `training_plan_start_date` date DEFAULT NULL,
  `training_plan_end_date` date DEFAULT NULL,
  `training_plan_location` varchar(2500) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `training_plan_contact_person` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`training_plan_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `training_plans`
--

LOCK TABLES `training_plans` WRITE;
/*!40000 ALTER TABLE `training_plans` DISABLE KEYS */;
INSERT INTO `training_plans` VALUES (1,'sbuffery0','RPR','Maternal care for excessive fetal growth, second trimester, other fetus','2023-03-03','2023-09-07','Velykyi Bereznyi','Stephani Buffery'),(2,'csully1','MRC','Dieulafoy lesion of intestine','2023-04-20','2023-08-30','Przystajan','Colby Sully'),(3,'aworkes2','MDY','Military operations involving fragments from munitions, civilian, initial encounter','2023-04-17','2023-12-12','Cileuya','Albertina Workes'),(4,'jtennant3','LTS','Inhalant use, unspecified with intoxication with delirium','2023-03-21','2023-07-21','Noen Maprang','Jedidiah Tennant'),(5,'fteissier4','GBK','Encounter for screening for malignant neoplasm of intestinal tract','2023-03-20','2023-07-23','Daja','Flint Teissier'),(6,'atompkiss5','RYN','Car passenger injured in noncollision transport accident in traffic accident, subsequent encounter','2023-03-23','2023-07-18','Duwayr Raslan','Adolpho Tompkiss'),(7,'tmillimoe6','TAQ','Person on outside of heavy transport vehicle injured in collision with heavy transport vehicle or bus in nontraffic accident, initial encounter','2023-04-09','2023-06-28','Kafr ad Daw','Tildi Millimoe'),(8,'avowels7','BZB','Poisoning by antidiarrheal drugs, accidental (unintentional), subsequent encounter','2023-01-21','2023-09-10','Citeluk','Amalea Vowels'),(9,'ucrommett8','WSM','Benign neoplasm of other specified female genital organs','2023-04-14','2023-10-11','Ayotupas','Ulberto Crommett'),(10,'kbaddow9','BLL','Fracture of subcondylar process of mandible, unspecified side, initial encounter for closed fracture','2023-03-29','2023-11-07','Aimadamodo','Kathlin Baddow'),(11,'vrouthorna','CRE','Displaced fracture of olecranon process without intraarticular extension of unspecified ulna, subsequent encounter for closed fracture with nonunion','2023-03-02','2023-11-02','Naopaulogo','Vivie Routhorn'),(12,'lpriddingb','MJR','Fracture of unspecified tarsal bone(s) of right foot, initial encounter for open fracture','2023-04-02','2023-06-07','Hengbanqiao','Lise Pridding'),(13,'dbolandc','HUG','Cellulitis of finger','2023-02-23','2023-08-25','Nassarawa','Dallas Boland'),(14,'rhovertd','KDX','Poisoning by unspecified psychostimulants, intentional self-harm, subsequent encounter','2023-05-13','2023-09-22','New York City','Raven Hovert'),(15,'afitte','ZKE','Activities involving other specified sports and athletics','2023-05-30','2023-10-11','Mamburao','Ancell Fitt'),(16,'adanksf','OYK','Malignant neoplasm of rectosigmoid junction','2023-03-07','2023-06-07','Pacucha','Artur Danks'),(17,'estanyerg','FSC','Person boarding or alighting a motorcycle injured in collision with pedal cycle, subsequent encounter','2023-05-06','2023-11-05','Grande Cache','Emlynne Stanyer'),(18,'dmincih','CUR','Subluxation of metacarpophalangeal joint of other finger, subsequent encounter','2023-05-24','2023-08-31','Cagbang','Devland Minci'),(19,'agrelaki','CRR','Occupant (driver) (passenger) of heavy transport vehicle injured in transport accidents with military vehicle, sequela','2023-04-18','2023-08-12','Shuangkou','Aylmer Grelak'),(20,'slorriej','EWN','Other intrapartum hemorrhage','2023-02-15','2023-06-13','Avalynest','Sidney Lorrie'),(21,'jderrickk','BRA','Insect bite (nonvenomous) of right back wall of thorax, sequela','2023-01-25','2023-06-03','Osaragilo','Jakie Derrick'),(22,'whawkeyl','GPS','Nondisplaced fracture of medial condyle of left humerus, initial encounter for open fracture','2023-05-30','2023-11-01','Liuxia','Wilton Hawkey'),(23,'wspitellm','ATV','Poisoning by other laxatives, accidental (unintentional), sequela','2023-02-25','2023-06-02','Tablka','Whitby Spitell'),(24,'lrialln','LJG','Sprain of metacarpophalangeal joint of unspecified finger, sequela','2023-04-12','2023-07-20','Milove','Larry Riall'),(25,'mrookeo','GOJ','External constriction of unspecified ear, subsequent encounter','2023-03-13','2023-06-19','Savelugu','Meyer Rooke'),(26,'bmottinellip','XNN','Dislocation of other parts of left shoulder girdle, subsequent encounter','2023-02-03','2023-12-17','San Ramon','Bathsheba Mottinelli'),(27,'tflavertyq','ARG','Sleepwalking [somnambulism]','2023-05-07','2023-11-13','Point Hill','Tremaine Flaverty'),(28,'awillingaler','KNU','Burn of first degree of multiple sites of unspecified shoulder and upper limb, except wrist and hand, sequela','2023-05-09','2023-11-30','Berkovitsa','Aaron Willingale'),(29,'pstarrss','DRC','Mediastinal (thymic) large B-cell lymphoma, unspecified site','2023-04-12','2023-07-08','Linjiang','Phaedra Starrs'),(30,'amacgettigent','ODR','Unspecified occupant of bus injured in collision with fixed or stationary object in traffic accident, subsequent encounter','2023-04-29','2023-08-15','Bojnik','Ameline MacGettigen'),(31,'sheinleu','TBJ','Nondisplaced fracture of second metatarsal bone, right foot, subsequent encounter for fracture with nonunion','2023-03-04','2023-09-17','Chikwawa','Sheffie Heinle'),(32,'dtrytsmanv','AAC','Other specified viral hemorrhagic fevers','2023-01-18','2023-07-04','San Nicolas','Daven Trytsman'),(33,'jwallickerw','GTR','External constriction of left back wall of thorax, sequela','2023-01-17','2023-11-12','Ustynivka','Jerry Wallicker'),(34,'cburberyex','XPL','Disorder of amniotic fluid and membranes, unspecified, second trimester','2023-05-16','2023-11-28','Spitsevka','Coretta Burberye'),(35,'kcamolliy','XPP','Other osteoporosis with current pathological fracture, right ankle and foot, subsequent encounter for fracture with malunion','2023-03-17','2023-10-01','Mendes','Karlene Camolli'),(36,'alockyearz','MPW','Displaced Maisonneuve\'s fracture of right leg, sequela','2023-03-06','2023-12-12','San Antonio','Arnoldo Lockyear'),(37,'asyplus10','SJP','Periodic paralysis','2023-05-05','2023-12-28','Huanoquite','Aldo Syplus'),(38,'msline11','REO','Laceration of axillary artery, left side, sequela','2023-05-09','2023-09-26','Huzhen','Miller Sline'),(39,'pcarradice12','TPJ','Fracture of angle of right mandible, initial encounter for open fracture','2023-05-04','2023-08-25','Mataquescuintla','Perry Carradice'),(40,'omilstead13','HRT','Major laceration of femoral artery, unspecified leg, subsequent encounter','2023-02-24','2023-07-30','Krzytsowice','Osbourne Milstead'),(41,'ptorrejon14','KNA','Other fracture of shaft of left tibia, subsequent encounter for open fracture type I or II with nonunion','2023-02-27','2023-12-22','Baiquan','Patrick Torrejon'),(42,'pnielson15','NOC','Unspecified superficial injury of right forearm, subsequent encounter','2023-03-08','2023-11-28','Lingbei','Peggie Nielson'),(43,'esnaith16','EOR','Unspecified motorcycle rider injured in collision with other motor vehicles in traffic accident, initial encounter','2023-01-09','2023-08-05','Huanglian','Edita Snaith'),(44,'elongrigg17','LEJ','Breakdown (mechanical) of internal fixation device of left humerus, sequela','2023-02-08','2023-09-18','Huurch','Elana Longrigg'),(45,'jcurteis18','TEU','Other injury of other intra-abdominal organs','2023-04-19','2023-09-22','Shumjsack','Janeczka Curteis'),(46,'sbaldrey19','NAO','Nondisplaced transverse fracture of left patella, subsequent encounter for closed fracture with delayed healing','2023-01-28','2023-07-07','Houilles','Sheryl Baldrey'),(47,'tpavett1a','NAM','Anterior dislocation of unspecified sternoclavicular joint, initial encounter','2023-02-19','2023-11-23','Hotonj','Trever Pavett'),(48,'tchmiel1b','NAO','Laceration with foreign body of unspecified external genital organs','2023-02-11','2023-08-01','Saovedalen','Tiffanie Chmiel'),(49,'theningam1c','BIG','Displaced fracture of head of unspecified radius, subsequent encounter for open fracture type I or II with malunion','2023-02-10','2023-06-05','Ugljevik','Tremain Heningam'),(50,'gstoffler1d','DNZ','Other acute appendicitis','2023-04-08','2023-06-28','Erawmi','Gizela Stoffler'),(51,'ezaniolo1e','AAR','Displaced fracture of medial phalanx of unspecified finger','2023-02-23','2023-11-08','Enhe Hada','Eimile Zaniolo'),(52,'ccrysell1f','SAQ','Displaced fracture of base of third metacarpal bone, left hand, initial encounter for closed fracture','2023-04-10','2023-11-11','Mosfilotake','Carlita Crysell'),(53,'wpinxton1g','TMB','Unspecified disorder of synovium and tendon, hand','2023-04-07','2023-11-20','Gedongmulyo','Winnah Pinxton'),(54,'akarus1h','TUM','Acute lymphoblastic leukemia [ALL]','2023-02-20','2023-06-05','Mariawke','Alonzo Karus'),(55,'eguyan1i','IXD','Unspecified fracture of second lumbar vertebra','2023-03-15','2023-08-14','Bamenda','Engracia Guyan'),(56,'hmattiacci1j','SAS','Nondisplaced fracture of coronoid process of left ulna, subsequent encounter for open fracture type IIIA, IIIB, or IIIC with nonunion','2023-01-06','2023-06-27','Nuevo ArraijÃ¡n','Hewie Mattiacci'),(57,'nwigan1k','HCJ','Displaced fracture of first metatarsal bone, unspecified foot, subsequent encounter for fracture with nonunion','2023-02-11','2023-11-20','Dumalneg','Norene Wigan'),(58,'mdyde1l','PUL','Coma scale, best verbal response','2023-02-11','2023-07-31','La Guata','Margarete Dyde'),(59,'gnewvell1m','JNB','Hit by object falling from aircraft, initial encounter','2023-04-27','2023-09-15','Azulovale','Gardiner Newvell'),(60,'athrustle1n','YMN','Salter-Harris Type II physeal fracture of lower end of left tibia, subsequent encounter for fracture with nonunion','2023-01-15','2023-10-26','Ribeirado','Alis Thrustle'),(61,'mgallant1o','TZX','Nondisplaced supracondylar fracture with intracondylar extension of lower end of left femur, subsequent encounter for closed fracture with nonunion','2023-02-16','2023-06-17','General Belgrano','Marys Gallant'),(62,'jweatherby1p','SRG','Strain of flexor muscle, fascia and tendon of right index finger at forearm level','2023-01-27','2023-08-31','Panitian','Jamil Weatherby'),(63,'ooakinfold1q','ZHM','Xeroderma of right eye, unspecified eyelid','2023-05-15','2023-09-07','Sumurgung','Oriana Oakinfold'),(64,'rflannery1r','LDW','Food in bronchus','2023-03-12','2023-11-29','Backoumi','Renata Flannery'),(65,'kcokely1s','IWK','Breakdown (mechanical) of other urinary stents','2023-01-07','2023-12-05','Long Loreh','Kellina Cokely'),(66,'lkauble1t','HAO','Resistance to quinolones and fluoroquinolones','2023-02-27','2023-11-25','Mela­ssia','Lydia Kauble'),(67,'svanshin1u','GPL','Nondisplaced trimalleolar fracture of unspecified lower leg, subsequent encounter for closed fracture with nonunion','2023-05-23','2023-12-06','Penengahan','Sybille Vanshin'),(68,'ckybert1v','ZKE','Unspecified subluxation and dislocation of patella','2023-03-22','2023-08-28','Longsha','Caroljean Kybert'),(69,'geakle1w','CWC','Toxic effect of chewing tobacco, assault, sequela','2023-01-04','2023-07-11','Xianghe','Gilberta Eakle'),(70,'bfausch1x','AVN','Nondisplaced segmental fracture of shaft of radius, unspecified arm, subsequent encounter for open fracture type IIIA, IIIB, or IIIC with malunion','2023-04-24','2023-09-06','Bindang','Beryle Fausch'),(71,'tgirard1y','PFB','Other specified injury of left Achilles tendon','2023-01-26','2023-09-01','Korczyna','Tatum Girard'),(72,'dhydes1z','KGG','Nondisplaced comminuted fracture of shaft of left tibia, subsequent encounter for closed fracture with delayed healing','2023-02-17','2023-07-23','Oslo','Dru Hydes'),(73,'lhanse20','HHQ','Driver of snowmobile injured in traffic accident','2023-05-26','2023-07-15','Lyon','Levin Hanse'),(74,'fhallatt21','AZO','Poisoning by anticoagulants, accidental (unintentional)','2023-05-16','2023-08-21','Changxingbao','Fran Hallatt'),(75,'scorey22','LVL','Military operations involving other destruction of aircraft, military personnel','2023-02-02','2023-06-24','St. Thomas','Sayres Corey'),(76,'kbarthrup23','LMQ','Puncture wound with foreign body of left forearm','2023-02-24','2023-06-20','Hamanoichi','Kerrin Barthrup'),(77,'ctilly24','ABI','Other reduction defects of left upper limb','2023-03-18','2023-09-19','Qingyang','Carlo Tilly'),(78,'ccaramuscia25','DLI','Carbuncle of other sites','2023-04-12','2023-08-10','Chajaraw','Cirillo Caramuscia'),(79,'jgomer26','RBF','Other hypothyroidism','2023-03-24','2023-06-07','Melissoch','Jeramey Gomer'),(80,'ajovasevic27','NRE','Motorized mobility scooter colliding with stationary object, subsequent encounter','2023-03-13','2023-08-15','Sathing Phra','Auberta Jovasevic'),(81,'igreenstock28','KRY','Nondisplaced fracture of capitate [os magnum] bone, left wrist, initial encounter for open fracture','2023-04-22','2023-12-07','North Little Rock','Idaline Greenstock'),(82,'aguppey29','GUJ','Sprain of calcaneofibular ligament of unspecified ankle, subsequent encounter','2023-04-16','2023-07-13','Stryszawa','Amalea Guppey'),(83,'rbeining2a','ALN','Burn of unspecified degree of multiple sites of head, face, and neck','2023-04-28','2023-09-26','Taiwan','Rowe Beining'),(84,'tmogey2b','NTY','Other specified acute skin changes due to ultraviolet radiation','2023-03-04','2023-07-07','Ketampak','Timmie Mogey'),(85,'ewurst2c','LSL','Interstitial myositis, other site','2023-02-10','2023-12-26','Karachi','Errol Wurst'),(86,'nvaleri2d','APT','Algoneurodystrophy, right shoulder','2023-02-22','2023-10-29','Siepraw','Nicol Valeri'),(87,'obarstowk2e','DBO','Displaced fracture of lateral condyle of unspecified tibia, subsequent encounter for open fracture type IIIA, IIIB, or IIIC with delayed healing','2023-04-06','2023-10-12','Itagui','Olga Barstowk'),(88,'pnutten2f','ICC','Other sprain of right hip, initial encounter','2023-02-18','2023-09-10','Boden','Philippine Nutten'),(89,'fbavage2g','AUO','Nondisplaced fracture of body of hamate [unciform] bone, unspecified wrist, initial encounter for closed fracture','2023-05-24','2023-12-21','Auch','Fields Bavage'),(90,'swyss2h','PMR','Kernicterus, unspecified','2023-03-09','2023-11-21','Amsterdam','Sharlene Wyss'),(91,'mduiged2i','YXC','Crohn\'s disease of both small and large intestine with complications','2023-05-29','2023-10-06','Kyankwanzi','Minetta Duiged'),(92,'ghallgath2j','AKP','Acute pancreatitis','2023-02-06','2023-11-13','Oyonnax','Gianna Hallgath'),(93,'cthomassen2k','XBG','Blizzard (snow)(ice)','2023-02-20','2023-08-21','Nagrog Wetan','Catlin Thomassen'),(94,'wpawelec2l','JAA','Displaced trimalleolar fracture of right lower leg, sequela','2023-01-02','2023-12-10','Nanger','Westleigh Pawelec'),(95,'ajeavon2m','RDC','Perforation due to foreign body accidentally left in body following other procedure, sequela','2023-02-08','2023-12-07','Kukawa','Alfredo Jeavon'),(96,'kstandell2n','LWV','Posterior subluxation of right ulnohumeral joint','2023-01-15','2023-12-11','sighisoara','Kristal Standell'),(97,'wboniface2o','CBT','Open bite of right lesser toe(s) without damage to nail, sequela','2023-01-14','2023-09-05','Rio Guayabal de Yateras','Wildon Boniface'),(98,'lshiers2p','TNV','Injury of other nerves at wrist and hand level of left arm, subsequent encounter','2023-05-22','2023-12-24','Sa Paulo','Lauri Shiers'),(99,'pmussard2q','WKL','Person on outside of car injured in collision with fixed or stationary object in traffic accident, subsequent encounter','2023-02-15','2023-07-04','Russkaya Polyana','Porter Mussard'),(100,'asawter2r','ETE','Displaced fracture of triquetrum [cuneiform] bone, right wrist, initial encounter for closed fracture','2023-05-15','2023-06-18','Kanye','Adelice Sawter');
/*!40000 ALTER TABLE `training_plans` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-11-20 11:33:54
